# RSI Antifraud HUB

## Descripción
El objetivo de este servicio es el de centralizar todas las llamadas hacia motores antifraude, tanto de operaciones económicas como de blanqueo de capitales, estableciendo una entrada y salida estándar, facilitando la integración de estos análisis dentro de RSI.
## Funcionalidad

### Motores

Actualmente el hub integra dos motores antifraude y una sola operativa a validar, de los dos motores solo uno de ellos en modo de análisis:

- **Motor Táctico**: Es el motor actual de análisis antifraude, es el encargado a día de hoy de evaluar las transferencias
- **IBM Safer Payments**: Es el futuro motor de evaluación, a día de hoy, las operativas que pasan a través del motor táctico son enviadas a modo informativo hacia Safer.

### Operativas

Actualmente las única operativa que el hub enviará hacia el motor táctico para su evaluación serán las transferencias TARGET, el resto de operativas no serán enviadas para su evaluación, devolviendo todas ellas una respuesta genérica hacia la operativa.


### Fases de ejecución

Para las operativas económicas existen 3 fases, simulación, alta y ejecución.

Actualmente la única fase donde se enviará la operativa a evaluar será el alta, resultando las otras dos en una respuesta genérica por parte del hub.

## Estructura de proyecto
```bash
├───java
│   └───com
│       └───rsi
│           └───fraudapihub
│               │   FraudapihubApplication.java
│               │   
│               ├───configuration
│               │       AntifraudEngineConfiguration.java
│               │       ApiHubManagerConfiguration.java
│               │       ApplicationConfiguration.java
│               │       CustomJmsHealthIndicator.java
│               │       FilterConfiguration.java
│               │       JacksonConfiguration.java
│               │       MQQueue.java
│               │       RestClientConfig.java
│               │       Schemas.java
│               │       SoapConfiguration.java
│               │       
│               ├───controllers
│               │   ├───rest
│               │   │       ApiHubRestOperationController.java
│               │   │       ApiHubRestPersonController.java
│               │   │       
│               │   └───soap
│               │           ApiHubSoapController.java
│               │           
│               ├───exceptions
│               │       GlobalExceptionHandler.java
│               │       MapperFailedException.java
│               │       
│               ├───interceptors
│               │       SoapValidationInterceptor.java
│               │       
│               ├───manager
│               │   ├───connection
│               │   │   │   ApiHubRestOperationManager.java
│               │   │   │   
│               │   │   └───impl
│               │   │           ApiHubRestOperationManagerImpl.java
│               │   │           
│               │   └───operation
│               │       │   ApiHubOperationManager.java
│               │       │   ApiHubPersonManager.java
│               │       │   
│               │       └───impl
│               │               ApiHubOperationManagerImpl.java
│               │               ApiHubPersonManagerImpl.java
│               │
│               ├───service
│               │   │   AntifraudEngineService.java
│               │   │
│               │   ├───connection
│               │   │   │   ApiHubRestService.java
│               │   │   │
│               │   │   └───impl
│               │   │           ApiHubRestServiceImpl.java
│               │   │
│               │   └───operation
│               │       │   ApiHubOperationService.java
│               │       │
│               │       └───impl
│               │               ApiHubOperationServiceImpl.java
│               │
│               └───utils
│                   ├───constants
│                   │       ControllerConstants.java
│                   │       ResponseConstants.java
│                   │
│                   ├───dto
│                   │   │   DtoUtils.java
│                   │   │
│                   │   ├───base
│                   │   │       BaseResponse.java
│                   │   │       ErrorResponse.java
│                   │   │       ResponseCode.java
│                   │   │
│                   │   ├───request
│                   │   │   ├───engine
│                   │   │   │   ├───safer
│                   │   │   │   │       SaferRequestDto.java
│                   │   │   │   │
│                   │   │   │   └───tactical
│                   │   │   │           EE_I_ComprobarFraude.java
│                   │   │   │           Request.java
│                   │   │   │
│                   │   │   └───operation
│                   │   │           OperationRequestDto.java
│                   │   │           PersonRequestDto.java
│                   │   │
│                   │   └───response
│                   │       ├───engine
│                   │       │   ├───safer
│                   │       │   │       IrisDTO.java
│                   │       │   │       MandatorDTO.java
│                   │       │   │       SaferResponseDTO.java
│                   │       │   │
│                   │       │   └───tactical
│                   │       │           EE_O_ComprobarFraude.java
│                   │       │           FactorDto.java
│                   │       │           RespuestaDto.java
│                   │       │
│                   │       └───operation
│                   │               OperationInsideResponseDto.java
│                   │               OperationResponseDto.java
│                   │               PersonInsideResponseDto.java
│                   │               PersonResponseDto.java
│                   │
│                   ├───enums
│                   │       EnginesCodes.java
│                   │       OperationPhaseStatus.java
│                   │       ResponseCode.java
│                   │
│                   └───mapper
│                           OperationFactory.java
│                           OperationMapper.java
│
└───resources
    │   banner.txt
    │   bootstrap-DESA.properties
    │   bootstrap-PREP.properties
    │   bootstrap-PROD.properties
    │   bootstrap-TEST.properties
    │   bootstrap-UAT.properties
    │   bootstrap.properties
    │
    ├───DESA
    │       logback.xml
    │
    ├───PREP
    │       logback.xml
    │
    ├───PROD
    │       logback.xml
    │
    ├───TEST
    │       logback.xml
    │
    └───UAT
            logback.xml
```
### Carpetas importantes

Dentro de todas las carpetas del proyecto las 4 más importantes serían las siguientes:
- **manager**: Contiene toda la lógica de la conexión con los distintos motores, así como la propia lógica de ejecución de mapeos dentro del hub.
- **service**: Contiene la fachada entre los controladores y el manager.
- **utils/mapper**: Contiene los mapeos de las operativas hacia los distintos motores
- **utils/dto**: Contiene todos los modelos de datos de entrada y salida, tanto del hub como de los distintos motores con los que se integra.

## API

Tenemos dos APIs de entrada distintos, dependiendo del tipo de operación que se quiera validar, los dos modelos se encuentran dentro de la carpeta *utils/dto/request/operation*

- **Operaciones económicas**: Definido dentro del fichero OperationRequestDTO
- **Operaciones de blanqueo**: Definido dentro del fichero PersonRequestDTO
### Diagrama de clases de entrada
**OperationRequestDTO**
```mermaid
classDiagram
    class OperationRequestDto
    OperationRequestDto: -String codigoEntidad
    OperationRequestDto: -String tipoOperacion
    OperationRequestDto: -String usuarioBE
    OperationRequestDto: -String acuerdoBE
    OperationRequestDto: -String idSesion
    OperationRequestDto: -String idCanal
    OperationRequestDto: -String estadoFaseOperacion
    OperationRequestDto: -String nombreOrdenante
    OperationRequestDto: -String ibanOrdenante
    OperationRequestDto: -String nombreBeneficiario
    OperationRequestDto: -String ibanBeneficiario
    OperationRequestDto: -String entidadBeneficiaria
    OperationRequestDto: -String bicBeneficiario
    OperationRequestDto: -String telefonoDestinatario
    OperationRequestDto: -Float importeOperacion
    OperationRequestDto: -String codigoMonedaOperacion
    OperationRequestDto: -String concepto
    OperationRequestDto: -String nombrePorCuentaDe
    OperationRequestDto: -String fechaHora
    OperationRequestDto: -String idOperacionBE
    OperationRequestDto: -String idOperacionCORE
    OperationRequestDto: -Float importeComisionesOperacion
    OperationRequestDto: -Float gastos
    OperationRequestDto: -String retornoOperacion
    OperationRequestDto: -String mensajeMostrarOperacion
    OperationRequestDto: -String cccVirtual
    OperationRequestDto: -String idInternoPE
	OperationRequestDto: +toString()
```

**PersonRequestDTO**
```mermaid
classDiagram
    class PersonRequestDTO
    PersonRequestDTO: -String codigoEntidad
    PersonRequestDTO: -String tipoOperacion
    PersonRequestDTO: -String idCanal
    PersonRequestDTO: -String idInternoPe
    PersonRequestDTO: -String codigoIdExterno
    PersonRequestDTO: -String idCanal
    PersonRequestDTO: -String idExternoPe
    PersonRequestDTO: -String apellidoUnoCliente
    PersonRequestDTO: -String apellidoDosCliente
    PersonRequestDTO: -String nombreBeneficiario
    PersonRequestDTO: -String nombreCliente
    PersonRequestDTO: -String denomLegal
    PersonRequestDTO: -String tipoPersona
    PersonRequestDTO: -String sexo
    PersonRequestDTO: -String codigoPaisNacionalidad
    PersonRequestDTO: -String codigoPaisNacimiento
    PersonRequestDTO: -String codigoPaisResidencia
    PersonRequestDTO: -String codigoEstructuraLegal
    PersonRequestDTO: -String fechaNacimiento
    PersonRequestDTO: -String codigoCNAE
    PersonRequestDTO: -String codigoCNO
    PersonRequestDTO: -String codigoSituacionLaboral
    PersonRequestDTO: -String paisFiscal
    PersonRequestDTO: -String municipioFiscal
    PersonRequestDTO: -String municipioPostal
    PersonRequestDTO: -String listaRelacionesPersona
    PersonRequestDTO: -String estadoPersona
	PersonRequestDTO: +toString()
```
### Diagrama de clases de salida
**OperationResponseDto**
```mermaid
classDiagram
    class BaseResponse
    BaseResponse: -String codigoRetorno

    class OperationResponseDto
    OperationResponseDto: -OperationInsideResponseDto RespuestaOperacion
    OperationResponseDto: -ErrorResponse Errores
    
    class OperationInsideResponseDto
    OperationInsideResponseDto: -String estadoOperacion
    OperationInsideResponseDto: -FloatriesgoOperacion
    OperationInsideResponseDto: -String idOperacionBE
    OperationInsideResponseDto: -Integer idOperacionInterno
    OperationInsideResponseDto: -Boolean bloquearUsuario
    OperationInsideResponseDto: -String motivosFraude
    OperationInsideResponseDto: -MotorInfoLoaded motorInfoLoaded
    
    class ErrorResponse
    ErrorResponse: -String codigoMostrar
    ErrorResponse: -String mensajeMostrar
    ErrorResponse: -String solucion
    
    class MotorInfoLoaded
    MotorInfoLoaded: -String codigoMotor
    MotorInfoLoaded: -String claseMapeo

	BaseResponse <|-- OperationResponseDto
	OperationResponseDto <|-- OperationInsideResponseDto
	OperationResponseDto <|-- ErrorResponse
	OperationInsideResponseDto <|-- MotorInfoLoaded
```
**PersonResponseDto**
```mermaid
classDiagram
    class BaseResponse
    BaseResponse: -String codigoRetorno

    class PersonResponseDto
    PersonResponseDto: -PersonInsideResponseDto RespuestaOperacion
    PersonResponseDto: -ErrorResponse Errores
    
    class PersonInsideResponseDto
    PersonInsideResponseDto: -String codRespuestaMotor
    PersonInsideResponseDto: -String descripcionRespuestaMotor
    PersonInsideResponseDto: -String codMotor
    PersonInsideResponseDto: -String idExternoMotor
    PersonInsideResponseDto: -String tipoOperacion
    PersonInsideResponseDto: -String idAlerta
    PersonInsideResponseDto: -String idEvidencia
    PersonInsideResponseDto: -String riesgoOperacion
    PersonInsideResponseDto: -String codRegla
    PersonInsideResponseDto: -String descrRegla
    PersonInsideResponseDto: -String riesgoOperacionManual
    
    class ErrorResponse
    ErrorResponse: -String codigoMostrar
    ErrorResponse: -String mensajeMostrar
    ErrorResponse: -String solucion

	BaseResponse <|-- PersonResponseDto
	PersonResponseDto <|-- PersonInsideResponseDto
	PersonResponseDto <|-- ErrorResponse
```
## Diagramas de secuencia

### Análisis Motor Táctico
```mermaid
sequenceDiagram
Operativa->> HUB: Envio datos operativa
HUB-->>Configuración: Comprobar configuración por entidad/operativa/canal
Configuración-->> HUB: Configuración encontrada hacia motor táctico
HUB->> Motor Táctico: Datos operativa
Note right of Configuración: La configuración a día de hoy<br/>es estática en<br/>ficheros de configuración
alt Motor Táctico responde OK
	Motor Táctico->> HUB: Análisis OK/KO
	HUB->>Servicio SVO: Inserta en tablas SVO análisis
	HUB->>SAFER: Envio en informativo hacia SAFER
	HUB->>Operativa: Resultado análisis OK/KO
else Error Motor Táctico
	HUB->>Servicio SVO: Inserta en tablas SVO error del motor
	HUB->>Operativa: Respuesta genérica OK
end
```
### Análisis IBM Safer Payments
```mermaid
sequenceDiagram
Operativa->> HUB: Envio datos operativa
HUB-->>Configuración: Comprobar configuración por entidad/operativa/canal
Configuración-->> HUB: Configuración encontrada hacia SAFER
HUB->> Safer: Envio mapeo por operativa
Note right of Configuración: La configuración a día de hoy<br/>es estática en<br/>ficheros de configuración
Safer->> HUB: Resultado análisis
HUB->> Operativa: Resultado análisis
```
### Respuesta genérica
```mermaid
sequenceDiagram
Operativa->> HUB: Envio datos operativa
HUB-->>Configuración: Comprobar configuración por entidad/operativa/canal
Configuración--x HUB: Configuración no encontrada
HUB->> Operativa: Respuesta OK Genérica
Note right of Configuración: La configuración a día de hoy<br/>es estática en<br/>ficheros de configuración.
```
## Configuración

La configuración del hub se encuentra actualmente dentro de ficheros YAML en el config server con la distribución de entornos habitual en RSI: DESA, TEST, UAT, PRE, PROD.

### Ficheros de configuración
Cada fichero de configuración se compone de dos apartados:
**Configuración de motores**:
-	**Identificador de motor**: ID del motor asociado
-	**Nombre de motor**: Nombre asociado al motor
-	**URL del endpoint del motor**: Endpoint REST de acceso al motor
     **Configuración de ingesta por entidad/operativa/canal**
- **Entidad**: Entidad asociada
- **Operativa**: Operativa asociada
- **Canal**: Canal asociado
- **Clase mapeo**: Modo de ingesta
- **Codigo Motor**: Id del motor al que se va a ingestar

La funcionalidad del hub decidirá el motor y mapeo que se va a usar viene definida por la configuración asociada a una entidad, operativa y canal.

El parámetro "clase-mapeo" es el que decidirá que tipo de mapeo se va a realizar, estando disponible actualmente estos únicos valores
- **TACTICO**: Mapeo necesario para ingestar al motor táctico actual
- **TARGET**: Mapeo hacia SAFER ingestando una transferencia TARGET
- **BIZUM**: Mapeo hacia SAFER ingestando una operativa BIZUM.

El hub leerá este parámetro y realizará los mapeos adecuados hacia el modelo de datos del motor asociado en el parámetro "codigo-motor"

Hay que tener especial cuidado en no asociar una operativa no soportada por el motor seleccionado en el "codigo-motor", por ejemplo, si se selecciona en "codigo-motor" el valor asociado a SAFER no podemos pedirle que mapee una operativa de tipo TACTICO ya que esta es especifica de un motor concreto, si se configura el hub erroneamente se devolverá un error de mapeo hacia el cliente.

### Servicio de configuración
Dentro del hub existe un servicio encargado de la lectura y carga en memoria de la configuración existente en los ficheros YAML.

La clase encargada se llama *AntifraudEngineService* dentro de la carpeta *service*. Esta clase se encargará de exponer la configuración cargada desde una clase de configuración (*AntifraudEngineConfiguration*).

### Recarga en caliente de la configuración
Si se necesita recargar la configuración del hub simplemente debereos de ejecutar el endpoint de actuator encargado de refrescar en caliente la configuración: *{host}/rsi-api-hub/actuator/refresh*
