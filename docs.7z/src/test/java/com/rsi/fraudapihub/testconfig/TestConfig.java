package com.rsi.fraudapihub.testconfig;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.IOException;

@Configuration
@ComponentScan(basePackages = { "com.rsi.fraudapihub" })
@PropertySource({ "classpath:application-test.yml" })
@EnableConfigurationProperties
@RefreshScope
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
public class TestConfig {

    /**
     * Property placeholder configurer.
     *
     * @return the property placeholder configurer
     * @throws IOException
     *         Signals that an I/O exception has occurred.
     */
    @Bean
    public PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer() throws IOException {
        final PropertySourcesPlaceholderConfigurer ppc = new PropertySourcesPlaceholderConfigurer();
        ppc.setLocations(ArrayUtils.addAll(new PathMatchingResourcePatternResolver().getResources("classpath*:*test.yml")));
        return ppc;
    }

}
