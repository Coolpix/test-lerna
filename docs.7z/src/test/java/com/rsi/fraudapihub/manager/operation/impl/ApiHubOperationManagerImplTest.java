package com.rsi.fraudapihub.manager.operation.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.exceptions.EngineTimeOutException;
import com.rsi.fraudapihub.handler.requestStrategy.operations.OperationsRequestHandler;
import com.rsi.fraudapihub.manager.operation.engines.operations.ApiHubFunctionsManager;
import com.rsi.fraudapihub.manager.operation.operations.operations.impl.ApiHubOperationManagerImpl;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.service.connection.ApiHubRestService;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.IrisDTO;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mapstruct.factory.Mappers;
import org.mockito.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ApiHubOperationManagerImplTest {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Mock
    private JmsTemplate jmsTopicTemplate;

    @Mock
    private ApiHubRestService apiHubRestService;

    @Mock
    private ApiHubFunctionsManager apiHubFunctionsManager;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private OperationsRequestHandler<SaferRequestDto> operationsRequestHandler;

    @Mock
    private OperationMapper operationMapperMock;

    @Mock
    private AntifraudEngineService antifraudEngineService;

    @Mock
    private IrisDTO irisDTO;

    @InjectMocks
    private ApiHubOperationManagerImpl apiHubOperationManager;

    private OperationRequestDto requestDto;

    private SaferRequestDto saferRequestDto;

    private SaferResponseDTO saferResponseDto;

    private final OperationMapper operationMapper = Mappers.getMapper(OperationMapper.class);

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // OperationRequestDto
        this.requestDto = new OperationRequestDto();
        this.requestDto.setCodigoMonedaOperacion("EUR");
        this.requestDto.setRetornoOperacion("1");
        this.requestDto.setTipoOperacion("90006");
        this.requestDto.setAcuerdoBE("2036624795");
        this.requestDto.setIdOperacionBE("40801165012");
        this.requestDto.setNombreBeneficiario("PRUEBA");
        this.requestDto.setFechaHora("2024-11-07 13:28:15:299");
        this.requestDto.setNombreOrdenante("CLIENTEG APELLIDOA APELLIDOB");
        this.requestDto.setIbanBeneficiario("ES0401821294120205925478");
        this.requestDto.setImporteOperacion(1F);
        this.requestDto.setIdCanal("8ML70eCxLjH_TOcd4hwSMEMPAL0a");
        this.requestDto.setIdSesion("");
        this.requestDto.setBicBeneficiario("");
        this.requestDto.setUsuarioBE("03961840");
        this.requestDto.setEstadoFaseOperacion("1");
        this.requestDto.setConcepto("TARGET VIA BE");
        this.requestDto.setCodigoEntidad("0198");
        this.requestDto.setCccVirtual("01980900282036624522");
        this.requestDto.setIbanOrdenante("ES6201980900282036624522");
        this.requestDto.setMensajeMostrarOperacion("");
        this.requestDto.setIdInternoPE("1627655");

        this.saferResponseDto = new SaferResponseDTO();

        saferResponseDto.setIris(irisDTO);
        saferResponseDto.setSpIntercept(0);
        saferResponseDto.setSpBloqueoUsuario(0);
        saferResponseDto.setSpRiskScore(0.0f);
        saferResponseDto.setSpRulesFired("");

        // SaferRequestDto
        /*saferRequestDto = new SaferRequestDto();
        saferRequestDto.setCodigoEntidad("0198");
        saferRequestDto.setTipoOperacion("90006");
        saferRequestDto.setUsuarioBE("03961840");
        saferRequestDto.setAcuerdoBE("2036624795");
        saferRequestDto.setIdSesion("");
        saferRequestDto.setIdCanal("8ML70eCxLjH_TOcd4hwSMEMPAL0a");
        saferRequestDto.setEstadoFaseOperacion("1");
        saferRequestDto.setNombreOrdenante("CLIENTEG APELLIDOA APELLIDOB");
        saferRequestDto.setIbanOrdenante("ES6201980900282036624522");
        saferRequestDto.setNombreBeneficiario("PRUEBA");
        saferRequestDto.setIbanBeneficiario("ES0401821294120205925478");
        saferRequestDto.setEntidadBeneficiaria(null);
        saferRequestDto.setBicBeneficiario(null);
        saferRequestDto.setTelefonoDestinatario(null);
        saferRequestDto.setImporteOperacion(1.0f);
        saferRequestDto.setCodigoMonedaOperacion("978");
        saferRequestDto.setConcepto("TARGET VIA BE");
        saferRequestDto.setNombrePorCuentaDe(null);
        saferRequestDto.setFechaHora("2024-11-07 13:28:15:299");
        saferRequestDto.setIdOperacionBE("40801165012");
        saferRequestDto.setIdOperacionCORE(null);
        saferRequestDto.setImporteComisionesOperacion(null);
        saferRequestDto.setGastos(null);
        saferRequestDto.setRetornoOperacion("1");
        saferRequestDto.setMensajeMostrarOperacion(null);*/
    }

    @Test
    @DisplayName("REST - Create SAFER Operation OK")
    @Disabled("Ver FIX: https://github.com/mockito/mockito/issues/3121")
    void testCreateOperationForRestValidationSafer_Success() throws Exception {
        // Arrange
        AntifraudEngineConfiguration.InfoMotorConfig motorInfo = mock(AntifraudEngineConfiguration.InfoMotorConfig.class);
        AntifraudEngineConfiguration.InfoCanal channel = mock(AntifraudEngineConfiguration.InfoCanal.class);
        AntifraudEngineService.MotorInfoLoaded motorInfoLoaded = new AntifraudEngineService.MotorInfoLoaded(List.of(new AntifraudEngineConfiguration.InfoMotorConfig("0","SAFER", "")), "TARGET");


        SaferRequestDto saferRequestDto = operationMapper.creationOperationToSaferTIOrTR(requestDto);
        when(operationsRequestHandler.handleOperation(anyString(), any())).thenReturn(saferRequestDto);

        when(antifraudEngineService.getEngineInfoByCodigoMotor(any())).thenReturn(motorInfo);
        when(antifraudEngineService.getEngineInfoByCodigoMotor(anyString()).getUrl()).thenReturn("http://foo");
        when(antifraudEngineService.getChannelById(anyString())).thenReturn(channel);

        when(apiHubFunctionsManager.getEngineResponse(any(),any(),any(),any(),any(),any())).thenCallRealMethod();

        when(apiHubRestService.sendPostRequestToSaferPayments(any(), any(), any(), any(), any())).thenReturn(new ResponseEntity<>(saferResponseDto, HttpStatus.OK));

        // Act
        CompletableFuture<ResponseEntity<OperationResponseDto>> result = apiHubOperationManager.createOperationForRestValidation(requestDto, motorInfoLoaded);

        // Assert
        assertNotNull(result);
        assertEquals(saferResponseDto, result.get().getBody());
    }

//    @Test
//    @DisplayName("REST - Create Tactico Operation OK")
//    void testCreateOperationForRestValidationTactico_Success() throws Exception {
//        // Arrange
//        AntifraudEngineService.MotorInfoLoaded motorInfoLoaded = mock(AntifraudEngineService.MotorInfoLoaded.class);
//        AntifraudEngineService.MotorInfo motorInfo = mock(AntifraudEngineService.MotorInfo.class);
//        when(motorInfoLoaded.getCodigoMotor()).thenReturn("1");
//        when(motorInfoLoaded.getClaseMapeo()).thenReturn("TACTICO");
//
//        CompletableFuture<String> future = new CompletableFuture<>();
//        future.complete(saferRequestDto.toString());
//
//        when(operationFactory.redirectOperationToMapper(any(), anyString())).thenReturn(saferRequestDto);
//
//        when(antifraudEngineService.getEngineInfoByCodigoMotor(any())).thenReturn(motorInfo);
//        when(antifraudEngineService.getEngineInfoByCodigoMotor(anyString()).getUrl()).thenReturn("http://foo");
//
//        when(apiHubRestService.sendPostRequestToTacticalAndSVO(any(), any(), any(), any(), any())).thenReturn(new ResponseEntity<>(saferRequestDto.toString(), HttpStatus.OK));
//        //when(objectMapper.writeValueAsString(any())).thenReturn(saferRequestDto.toString());
//
//        // Act
//        CompletableFuture<ResponseEntity<String>> result = apiHubOperationManager.createOperationForRestValidation(requestDto, motorInfoLoaded);
//
//        // Assert
//        assertNotNull(result);
//        assertEquals(saferRequestDto.toString(), result.get().getBody());
//        //verify(operationFactory, times(1)).redirectOperationToMapper(any(), anyString());
//    }

    @ParameterizedTest
    @ValueSource(strings = { "0", "1" })
    @DisplayName("Engine Time Out Check")
    void createOperationForRestValidation_timeout(String codigoMotor) {
        // Arrange
        List<AntifraudEngineConfiguration.InfoMotorConfig> infoMotorConfig = List.of(mock(AntifraudEngineConfiguration.InfoMotorConfig.class));
        AntifraudEngineService.MotorInfoLoaded motorInfoLoaded = new AntifraudEngineService.MotorInfoLoaded(infoMotorConfig, "TARGET");

        // Simulate timeout
        when(motorInfoLoaded.getCodigoMotor().getFirst().getCodigoMotor()).thenReturn(codigoMotor);
        CompletableFuture<String> future = new CompletableFuture<>();
        future.completeExceptionally(new EngineTimeOutException("Timeout", "ID", motorInfoLoaded));
        doThrow(EngineTimeOutException.class).when(operationMapperMock).buildSuccessfulResponseDTO(any());

        // Act & Assert
        assertThrows(Exception.class, () -> {
            apiHubOperationManager.createOperationForRestValidation(this.requestDto, motorInfoLoaded).get();
        });

        this.log.info("Ending createOperationForRestValidation_timeout");
    }
}

