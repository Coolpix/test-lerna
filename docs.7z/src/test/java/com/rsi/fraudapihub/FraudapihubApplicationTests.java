package com.rsi.fraudapihub;

//@SpringBootTest
//class FraudapihubApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
