package com.rsi.fraudapihub.utils.mapper;

import com.rsi.fraudapihub.handler.requestStrategy.operations.OperationsRequestHandler;
import com.rsi.fraudapihub.handler.requestStrategy.operations.impl.*;
import com.rsi.fraudapihub.utils.dto.request.engine.tactical.EE_I_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;

/**
 * The type Operation factory test.
 *
 * @author Miguel Alonso Felipe
 */
class OperationHandlerRequestTest {

    private OperationsRequestHandler<SaferRequestDto> operationsRequestHandler;

    private OperationsRequestHandler<EE_I_ComprobarFraude> operationsRequestHandlerTactico;

    private OperationRequestDto defaultRequestDto;

    private SaferRequestDto saferRequestDto;

    private final OperationMapper operationMapper = Mappers.getMapper(OperationMapper.class);

    /**
     * Sets up.
     */
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        operationsRequestHandler = new OperationsRequestHandler<>(
                new BizumRequestStrategy(operationMapper),
                new TargetRequestStrategy(operationMapper),
                new PSD2RequestStrategy(operationMapper),
                new TacticalRequestStrategy(operationMapper),
                new DefaultRequestStrategy(operationMapper)
        );

        operationsRequestHandlerTactico = new OperationsRequestHandler<>(
                new BizumRequestStrategy(operationMapper),
                new TargetRequestStrategy(operationMapper),
                new PSD2RequestStrategy(operationMapper),
                new TacticalRequestStrategy(operationMapper),
                new DefaultRequestStrategy(operationMapper)
        );

        // OperationRequestDto
        defaultRequestDto = new OperationRequestDto();
        defaultRequestDto.setCodigoMonedaOperacion("EUR");
        defaultRequestDto.setRetornoOperacion("1");
        defaultRequestDto.setTipoOperacion("90006");
        defaultRequestDto.setAcuerdoBE("2036624795");
        defaultRequestDto.setIdOperacionBE("40801165012");
        defaultRequestDto.setNombreBeneficiario("PRUEBA");
        defaultRequestDto.setFechaHora("2024-11-07 13:28:15:299");
        defaultRequestDto.setNombreOrdenante("CLIENTEG APELLIDOA APELLIDOB");
        defaultRequestDto.setIbanBeneficiario("ES0401821294120205925478");
        defaultRequestDto.setImporteOperacion(1F);
        defaultRequestDto.setIdCanal("8ML70eCxLjH_TOcd4hwSMEMPAL0a");
        defaultRequestDto.setIdSesion("");
        defaultRequestDto.setBicBeneficiario("");
        defaultRequestDto.setUsuarioBE("03961840");
        defaultRequestDto.setEstadoFaseOperacion("1");
        defaultRequestDto.setConcepto("TARGET VIA BE");
        defaultRequestDto.setCodigoEntidad("0198");
        defaultRequestDto.setCccVirtual("01980900282036624522");
        defaultRequestDto.setIbanOrdenante("ES6201980900282036624522");
        defaultRequestDto.setMensajeMostrarOperacion("");
        defaultRequestDto.setIdInternoPE("1627655");

        // SaferRequestDto
        saferRequestDto = new SaferRequestDto();
        saferRequestDto.setCodigoEntidad("0198");
        saferRequestDto.setTipoOperacion("90006");
        saferRequestDto.setUsuarioBE("03961840");
        saferRequestDto.setAcuerdoBE("2036624795");
        saferRequestDto.setIdSesion("");
        saferRequestDto.setIdCanal("8ML70eCxLjH_TOcd4hwSMEMPAL0a");
        saferRequestDto.setEstadoFaseOperacion("1");
        saferRequestDto.setNombreOrdenante("CLIENTEG APELLIDOA APELLIDOB");
        saferRequestDto.setIbanOrdenante("ES6201980900282036624522");
        saferRequestDto.setNombreBeneficiario("PRUEBA");
        saferRequestDto.setIbanBeneficiario("ES0401821294120205925478");
        saferRequestDto.setEntidadBeneficiaria(null);
        saferRequestDto.setBicBeneficiario(null);
        saferRequestDto.setTelefonoDestinatario(null);
        saferRequestDto.setImporteOperacion(1.0f);
        saferRequestDto.setCodigoMonedaOperacion("978");
        saferRequestDto.setConcepto("TARGET VIA BE");
        saferRequestDto.setNombrePorCuentaDe(null);
        saferRequestDto.setFechaHora("2024-11-07 13:28:15:299");
        saferRequestDto.setIdOperacionBE("40801165012");
        saferRequestDto.setIdOperacionCORE(null);
        saferRequestDto.setImporteComisionesOperacion(null);
        saferRequestDto.setGastos(null);
        saferRequestDto.setRetornoOperacion("1");
        saferRequestDto.setMensajeMostrarOperacion(null);
    }

    /**
     * Redirect operation to mapper execution path target.
     */
    @Test
    @DisplayName("EXECUTE - TARGET: SAFER")
    void redirectOperationToMapper_executionPath_target() {
        defaultRequestDto.setEstadoFaseOperacion("2");
        SaferRequestDto expectedResponse = operationMapper.executionOperationToSaferTIOrTR(defaultRequestDto);

        SaferRequestDto result = operationsRequestHandler.handleOperation("TARGET", defaultRequestDto);

        assertEquals(expectedResponse, result);
    }

    /**
     * Redirect operation to mapper execution path bizum.
     */
    @Test
    @DisplayName("EXECUTE - BIZUM: SAFER")
    void redirectOperationToMapper_executionPath_bizum() {
        defaultRequestDto.setEstadoFaseOperacion("2");
        SaferRequestDto expectedResponse = operationMapper.executionOperationToSaferBizum(defaultRequestDto);

        SaferRequestDto result = operationsRequestHandler.handleOperation("BIZUM", defaultRequestDto);

        assertEquals(expectedResponse, result);
    }

    /**
     * Redirect operation to mapper creation path target.
     */
    @Test
    @DisplayName("CREATE - TARGET: SAFER")
    void redirectOperationToMapper_creationPath_target() {
        SaferRequestDto expectedResponse = operationMapper.creationOperationToSaferTIOrTR(defaultRequestDto);

        SaferRequestDto result = operationsRequestHandler.handleOperation("TARGET", defaultRequestDto);

        assertEquals(expectedResponse, result);
    }

    /**
     * Redirect operation to mapper creation path bizum.
     */
    @Test
    @DisplayName("CREATE - BIZUM: SAFER")
    void redirectOperationToMapper_creationPath_bizum() {
        SaferRequestDto expectedResponse = operationMapper.creationOperationToSaferBizum(defaultRequestDto);

        SaferRequestDto result = operationsRequestHandler.handleOperation("BIZUM", defaultRequestDto);

        assertEquals(expectedResponse, result);
    }

    /**
     * Redirect operation to mapper creation path tactico.
     */
    @Test
    @DisplayName("CREATE - TACTICO: TACTICO")
    void redirectOperationToMapper_creationPath_tactico() {
        EE_I_ComprobarFraude expectedResponse = operationMapper.creationTacticalRequestMapping(defaultRequestDto);

        EE_I_ComprobarFraude result = operationsRequestHandlerTactico.handleOperation("TACTICO", defaultRequestDto);

        assertEquals(expectedResponse, result);
    }

    /**
     * Redirect operation to mapper simulation path target.
     */
    @Test
    @DisplayName("SIMULATE - TARGET: SAFER")
    void redirectOperationToMapper_simulationPath_target() {
        defaultRequestDto.setEstadoFaseOperacion("0");
        defaultRequestDto.setIdSesion("9837893");
        SaferRequestDto expectedResponse = operationMapper.simulationOperationToSaferTIOrTR(defaultRequestDto);

        SaferRequestDto result = operationsRequestHandler.handleOperation("TARGET", defaultRequestDto);

        assertEquals(expectedResponse, result);
    }

    /**
     * Redirect operation to mapper simulation path bizum.
     */
    @Test
    @DisplayName("SIMULATE - BIZUM: SAFER")
    void redirectOperationToMapper_simulationPath_bizum() {
        defaultRequestDto.setEstadoFaseOperacion("0");
        SaferRequestDto expectedResponse = operationMapper.simulationOperationToSaferBizum(defaultRequestDto);

        SaferRequestDto result = operationsRequestHandler.handleOperation("BIZUM", defaultRequestDto);

        assertEquals(expectedResponse, result);
    }

    /**
     * Redirect operation to mapper simulation path ti psd 2 or tr psd 2.
     */
    @Test
    @DisplayName("SIMULATE - TI TR PSD2: SAFER")
    void redirectOperationToMapper_simulationPath_tiPsd2_or_trPsd2() {
        defaultRequestDto.setEstadoFaseOperacion("0");
        defaultRequestDto.setIdSesion("");
        defaultRequestDto.setIbanOrdenante("");
        SaferRequestDto expectedResponse = operationMapper.simulationOperationToSaferTIPsd2OrTRPsd2(defaultRequestDto);

        SaferRequestDto result = operationsRequestHandler.handleOperation("PSD2", defaultRequestDto);

        assertEquals(expectedResponse, result);
    }
}

