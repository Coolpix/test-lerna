package com.rsi.fraudapihub.controllers.rest;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.utils.dto.response.config.ConfigResponseDto;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(properties = "spring.cloud.config.enabled=false")
@ActiveProfiles("test")
class ApiHubRestConfigControllerTest {

    @Autowired
    ApiHubRestConfigController apiHubRestConfigController;

    @Test
    @DisplayName("GET CHANNEL NAME BY ID - OK")
    void getChannelNameByIdOk() throws Exception {
        AntifraudEngineConfiguration.InfoCanal infoCanal = apiHubRestConfigController.getChannelNameById("8ML70eCxLjH_TOcd4hwSMEMPAL0a");
        assertEquals(infoCanal.getNombreCanal(), "Canal API PSD2");
    }

    @Test
    @DisplayName("GET CHANNEL NAME BY ID - GENERIC")
    void getChannelNameByIdGeneric() throws Exception {
        AntifraudEngineConfiguration.InfoCanal infoCanal = apiHubRestConfigController.getChannelNameById("8ML70eCxLjH");
        assertEquals(infoCanal.getNombreCanal(), "Canal Genérico");
    }

    @Test
    @DisplayName("EXIST ENTIDAD - OK")
    void existsEntidadTrue() throws Exception {
        ConfigResponseDto configResponseDto = apiHubRestConfigController.existsEntidad("9999");
        assertTrue(configResponseDto.isConfigured());
    }

    @Test
    @DisplayName("EXIST ENTIDAD - KO")
    void existsEntidadFalse() throws Exception {
        ConfigResponseDto configResponseDto = apiHubRestConfigController.existsEntidad("1111");
        assertFalse(configResponseDto.isConfigured());
    }
}