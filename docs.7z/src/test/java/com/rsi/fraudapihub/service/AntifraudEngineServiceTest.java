package com.rsi.fraudapihub.service;

import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.configuration.hub.ApiRoutingConfig;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@SpringBootTest(properties = "spring.cloud.config.enabled=false")
@ActiveProfiles("test")
class AntifraudEngineServiceTest {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Mock
    private AntifraudEngineConfiguration mockAntifraudEngineConfiguration;

    @Mock
    private ApiRoutingConfig mockApiRoutingConfig;

    @InjectMocks
    private AntifraudEngineService antifraudEngineService;

    @Autowired
    private ApiRoutingConfig apiRoutingConfig;

    @Autowired
    private AntifraudEngineConfiguration antifraudEngineConfiguration;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        antifraudEngineService = new AntifraudEngineService(mockAntifraudEngineConfiguration, mockApiRoutingConfig);
    }

    @ParameterizedTest
    @CsvFileSource(resources = "/test-parameters.csv", numLinesToSkip = 1)
    @DisplayName("GET INFO BY: ENTITY, OPERATIVE AND CHANNEL - OK")
    void testGetEngine_validConfiguration(String entidad, String operativa, String canal, String codigoMotor, String claseMapeo) throws Exception {
        when(mockAntifraudEngineConfiguration.getMotores()).thenReturn(antifraudEngineConfiguration.getMotores());
        when(mockApiRoutingConfig.getMappings()).thenReturn(apiRoutingConfig.getMappings());

        // Call the method
        AntifraudEngineService.MotorInfoLoaded result = antifraudEngineService.getEngines(
                entidad,
                operativa,
                canal
        );


        // Assertions
        assertEquals(antifraudEngineService.getEngineInfoByCodigoMotor(codigoMotor).getCodigoMotor(), codigoMotor);
        assertEquals(claseMapeo, result.getMapeo());
        this.log.info("Test finished with:\n\t - configuracion: {}\n\t - result: {}",
                apiRoutingConfig.getMappings(), result);
    }

    @ParameterizedTest
    @CsvSource({ ",,,,",
                ", 90006, 8ML70eCxLjH_TOcd4hwSMEMPAL0a, 0, TARGET",
                "3008,, 8ML70eCxLjH_TOcd4hwSMEMPAL0a, 0, BIZUM",
                "0198, 501,, 1, TACTICO"
    })
    @DisplayName("GET INFO BY: ENTITY, OPERATIVE AND CHANNEL - KO")
    void testGetEngine_inValidConfiguration(String entidad, String operativa, String canal, String codigoMotor, String claseMapeo) throws Exception {

        when(mockApiRoutingConfig.getMappings()).thenReturn(apiRoutingConfig.getMappings());

        // Assertions
        assertThrows(Exception.class, () -> {
            antifraudEngineService.getEngines(
                    entidad,
                    operativa,
                    canal
            );
        });

        this.log.info("Test finished with KO for null or empty parameters");
    }

    @ParameterizedTest
    @CsvSource({ "0, SAFER", "1, TACTICO", "2, SVO" })
    @DisplayName("GET INFO BY: ENGINE CODE - OK")
    void testGetEngineInfoByCodigoMotor_validConfiguration(String codigoMotor, String nombreMotor) throws Exception {

        when(mockAntifraudEngineConfiguration.getMotores()).thenReturn(antifraudEngineConfiguration.getMotores());

        // Call the method
        AntifraudEngineConfiguration.InfoMotorConfig result = antifraudEngineService.getEngineInfoByCodigoMotor(
                codigoMotor
        );

        // Assertions
        assertEquals(codigoMotor, result.getCodigoMotor());
        assertEquals(nombreMotor, result.getNombreMotor());
        this.log.info("Test finished with:\n\t - engines: {}\n\t - result: {}",
                mockAntifraudEngineConfiguration.getMotores(), result);
    }

    @ParameterizedTest
    @ValueSource(strings = { " ", "", "   " })
    @DisplayName("GET INFO BY: ENGINE CODE - KO")
    void testGetEngineInfoByCodigoMotor_inValidConfiguration(String codigoMotor) throws Exception {
        AntifraudEngineConfiguration.InfoMotorConfig genericEngineConfig = new AntifraudEngineConfiguration.InfoMotorConfig("9999", "Motor Genérico", "");

        // Assertions
        assertEquals(antifraudEngineService.getEngineInfoByCodigoMotor(codigoMotor), genericEngineConfig);

        this.log.info("Test finished with KO for null or empty parameters");
    }
}

