package com.rsi.fraudapihub.interceptors;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsi.schema.validation.JsonValidationFailedException;
import com.rsi.schema.validation.JsonValidationTools;
import jakarta.xml.soap.SOAPException;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.transform.TransformerException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * The type Soap validation interceptor.
 *
 * @author Miguel Alonso Felipe
 */
public class SoapValidationInterceptor extends AbstractPhaseInterceptor<Message> {

    private static final String WSDL_QUERY_PARAM = "wsdl";
    private static final String SOAP_ENVELOPE = "soapenv:Envelope";
    private static final String SOAP_BODY = "soapenv:Body";

    private final String jsonSchemaString;
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * Instantiates a new Soap validation interceptor.
     *
     * @param jsonSchemaString
     *         the json schema string
     */
    public SoapValidationInterceptor(String jsonSchemaString) {
        super(Phase.RECEIVE);
        this.jsonSchemaString = jsonSchemaString;
    }

    /**
     * Captures an incoming SOAP Message and validates it against a JSON Schema.
     *
     * @param message
     *          the soap message
     */
    @Override
    public void handleMessage(Message message) {
        this.log.info("Starting SOAP Interceptor");
        // Get the message bytes content
        InputStream in = message.getContent(InputStream.class);

        // Evade validation check if wsdl query param exists
        Object param = message.getContextualProperty(Message.QUERY_STRING);
        if (!Objects.isNull(param) && StringUtils.equals(param.toString(), WSDL_QUERY_PARAM)) {
            this.log.info("Ending SOAP Interceptor. WSDL URI won't be intercepted.");
            return;
        }

        try {
            // Get the message body into payload
            byte[] payload = IOUtils.readBytesFromStream(in);

            // Convert byte array to String
            String payloadString = new String(payload, StandardCharsets.UTF_8);

            this.log.debug("Payload String for validation:\n {}", payloadString);

            // Parse XML SOAP message into a JSONObject
            JSONObject jsonToValidate = parseXmlToJson(payloadString);

            // JsonNode mapping
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonForValidation = objectMapper.readTree(jsonToValidate.toString());

            // Json Schema build
            StringBuilder jsonSchemaBuilder = new StringBuilder();
            jsonSchemaBuilder.append(this.jsonSchemaString);

            // Validate JsonNode against Json Schema
            JsonValidationTools jsonValidationTools = new JsonValidationTools(jsonSchemaBuilder);
            jsonValidationTools.validateJsonNode(jsonForValidation, null);

            // Set the InputStream with the non-consumed byte array back into the message
            ByteArrayInputStream bin = new ByteArrayInputStream(payload);
            message.setContent(InputStream.class, bin);

        } catch (Exception e) {
            handleException(e);
        }
        this.log.info("Ending SOAP Interceptor");
    }

    /**
     * Parse xml to JSONObject.
     *
     * @param xml
     *         the xml
     * @return the json object
     * @throws Exception
     *         the exception
     */
    private JSONObject parseXmlToJson(String xml) throws Exception {
        if (StringUtils.isEmpty(xml)) {
            throw new Exception("Empty XML String for parsing to JSON");
        }
        JSONObject jsonObjectBody = XML.toJSONObject(xml);
        JSONObject cleanedJson = removeAttributes(jsonObjectBody);
        JSONObject jsonObject = cleanedJson.getJSONObject(SOAP_ENVELOPE).getJSONObject(SOAP_BODY);
        jsonObject = (JSONObject) jsonObject.get(jsonObject.keys().next());

        return jsonObject;
    }

    /**
     * Handle exception.
     *
     * @param e
     *         the e
     */
    private void handleException(Exception e) {
        this.log.error("Starting handle exceptions in SoapValidationInterceptor");
        if (e instanceof SOAPException || e instanceof IOException || e instanceof TransformerException) {
            this.log.error("SOAP message processing error", e);
            throw new Fault(new Exception("SOAP message processing error", e));
        } else if (e instanceof JsonValidationFailedException) {
            this.log.error("SOAP Json Validation failed", e);
            throw new Fault(new JsonValidationFailedException(((JsonValidationFailedException) e).getValidationMessages()));
        } else {
            this.log.error("Unexpected error during SOAP message validation", e);
            throw new RuntimeException(e);
        }
    }

    private static JSONObject removeAttributes(JSONObject jsonObject) {
        JSONObject result = new JSONObject();

        for (String key : jsonObject.keySet()) {
            Object value = jsonObject.get(key);

            if (value instanceof JSONObject) {
                JSONObject nestedObject = (JSONObject) value;

                // Si el objeto contiene una clave "content", dejamos solo esa clave
                if (nestedObject.has("content")) {
                    result.put(key, nestedObject.get("content"));
                } else {
                    // Recursión para objetos anidados
                    result.put(key, removeAttributes(nestedObject));
                }
            } else {
                // Mantener valores simples (no objetos)
                result.put(key, value);
            }
        }

        return result;
    }
}
