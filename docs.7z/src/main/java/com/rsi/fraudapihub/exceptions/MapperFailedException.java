package com.rsi.fraudapihub.exceptions;

/**
 * The type Mapper failed exception.
 */
public class MapperFailedException extends RuntimeException {

    /**
     * Instantiates a new Mapper failed exception.
     *
     * @param message
     *         the message
     */
    public MapperFailedException(String message) {
        super(message);
    }

    /**
     * Instantiates a new Mapper failed exception.
     *
     * @param message
     *         the message
     * @param cause
     *         the cause
     */
    public MapperFailedException(String message, Throwable cause) {
        super(message, cause);
    }
}

