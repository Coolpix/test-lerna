package com.rsi.fraudapihub.exceptions;

import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import lombok.Getter;
import lombok.Setter;

/**
 * The type Engine time out exception.
 *
 * @author Miguel Alonso Felipe
 */
@Setter
@Getter
public class EngineTimeOutException extends RuntimeException {

    private String message;
    private String operationRequestID;
    private AntifraudEngineService.MotorInfoLoaded motorInfoLoaded;

    /**
     * Instantiates a new Engine time out exception.
     *
     * @param message
     *         the message
     * @param operationRequestID
     *         the operation request id
     * @param motorInfoLoaded
     *         the motor info
     */
    public EngineTimeOutException(String message, String operationRequestID, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded) {
        this.message = message;
        this.motorInfoLoaded = motorInfoLoaded;
        this.operationRequestID = operationRequestID;
    }

    @Override
    public String getMessage() {
        return String.format("Error code: %s - %s", operationRequestID, message);
    }
}
