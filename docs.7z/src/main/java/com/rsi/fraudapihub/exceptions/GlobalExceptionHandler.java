package com.rsi.fraudapihub.exceptions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsi.fraudapihub.utils.constants.ResponseConstants;
import com.rsi.fraudapihub.utils.dto.base.ErrorResponse;
import com.rsi.fraudapihub.utils.dto.base.ResponseCode;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.schema.validation.JsonSchemaLoadingFailedException;
import com.rsi.schema.validation.JsonValidationFailedException;
import org.apache.cxf.interceptor.Fault;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * The type Global exception handler.
 *
 * @author Miguel Alonso Felipe
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The Object mapper.
     */
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Handle all exceptions response entity.
     *
     * @param ex
     *         the ex
     * @return the response entity
     * @throws IOException
     *         the io exception
     */
    @ExceptionHandler({Exception.class, Fault.class, RuntimeException.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Object> handleAllExceptions(
            Exception ex) throws IOException {

        this.log.error("Method handleAllExceptions for unhandled Exception Class: {} with message: {}", ex.getClass().getName(), ex.getMessage());

        String modifiedBodyJson = buildErrorResponse(
                ResponseConstants.DEFAULT_ERROR_CODE,
                ResponseConstants.DEFAULT_ERROR_MESSAGE,
                ResponseConstants.DEFAULT_ERROR_SOLUTION
        );

        return new ResponseEntity<>(modifiedBodyJson, getBasicHttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handle engine time out exception response entity.
     *
     * @param ex
     *         the ex
     * @return the response entity
     * @throws IOException
     *         the io exception
     */
    @ExceptionHandler(EngineTimeOutException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Object> handleEngineTimeOutException(
            EngineTimeOutException ex) throws IOException {

        this.log.error("Method handleEngineTimeOutException with message: {}", ex.getMessage());

        String modifiedBodyJson = buildErrorResponse(
                ResponseConstants.CONNECTION_ENGINE_ERROR_CODE,
                ResponseConstants.CONNECTION_ENGINE_ERROR_MESSAGE,
                "Revisar el ID operación: " + ex.getOperationRequestID() + ", Motor: " + ex.getMotorInfoLoaded().getCodigoMotor()
        );

        return new ResponseEntity<>(modifiedBodyJson, getBasicHttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handle mapper failed exception response entity.
     *
     * @param ex
     *         the ex
     * @return the response entity
     * @throws IOException
     *         the io exception
     */
    @ExceptionHandler(MapperFailedException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Object> handleMapperFailedException(
            MapperFailedException ex) throws IOException {

        this.log.error("Method handleMapperFailedException with message: {}", ex.getMessage());

        String modifiedBodyJson = buildErrorResponse(
                ResponseConstants.REQUEST_MAPPING_ERROR_CODE,
                ResponseConstants.REQUEST_MAPPING_ERROR_MESSAGE,
                ResponseConstants.REQUEST_MAPPING_ERROR_SOLUTION
        );

        return new ResponseEntity<>(modifiedBodyJson, getBasicHttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handle json validation failed exception response entity.
     *
     * @param ex
     *         the ex
     * @return the response entity
     * @throws IOException
     *         the io exception
     */
    @ExceptionHandler(JsonValidationFailedException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> handleJsonValidationFailedException(
            JsonValidationFailedException ex
    ) throws IOException {

        this.log.error("Method handleJsonValidationFailedException with message: {}", ex.getMessage());

        String modifiedBodyJson = buildErrorResponse(
                ResponseConstants.MANDATORY_FIELDS_LACK_ERROR_CODE,
                ex.getValidationMessages().toString(),
                ResponseConstants.MANDATORY_FIELDS_LACK_ERROR_SOLUTION
        );

        return new ResponseEntity<>(modifiedBodyJson, getBasicHttpHeaders(), HttpStatus.BAD_REQUEST);
    }

    /**
     * Handle json schema loading failed exception response entity.
     *
     * @param ex
     *         the ex
     * @return the response entity
     * @throws IOException
     *         the io exception
     */
    @ExceptionHandler(JsonSchemaLoadingFailedException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Object> handleJsonSchemaLoadingFailedException(
            JsonSchemaLoadingFailedException ex
    ) throws IOException {

        this.log.error("Method handleJsonSchemaLoadingFailedException with message: {}", ex.getMessage());

        String modifiedBodyJson = buildErrorResponse(
                ResponseConstants.MANDATORY_FIELDS_LACK_ERROR_CODE,
                "JSON Schema de validación incorrecto.",
                "Revise los campos, la sintaxis o que la versión del JSON Schema coincide con la de la documentación."
        );

        return new ResponseEntity<>(modifiedBodyJson, getBasicHttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Build error response string.
     *
     * @param errorCode
     *         the error code
     * @param errorMessage
     *         the error message
     * @param errorSolution
     *         the error solution
     * @return the string
     * @throws JsonProcessingException
     *         the json processing exception
     */
    private String buildErrorResponse(String errorCode, String errorMessage, String errorSolution) throws JsonProcessingException {
        ErrorResponse errorResponse = new ErrorResponse(
                errorCode,
                errorMessage,
                errorSolution);
        OperationResponseDto operationResponseDto = buildBaseResponse(errorResponse);
        return objectMapper.writeValueAsString(operationResponseDto);
    }

    /**
     * Build base response.
     *
     * @param errorResponse
     *            the error response
     * @return the base response
     */
    private OperationResponseDto buildBaseResponse(ErrorResponse errorResponse) {
        OperationResponseDto operationResponseDto = new OperationResponseDto();
        operationResponseDto.setCodigoRetorno(ResponseCode.ERROR.getResponseCode());
        operationResponseDto.setError(errorResponse);
        return operationResponseDto;
    }

    /**
     * Get basic http headers.
     *
     * @return the http headers
     */
    private HttpHeaders getBasicHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("charset", StandardCharsets.UTF_8.name());
        return headers;
    }

}




