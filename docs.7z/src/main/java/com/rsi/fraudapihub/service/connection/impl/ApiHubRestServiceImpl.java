package com.rsi.fraudapihub.service.connection.impl;

import com.rsi.fraudapihub.manager.connection.ApiHubRestOperationManager;
import com.rsi.fraudapihub.service.connection.ApiHubRestService;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferWebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.response.engine.cleafy.CleafyResponseDto;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.EE_O_ComprobarFraude;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * The type Api hub rest service.
 *
 * @author Miguel Alonso Felipe
 */
@Service
public class ApiHubRestServiceImpl implements ApiHubRestService {

    private final ApiHubRestOperationManager apiHubRestManager;

    /**
     * Instantiates a new Api hub rest service.
     *
     * @param apiHubRestManager
     *         the api hub rest manager
     */
    @Autowired
    public ApiHubRestServiceImpl(ApiHubRestOperationManager apiHubRestManager) {
        this.apiHubRestManager = apiHubRestManager;
    }

    public ResponseEntity<SaferResponseDTO> sendPostRequestToSaferPayments(String uri, String body, String messageType, String correlationId, String requestType) {
        return this.apiHubRestManager.sendPostRequestToSaferPayments(uri, body, messageType, correlationId, requestType);
    }

    public ResponseEntity<EE_O_ComprobarFraude> sendPostRequestToTacticalAndSVO(String uri, String SVOUri, String body, String idOperacionBE) {
        return this.apiHubRestManager.sendPostRequestToTacticalAndSVO(uri, SVOUri, body, idOperacionBE);
    }

    @Override
    public ResponseEntity<SaferWebHookRequestDto> sendPostRequestToCleafy(String uri, String body) {
        return this.apiHubRestManager.sendPostRequestToCleafy(uri, body);
    }
}
