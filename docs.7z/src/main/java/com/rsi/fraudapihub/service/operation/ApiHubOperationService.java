package com.rsi.fraudapihub.service.operation;

import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.PersonRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.WebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import org.springframework.http.ResponseEntity;

import java.util.concurrent.CompletableFuture;

/**
 * The interface Api hub operation service.
 *
 * @author Miguel Alonso Felipe
 */
public interface ApiHubOperationService {

    /**
     * Create operation for soap validation t.
     *
     * @param requestDto
     *         the request dto
     * @return the t
     */
    OperationResponseDto createOperationForSoapValidation(OperationRequestDto requestDto) throws Exception;

    /**
     * Create operation for rest validation completable future.
     *
     * @param requestDto
     *         the request dto
     * @return the completable future
     */
    CompletableFuture<ResponseEntity<OperationResponseDto>> createOperationForRestValidation(OperationRequestDto requestDto) throws Exception;

    /**
     * Create person operation for rest validation completable future.
     *
     * @param requestDto
     *         the request dto
     * @return the completable future
     */
    CompletableFuture<ResponseEntity<String>> createPersonOperationForRestValidation(PersonRequestDto requestDto) throws InterruptedException;

    /**
     * Create person operation for rest validation completable future.
     *
     * @param requestDto
     *         the request dto
     * @return the completable future
     */
    CompletableFuture<ResponseEntity<WebHookResponseDto>> createWebHookOperationForRestValidation(WebHookRequestDto requestDto) throws Exception;

}
