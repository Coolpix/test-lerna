package com.rsi.fraudapihub.service.operation.impl;

import com.rsi.fraudapihub.manager.operation.operations.operations.ApiHubOperationManager;
import com.rsi.fraudapihub.manager.operation.pbc.ApiHubPersonManager;
import com.rsi.fraudapihub.manager.operation.operations.devices.ApiHubWebHookManager;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.service.operation.ApiHubOperationService;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.PersonRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.WebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

/**
 * The type Api hub operation service.
 *
 * @param <T>
 *         the type parameter
 * @author Miguel Alonso Felipe
 */
@Service
public class ApiHubOperationServiceImpl<T> implements ApiHubOperationService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final ApiHubOperationManager apiHubOperationManager;

    private final ApiHubPersonManager<T> apiHubPersonManager;

    private final ApiHubWebHookManager apiHubWebHookManager;

    private final AntifraudEngineService antifraudEngineService;

    /**
     * Instantiates a new Api hub operation service.
     *
     * @param apiHubOperationManager
     *         the api hub operation manager
     * @param apiHubPersonManager
     *         the api hub person manager
     * @param apiHubWebHookManager
     *         the api hub webhook manager
     * @param antifraudEngineService
     *         the antifraude engine service
     */


    @Autowired
    public ApiHubOperationServiceImpl(
            ApiHubOperationManager apiHubOperationManager,
            ApiHubPersonManager<T> apiHubPersonManager,
            ApiHubWebHookManager apiHubWebHookManager,
            AntifraudEngineService antifraudEngineService
    ) {
        this.apiHubOperationManager = apiHubOperationManager;
        this.apiHubPersonManager = apiHubPersonManager;
        this.apiHubWebHookManager = apiHubWebHookManager;
        this.antifraudEngineService = antifraudEngineService;
    }

    public CompletableFuture<ResponseEntity<OperationResponseDto>> createOperationForRestValidation(OperationRequestDto dto) throws Exception {
        AntifraudEngineService.MotorInfoLoaded motorInfoLoaded = getMotorInfo(dto);
        return apiHubOperationManager.createOperationForRestValidation(dto, motorInfoLoaded);
    }

    public OperationResponseDto createOperationForSoapValidation(OperationRequestDto dto) throws Exception {
        AntifraudEngineService.MotorInfoLoaded motorInfoLoaded = getMotorInfo(dto);
        return apiHubOperationManager.createOperationForSoapValidation(dto, motorInfoLoaded);
    }

    public CompletableFuture<ResponseEntity<String>> createPersonOperationForRestValidation(PersonRequestDto dto) throws InterruptedException {
        return apiHubPersonManager.createOperationForRestValidation(dto);
    }

    public CompletableFuture<ResponseEntity<WebHookResponseDto>> createWebHookOperationForRestValidation(WebHookRequestDto requestDto) throws Exception {
        return apiHubWebHookManager.createOperationForRestValidation(requestDto);
    }

    private AntifraudEngineService.MotorInfoLoaded getMotorInfo(OperationRequestDto dto) throws Exception {
        AntifraudEngineService.MotorInfoLoaded motorInfoLoaded = antifraudEngineService.getEngines(dto.getCodigoEntidad(), dto.getTipoOperacion(), dto.getIdCanal());
        this.log.info("Motor seleccionado: código: {} - nombre: {}", motorInfoLoaded.getCodigoMotor(), antifraudEngineService.getEngineInfoByCodigoMotor(motorInfoLoaded.getCodigoMotor().toString()).getNombreMotor());
        return motorInfoLoaded;
    }
}
