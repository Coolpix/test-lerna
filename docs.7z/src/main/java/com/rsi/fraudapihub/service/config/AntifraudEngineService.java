package com.rsi.fraudapihub.service.config;

import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.configuration.hub.ApiRoutingConfig;
import com.rsi.fraudapihub.utils.dto.response.config.ConfigResponseDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 */
@Service
public class AntifraudEngineService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final AntifraudEngineConfiguration config;
    private final ApiRoutingConfig apiRoutingConfig;

    public AntifraudEngineService(
            AntifraudEngineConfiguration config,
            ApiRoutingConfig apiRoutingConfig
    ) {
        this.config = config;
        this.apiRoutingConfig = apiRoutingConfig;
    }

    public MotorInfoLoaded getEngines(String entidad, String operativa, String canal) throws Exception {
        if (StringUtils.isBlank(entidad) || StringUtils.isBlank(operativa) || StringUtils.isBlank(canal)) {
            this.log.error("Parameters: entidad - {}, operativa - {} and canal - {} are mandatory.", entidad, operativa, canal);
            throw new Exception("Parameters: entidad, operativa and canal are mandatory.");
        }
        return apiRoutingConfig.getMappings().stream()
                .filter(c -> checkCondition(entidad, operativa, canal, c))
                .map(c -> new MotorInfoLoaded(c.getMotores().stream()
                        .map(this::getEngineInfoByCodigoMotor)
                        .toList(),
                        c.getMapeo()))
                .findFirst()
                .orElse(new MotorInfoLoaded(List.of(new AntifraudEngineConfiguration.InfoMotorConfig("9999", "Motor Genérico", "")), "Mapeo Generico"));
    }

    private static boolean checkCondition(String entidad, String operativa, String canal, ApiRoutingConfig.Mapping c) {
        return c.getCondition().getEntidad().contains(entidad)
                && c.getCondition().getOperativa().contains(operativa)
                && c.getCondition().getCanal().contains(canal);
    }

    public AntifraudEngineConfiguration.InfoMotorConfig getEngineInfoByCodigoMotor(String codigoMotor) {
        return config.getMotores().stream()
                .filter(c -> c.getMotor().getCodigoMotor().equals(codigoMotor))
                .map(c -> new AntifraudEngineConfiguration.InfoMotorConfig(c.getMotor().getCodigoMotor(), c.getMotor().getNombreMotor(), c.getMotor().getUrl()))
                .findFirst()
                .orElse(new AntifraudEngineConfiguration.InfoMotorConfig("9999", "Motor Genérico", ""));
    }

    public AntifraudEngineConfiguration.InfoCanal getChannelById(String idCanal) throws Exception {
        if (StringUtils.isBlank(idCanal)) {
            this.log.error("Parameter idCanal - {} is mandatory.", idCanal);
            throw new Exception("Parameter idCanal is mandatory.");
        }

        return config.getCanales().stream()
                .filter(c -> c.getCanal().getIdCanal().equals(idCanal))
                .map(c -> new AntifraudEngineConfiguration.InfoCanal(c.getCanal().getIdCanal(), c.getCanal().getNombreCanal()))
                .findFirst()
                .orElse(new AntifraudEngineConfiguration.InfoCanal("9999", "Canal Genérico"));
    }

    public Map<String, List<String>> getApiForInput(String canal, String entidad, String operativa) {
        return apiRoutingConfig.getMappings().stream()
                .filter(mapping -> mapping.getCondition().getCanal().contains(canal) &&
                        mapping.getCondition().getEntidad().contains(entidad) &&
                        mapping.getCondition().getOperativa().contains(operativa))
                .map(mapping -> Map.entry(mapping.getMapeo(), mapping.getMotores())) // Crear un par clave-valor
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    public ConfigResponseDto checkEntidadExists(String entidad) throws Exception {
        if (StringUtils.isBlank(entidad)) {
            this.log.error("Parameters: entidad - {} is mandatory.", entidad);
            throw new Exception("Parameters: entidad is mandatory.");
        }
        return apiRoutingConfig.getMappings().stream()
                .filter(c -> c.getCondition().getEntidad().contains(entidad))
                .map(c -> new ConfigResponseDto(true))
                .findFirst()
                .orElse(new ConfigResponseDto(false));
    }

    /**
     *
     */
    @Data
    @AllArgsConstructor
    public static class MotorInfoLoaded {
        private List<AntifraudEngineConfiguration.InfoMotorConfig> codigoMotor;
        private String mapeo;
    }
}
