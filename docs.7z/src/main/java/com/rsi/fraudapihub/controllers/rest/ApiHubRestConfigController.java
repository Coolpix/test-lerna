package com.rsi.fraudapihub.controllers.rest;

import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.response.config.ConfigResponseDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * The type API HUB rest config controller.
 *
 * @author Sergio Alonso
 */
@RestController
public class ApiHubRestConfigController {

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The API HUB Config Service.
     */
    private final AntifraudEngineService antifraudEngineService;

    /**
     * Instantiates a new Api hub rest config controller.
     *
     * @param antifraudEngineService
     *         the api hub config service
     */
    public ApiHubRestConfigController(AntifraudEngineService antifraudEngineService) {
        this.antifraudEngineService = antifraudEngineService;
    }

    /**
     * Get Channel Name by Channel ID.
     *
     * @param idCanal
     *         the idCanal
     * @return the channel name
     */
    @GetMapping(value = "/config/getChannelNameById/{idCanal}", produces = MediaType.APPLICATION_JSON_VALUE)
    public AntifraudEngineConfiguration.InfoCanal getChannelNameById(@PathVariable String idCanal) throws Exception {
        this.log.info("Starting getChannelNameById for channel: {}", idCanal);
        AntifraudEngineConfiguration.InfoCanal response = this.antifraudEngineService.getChannelById(idCanal);
        this.log.info("Ending getChannelNameById for channel: {}", idCanal);
        return response;
    }

    /**
     * Get Entidad is Config.
     *
     * @param entidad
     *         the entidad
     * @return boolean if entidad exists
     */
    @GetMapping(value = "/config/existsEntidad/{entidad}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ConfigResponseDto existsEntidad(@PathVariable String entidad) throws Exception {
        this.log.info("Starting existsEntidad for entidad: {}", entidad);
        ConfigResponseDto response = this.antifraudEngineService.checkEntidadExists(entidad);
        this.log.info("Ending existsEntidad for entidad: {}", entidad);
        return response;
    }
}
