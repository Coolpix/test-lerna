package com.rsi.fraudapihub.controllers.rest;

import com.rsi.fraudapihub.service.operation.ApiHubOperationService;
import com.rsi.fraudapihub.utils.dto.request.operation.WebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.CompletableFuture;

/**
 * The type API HUB web hook rest controller.
 *
 * @author Sergio Alonso
 */
@RestController
public class ApiHubRestWebHookController {

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The API HUB Service.
     */
    private final ApiHubOperationService apiHubOperationService;

    /**
     * Instantiates a new Api hub rest web hook controller.
     *
     * @param apiHubOperationService
     *         the api hub operation service
     */
    @Autowired
    public ApiHubRestWebHookController(ApiHubOperationService apiHubOperationService) {
        this.apiHubOperationService = apiHubOperationService;
    }

    /**
     * Create operation for validation.
     *
     * @param request
     *         the request
     * @return the completable future
     */
    @PostMapping(value = "/webhookcleafy", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    //TODO: Crear JSON SChema
    public CompletableFuture<ResponseEntity<WebHookResponseDto>> createWebHookOperationForValidation(/*@ValidJson("#{@Schemas.webhookSchema}")*/ @RequestBody WebHookRequestDto request) throws Exception {
        this.log.info("Starting createWebHookOperationForValidation for request: {}", StructuredArguments.keyValue("request", request));
        CompletableFuture<ResponseEntity<WebHookResponseDto>> response = this.apiHubOperationService.createWebHookOperationForRestValidation(request);
        this.log.info("Ending createWebHookOperationForValidation for request: {}", StructuredArguments.keyValue("request", request));
        return response;
    }
}
