package com.rsi.fraudapihub.controllers.rest;

import com.rsi.fraudapihub.service.operation.ApiHubOperationService;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.schema.validation.ValidJson;
import net.logstash.logback.argument.StructuredArguments;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.CompletableFuture;

/**
 * The type API HUB rest controller.
 *
 * @author Miguel Alonso Felipe
 */
@RestController
public class ApiHubRestOperationController {

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The API HUB Service.
     */
    private final ApiHubOperationService apiHubOperationService;

    /**
     * Instantiates a new Api hub rest operation controller.
     *
     * @param apiHubOperationService
     *         the api hub operation service
     */
    @Autowired
    public ApiHubRestOperationController(
            ApiHubOperationService apiHubOperationService
    ) {
        this.apiHubOperationService = apiHubOperationService;
    }

    /**
     * Create operation for validation.
     *
     * @param request
     *         the request
     * @return the completable future
     */
    @PostMapping(value = "/antifraudeHubOperacEconomicas", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public CompletableFuture<ResponseEntity<OperationResponseDto>> createOperationForValidation(@ValidJson("#{@Schemas.operationSchema}") OperationRequestDto request) throws Exception {
        this.log.info("Starting createOperationForValidation for request: {}", StructuredArguments.keyValue("request", request));
        CompletableFuture<ResponseEntity<OperationResponseDto>> response = this.apiHubOperationService.createOperationForRestValidation(request);
        this.log.info("Ending createOperationForValidation for request: {}", StructuredArguments.keyValue("request", request));
        return response;
    }

    /**
     * Ping.
     *
     * @return the response entity
     */
    @GetMapping("/ping")
    public ResponseEntity<String> ping(@RequestBody Object object) throws Exception {
        //throw new Exception("PONG");
        return new ResponseEntity<>("PONG", HttpStatus.OK);
    }

}

