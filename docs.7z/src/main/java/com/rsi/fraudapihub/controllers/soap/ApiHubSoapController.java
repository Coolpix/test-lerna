package com.rsi.fraudapihub.controllers.soap;

import com.rsi.fraudapihub.service.operation.ApiHubOperationService;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.validation.Valid;
import jakarta.xml.bind.annotation.XmlElement;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * The API HUB SOAP controller.
 *
 * @author Miguel Alonso Felipe
 */
@Service("apiHubSoapController")
@WebService(name = "antifraudeHubOperacEconomicas", targetNamespace = "http://www.ruralvia.com/antifraudeHubOperacEconomicas", serviceName = "antifraudeHubOperacEconomicas")
public class ApiHubSoapController {

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The constant URN.
     */
    private static final String URN = "urn:";

    /**
     * The constant CREATE_OPERATION_FOR_VALIDATION.
     */
    private static final String CREATE_OPERATION_FOR_VALIDATION = "antifraudeHubOperacEconomicas";

    /**
     * The API HUB Service.
     */
    private final ApiHubOperationService apiHubOperationService;

    /**
     * Instantiates a new API HUB SOAP controller.
     *
     * @param apiHubOperationService
     *         the api hub common controller
     */
    @Autowired
    public ApiHubSoapController(ApiHubOperationService apiHubOperationService) {
        this.apiHubOperationService = apiHubOperationService;
    }

    /**
     * Create operation for validation completable future.
     *
     * @param request
     *         the request
     * @return the completable future
     */
    @WebMethod(operationName = CREATE_OPERATION_FOR_VALIDATION, action = URN + CREATE_OPERATION_FOR_VALIDATION)
    public OperationResponseDto createOperationForValidation(
            @XmlElement(required = true) @WebParam(name = "EE_I_AltaOperacionFraude") @Valid OperationRequestDto request) throws Exception {
        this.log.info("Starting createOperationForValidation for request: {}", StructuredArguments.keyValue("request", request));

        return this.apiHubOperationService.createOperationForSoapValidation(request);
    }
}
