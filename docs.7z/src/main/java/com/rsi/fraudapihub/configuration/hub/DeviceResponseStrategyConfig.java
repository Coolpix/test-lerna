package com.rsi.fraudapihub.configuration.hub;

import com.rsi.fraudapihub.handler.responseStrategy.cleafy.impl.CleafyEngineResponseStrategy;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DeviceResponseStrategyConfig {

    @Bean
    public CleafyEngineResponseStrategy cleafyResponseStrategy(OperationMapper operationMapper) {
        return new CleafyEngineResponseStrategy(operationMapper);
    }
}
