package com.rsi.fraudapihub.configuration.hub;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 *
 */
@Configuration
@ConfigurationProperties(prefix = "diccionarios")
@Data
public class AntifraudEngineConfiguration {

    private List<Canal> canales;
    private List<MotorConfig> motores;

    /**
     *
     */
    @Data
    @AllArgsConstructor
    public static class Canal {
        private InfoCanal canal;
    }

    /**
     *
     */
    @Data
    @AllArgsConstructor
    public static class MotorConfig {
        private InfoMotorConfig motor;
    }

    /**
     *
     */
    @Data
    @AllArgsConstructor
    public static class InfoCanal {
        private String idCanal;
        private String nombreCanal;
    }

    /**
     *
     */
    @Data
    @AllArgsConstructor
    public static class InfoMotorConfig {
        private String codigoMotor;
        private String nombreMotor;
        private String url;
    }
}

