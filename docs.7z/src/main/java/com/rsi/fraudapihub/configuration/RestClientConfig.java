package com.rsi.fraudapihub.configuration;

import org.springframework.boot.web.client.ClientHttpRequestFactories;
import org.springframework.boot.web.client.ClientHttpRequestFactorySettings;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.web.client.RestClient;
import java.time.Duration;

/**
 * The type Rest client config.
 *
 * @author Miguel Alonso Felipe
 */
@Configuration
public class RestClientConfig {

    /**
     * Custom rest client rest client.
     *
     * @return the rest client
     */
    @Bean(name = "customRestClient")
    public RestClient customRestClient() {
        return RestClient.builder()
                .requestFactory(clientHttpRequestFactory())
                .build();
    }

    /**
     * Client http request factory client http request factory.
     *
     * @return the client http request factory
     */
    @Bean
    public ClientHttpRequestFactory clientHttpRequestFactory() {
        ClientHttpRequestFactorySettings settings = ClientHttpRequestFactorySettings.DEFAULTS
                .withConnectTimeout(Duration.ofMillis(10000))
                .withReadTimeout(Duration.ofMillis(10000));
        return ClientHttpRequestFactories.get(settings);
    }
}

