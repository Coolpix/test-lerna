package com.rsi.fraudapihub.configuration.hub;

import com.rsi.fraudapihub.handler.requestStrategy.cleafy.impl.CleafyRequestStrategy;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DeviceRequestStrategyConfig {

    @Bean
    public CleafyRequestStrategy cleafyRequestStrategy(OperationMapper operationMapper) {
        return new CleafyRequestStrategy(operationMapper);
    }
}
