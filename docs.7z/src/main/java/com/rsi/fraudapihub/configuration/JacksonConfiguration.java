package com.rsi.fraudapihub.configuration;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * The type Jackson configuration.
 *
 * @author Miguel Alonso
 */
@Configuration
public class JacksonConfiguration {

    /**
     * Object mapper. This ObjectMapper is used to wrap DTOs.
     *
     * @return the object mapper
     */
    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        final ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(MapperFeature.DEFAULT_VIEW_INCLUSION, true);
        // mapper.enable(DeserializationFeature.UNWRAP_ROOT_VALUE);
        // mapper.enable(SerializationFeature.WRAP_ROOT_VALUE);
        return mapper;
    }
}
