package com.rsi.fraudapihub.configuration;

import com.rsi.fraudapihub.controllers.soap.ApiHubSoapController;
import com.rsi.fraudapihub.interceptors.SoapValidationInterceptor;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import jakarta.xml.ws.Endpoint;

/**
 * Class to load the configuration into the SOAP controller.
 *
 * @author Miguel Alonso Felipe
 */
@Configuration
public class SoapConfiguration {

    @Value("${params.schema.operation}")
    public String jsonSchemaString;

    /**
     * The Cxf servlet url mapping.
     */
    private static final String CXF_SERVLET_URL_MAPPING = "/wsdl/*";
    /**
     * The Cxf servlet name.
     */
    private static final String CXF_SERVLET_NAME = "cfxdispatcher";

    /**
     * The constant API_HUB_ENDPOINT_URL.
     */
    private static final String API_HUB_ENDPOINT_URL = "/antifraudeHubOperacEconomicas";

    /**
     * The constant API_HUB_SOAP_CONTROLLER.
     */
    private static final String API_HUB_SOAP_CONTROLLER = "apiHubSoapController";

    /**
     * Cxf.
     *
     * @return the spring bus
     */
    @Bean
    public SpringBus cxf() {
        return new SpringBus();
    }

    /**
     * Cxf servlet.
     *
     * @return the servlet registration bean
     */
    @Bean
    public ServletRegistrationBean<CXFServlet> cxfServlet() {
        final ServletRegistrationBean<CXFServlet> cxf = new ServletRegistrationBean<>(new CXFServlet(), CXF_SERVLET_URL_MAPPING);
        cxf.setName(CXF_SERVLET_NAME);
        return cxf;
    }

    /**
     * Accounts movements endpoint endpoint.
     *
     * @param apiHubSoapController
     *         the api hub soap controller
     * @return the endpoint
     */
    @Bean
    @DependsOn(API_HUB_SOAP_CONTROLLER)
    public Endpoint createOperationEndpoint(final ApiHubSoapController apiHubSoapController) {
        final EndpointImpl endpoint = new EndpointImpl(cxf(), apiHubSoapController);
        endpoint.getInInterceptors().add(new SoapValidationInterceptor(jsonSchemaString));
        endpoint.publish(API_HUB_ENDPOINT_URL);
        return endpoint;
    }
}

