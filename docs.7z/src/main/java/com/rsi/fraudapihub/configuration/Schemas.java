package com.rsi.fraudapihub.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * The type Schemas.
 *
 * @author Miguel Alonso Felipe
 */
@Configuration
@RefreshScope
public class Schemas {

    /**
     * The Operation schema.
     */
    @Value("${params.schema.operation}")
    public String operationSchema;

    /**
     * The Operation 2 schema.
     */
    @Value("${params.schema.person}")
    public String personSchema;
}


