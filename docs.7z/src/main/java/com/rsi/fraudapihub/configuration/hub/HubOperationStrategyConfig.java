package com.rsi.fraudapihub.configuration.hub;

import com.rsi.fraudapihub.handler.engineOperations.cleafy.impl.CleafyEngineOperationsStrategy;
import com.rsi.fraudapihub.handler.engineOperations.operations.impl.DefaultEngineOperationsStrategy;
import com.rsi.fraudapihub.handler.engineOperations.operations.impl.SaferEngineOperationsStrategy;
import com.rsi.fraudapihub.handler.engineOperations.operations.impl.TacticalEngineOperationsStrategy;
import com.rsi.fraudapihub.handler.requestStrategy.operations.OperationsRequestHandler;
import com.rsi.fraudapihub.handler.requestStrategy.cleafy.DeviceRequestHandler;
import com.rsi.fraudapihub.manager.operation.engines.operations.ApiHubFunctionsManager;
import com.rsi.fraudapihub.manager.operation.engines.devices.CleafyFunctionsManager;
import com.rsi.fraudapihub.utils.dto.request.engine.cleafy.CleafyRequestDto;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferRequestDto;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferWebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.request.engine.tactical.EE_I_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.EE_O_ComprobarFraude;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HubOperationStrategyConfig {

    @Bean
    public SaferEngineOperationsStrategy saferOperationStrategy(
            @Qualifier("SaferEngineResponse") ApiHubFunctionsManager<SaferRequestDto, SaferResponseDTO> saferApiHubFunctionsManager,
            OperationsRequestHandler<SaferRequestDto> operationsRequestHandler
    ) {
        return new SaferEngineOperationsStrategy(
                saferApiHubFunctionsManager,
                operationsRequestHandler
        );
    }

    @Bean
    public TacticalEngineOperationsStrategy tacticalOperationStrategy(
            @Qualifier("TacticalEngineResponse") ApiHubFunctionsManager<EE_I_ComprobarFraude, EE_O_ComprobarFraude> tacticalApiHubFunctionsManager,
            OperationsRequestHandler<EE_I_ComprobarFraude> operationsRequestHandler
    ) {
        return new TacticalEngineOperationsStrategy(
                tacticalApiHubFunctionsManager,
                operationsRequestHandler
        );
    }

    @Bean
    public CleafyEngineOperationsStrategy cleafyOperationStrategy(
            @Qualifier("CleafyEngineResponse") CleafyFunctionsManager<SaferWebHookRequestDto, SaferResponseDTO> cleafyFunctionsManager,
            DeviceRequestHandler<SaferWebHookRequestDto> deviceRequestHandler
    ) {
        return new CleafyEngineOperationsStrategy(
                cleafyFunctionsManager,
                deviceRequestHandler
        );
    }

    @Bean
    public DefaultEngineOperationsStrategy defaultOperationStrategy(
            OperationMapper operationMapper
    ) {
        return new DefaultEngineOperationsStrategy(
                operationMapper
        );
    }
}
