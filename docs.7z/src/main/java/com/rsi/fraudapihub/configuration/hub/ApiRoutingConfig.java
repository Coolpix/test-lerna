package com.rsi.fraudapihub.configuration.hub;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConfigurationProperties(prefix = "api-routing")
@Data
public class ApiRoutingConfig {

    private List<Mapping> mappings;

    @Data
    public static class Mapping {
        private Condition condition;
        private List<String> motores;
        private String mapeo;
    }

    @Data
    public static class Condition {
        private List<String> entidad;
        private List<String> operativa;
        private List<String> canal;
    }
}

