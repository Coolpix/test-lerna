package com.rsi.fraudapihub.configuration.hub;

import com.rsi.fraudapihub.handler.requestStrategy.operations.impl.*;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OperationsRequestStrategyConfig {

    @Bean
    public BizumRequestStrategy bizumRequestStrategy(OperationMapper operationMapper) {
        return new BizumRequestStrategy(operationMapper);
    }

    @Bean
    public DefaultRequestStrategy defaultStrategy(OperationMapper operationMapper) {
        return new DefaultRequestStrategy(operationMapper);
    }

    @Bean
    public PSD2RequestStrategy psd2RequestStrategy(OperationMapper operationMapper) {
        return new PSD2RequestStrategy(operationMapper);
    }

    @Bean
    public TacticalRequestStrategy tacticalRequestStrategy(OperationMapper operationMapper) {
        return new TacticalRequestStrategy(operationMapper);
    }

    @Bean
    public TargetRequestStrategy targetRequestStrategy(OperationMapper operationMapper) {
        return new TargetRequestStrategy(operationMapper);
    }
}
