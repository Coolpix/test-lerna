package com.rsi.fraudapihub.configuration.hub;

import com.rsi.fraudapihub.handler.responseStrategy.operations.impl.DefaultResponseStrategy;
import com.rsi.fraudapihub.handler.responseStrategy.operations.impl.SaferEngineResponseStrategy;
import com.rsi.fraudapihub.handler.responseStrategy.operations.impl.TacticalEngineResponseStrategy;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OperationsReponseStrategyConfig {

    @Bean
    public SaferEngineResponseStrategy saferEngineResponseStrategy(OperationMapper operationMapper) {
        return new SaferEngineResponseStrategy(operationMapper);
    }

    @Bean
    public TacticalEngineResponseStrategy tacticalEngineResponseStrategy(OperationMapper operationMapper) {
        return new TacticalEngineResponseStrategy(operationMapper);
    }

    @Bean
    public DefaultResponseStrategy defaultResponseStrategy(OperationMapper operationMapper) {
        return new DefaultResponseStrategy(operationMapper);
    }
}
