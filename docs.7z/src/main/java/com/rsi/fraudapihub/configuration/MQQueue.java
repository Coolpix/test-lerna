package com.rsi.fraudapihub.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * The type Mq queue.
 *
 * @author Miguel Alonso Felipe
 */
@Configuration
@RefreshScope
public class MQQueue {

    /**
     * The Queue receiver.
     */
    @Value("${params.mq.queue.rx}")
    public String queueReceiver;
}
