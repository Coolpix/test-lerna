package com.rsi.fraudapihub.configuration;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * The type Application configuration.
 *
 * @author Miguel Alonso Felipe
 */
@Configuration
@ComponentScan({"com.rsi.schema.validation", "com.rsi.mqconnector", "com.rsi.starters.mapper", "com.rsi.fraudapihub"})
@EnableAsync
public class ApplicationConfiguration {

    /**
     * Schemas object to implement changes from config-repo in multiple JSON Schema configuration.
     *
     * @return the schemas
     */
    @Bean("Schemas")
    public Schemas schemas() {
        return new Schemas();
    }
}

