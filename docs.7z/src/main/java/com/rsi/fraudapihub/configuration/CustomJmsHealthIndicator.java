package com.rsi.fraudapihub.configuration;

import com.ibm.mq.jakarta.jms.MQQueueConnectionFactory;
import com.ibm.mq.jakarta.jms.MQTopicConnectionFactory;
import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.health.ConditionalOnEnabledHealthIndicator;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

/**
 * The type Custom jms health indicator.
 *
 * @author Miguel Alonso Felipe
 */
@Component
@ConditionalOnEnabledHealthIndicator("custom_connection_factory")
public class CustomJmsHealthIndicator extends AbstractHealthIndicator {

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final MQQueueConnectionFactory mqQueueConnectionFactory;
    private final MQTopicConnectionFactory mqTopicConnectionFactory;

    /**
     * Instantiates a new Custom jms health indicator.
     *
     * @param mqQueueConnectionFactory
     *         the mq queue connection factory
     * @param mqTopicConnectionFactory
     *         the mq topic connection factory
     */
    @Autowired
    public CustomJmsHealthIndicator(MQQueueConnectionFactory mqQueueConnectionFactory, MQTopicConnectionFactory mqTopicConnectionFactory) {
        super("Custom JMS health check failed");
        this.mqQueueConnectionFactory = mqQueueConnectionFactory;
        this.mqTopicConnectionFactory = mqTopicConnectionFactory;
    }

    @Override
    protected void doHealthCheck(Health.Builder builder) throws Exception {
        boolean isQueueConnectionHealthy = checkConnection("MQQueueConnectionFactory", mqQueueConnectionFactory, builder);
        boolean isTopicConnectionHealthy = checkConnection("MQTopicConnectionFactory", mqTopicConnectionFactory, builder);

        if (isQueueConnectionHealthy && isTopicConnectionHealthy) {
            builder.up();
        } else {
            builder.down().withDetail("summary", "One or more JMS connections failed");
        }
    }

    private boolean checkConnection(String connectionType, ConnectionFactory connectionFactory, Health.Builder builder) {
        try (Connection connection = connectionFactory.createConnection()) {
            connection.start();
            builder.withDetail(connectionType, "UP").withDetail(connectionType + "-provider", connection.getMetaData().getJMSProviderName());
            return true;
        } catch (JMSException e) {
            this.log.error(e.getMessage(), e);
            builder.withDetail(connectionType, "DOWN").withDetail(connectionType + "-error", e.getMessage());
            return false;
        }
    }
}
