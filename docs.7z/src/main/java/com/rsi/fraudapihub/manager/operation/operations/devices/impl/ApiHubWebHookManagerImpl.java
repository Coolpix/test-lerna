package com.rsi.fraudapihub.manager.operation.operations.devices.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.handler.engineOperations.cleafy.DeviceOperationsHandler;
import com.rsi.fraudapihub.handler.engineOperations.operations.EngineOperationsHandler;
import com.rsi.fraudapihub.manager.operation.operations.devices.ApiHubWebHookManager;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.request.hub.DeviceRequestContext;
import com.rsi.fraudapihub.utils.dto.request.hub.EnginesRequestContext;
import com.rsi.fraudapihub.utils.dto.request.operation.WebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import jakarta.jms.JMSException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * The Api hub web hook manager.
 *
 * @author Sergio Alonso
 */
@Service
@EnableJms
@RefreshScope
@SuppressWarnings("unchecked")
public class ApiHubWebHookManagerImpl implements ApiHubWebHookManager {

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The Futures map for REST responses.
     */
    private final ConcurrentHashMap<String, CompletableFuture<WebHookResponseDto>> futuresMapRest = new ConcurrentHashMap<>();

    /**
     * The Antifraude Engine Service
     */
    private final AntifraudEngineService antifraudEngineService;

    private final DeviceOperationsHandler deviceOperationsHandler;

    public ApiHubWebHookManagerImpl(
            AntifraudEngineService antifraudEngineService,
            DeviceOperationsHandler deviceOperationsHandler
    ) {
        this.antifraudEngineService = antifraudEngineService;
        this.deviceOperationsHandler = deviceOperationsHandler;
    }

    @Override
    public CompletableFuture<ResponseEntity<WebHookResponseDto>> createOperationForRestValidation(WebHookRequestDto requestDto) throws Exception {
        this.log.info("Webhook request desde controlador REST {}", requestDto);
        String correlationId = UUID.randomUUID().toString();

        CompletableFuture<WebHookResponseDto> future = new CompletableFuture<>();
        futuresMapRest.put(correlationId, future);

        try {
            getResponseFromEngine(requestDto, correlationId, future);

            return future.orTimeout(30, TimeUnit.SECONDS).thenApply(ResponseEntity::ok);
        } catch (Exception e) {
            future.completeExceptionally(e);
            Thread.currentThread().interrupt();
            throw new Exception("Error processing REST validation", e);
        } finally {
            futuresMapRest.remove(correlationId);
        }
    }

    /**
     * Sends a message to the JMS topic and simulates a response.
     *
     * @param requestDto    the request data
     * @param correlationId the correlation ID for tracking the message
     * @param future        the future to complete with the response
     * @throws JsonProcessingException if the JSON processing fails
     * @throws InterruptedException    if the thread is interrupted
     * @throws JMSException            if there is an error in the JMS message processing
     */
    public void getResponseFromEngine(
            WebHookRequestDto requestDto,
            String correlationId,
            CompletableFuture<WebHookResponseDto> future
    ) throws Exception {
        WebHookResponseDto genericResponse;
        AntifraudEngineConfiguration.InfoMotorConfig saferMotorConfig = antifraudEngineService.getEngineInfoByCodigoMotor("0");
        DeviceRequestContext deviceRequestContext = new DeviceRequestContext(
                requestDto,
                correlationId,
                saferMotorConfig
        );
        genericResponse = deviceOperationsHandler.handleOperation("CLEAFY", deviceRequestContext);

        this.log.debug("Generated JSON: {} for ID: {}", genericResponse, correlationId);
        future.complete(genericResponse);
        this.log.info("Finalizada ejecución: Request {} - Response {} con ID: {}", requestDto, genericResponse, correlationId);

    }
}
