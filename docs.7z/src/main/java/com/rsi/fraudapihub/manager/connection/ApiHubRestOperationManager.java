package com.rsi.fraudapihub.manager.connection;

import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferWebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.response.engine.cleafy.CleafyResponseDto;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.EE_O_ComprobarFraude;
import org.springframework.http.ResponseEntity;

/**
 * The interface Api hub rest operation manager.
 *
 * @author Miguel Alonso Felipe
 */
//TODO: Rehacer como una interfaz generica y una implementacion por tipo de motor, no todo aqui dentro, pasando un parametro de context identico para todos
public interface ApiHubRestOperationManager {

    /**
     * Send post request to safer payments response entity.
     *
     * @param uri
     *         the uri
     * @param body
     *         the body
     * @param correlationId
     *         the correlation id
     * @param messageType
     *         the message type
     * @param requestType
     *         the request type
     * @return the response entity
     */
    ResponseEntity<SaferResponseDTO> sendPostRequestToSaferPayments(String uri, String body, String correlationId, String messageType, String requestType);

    /**
     * Send post request to safer payments response entity.
     *
     * @param uri
     *         the uri
     * @param body
     *         the body
     * @return the response entity
     */
    ResponseEntity<EE_O_ComprobarFraude> sendPostRequestToTacticalAndSVO(String uri, String SVOUri, String body, String idOperacionBE);

    /**
     * Send post request to cleafy response entity.
     *
     * @param uri
     *         the uri
     * @param body
     *         the body
     * @return the response entity
     */
    ResponseEntity<SaferWebHookRequestDto> sendPostRequestToCleafy(String uri, String body);
}
