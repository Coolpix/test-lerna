package com.rsi.fraudapihub.manager.connection.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsi.fraudapihub.manager.connection.ApiHubRestOperationManager;
import com.rsi.fraudapihub.utils.dto.base.ErrorResponse;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferWebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.request.engine.tactical.Request;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.EE_O_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.FactorDto;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.Response;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.RespuestaDto;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;

import java.nio.charset.StandardCharsets;
import java.util.*;

import static org.springframework.http.MediaType.APPLICATION_JSON;

/**
 * The type Api hub rest operation manager.
 *
 * @author Miguel Alonso Felipe
 */
@Service
public class ApiHubRestOperationManagerImpl implements ApiHubRestOperationManager {
    //TODO: Refactorizar las llamadas REST a los motores diferenciandolas por motor
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final RestClient restClient;

    private final OperationMapper operationMapper;

    /**
     * Instantiates a new Api hub rest operation manager.
     *
     * @param restClient
     *         the rest client
     */
    @Autowired
    public ApiHubRestOperationManagerImpl(
            @Qualifier("customRestClient") RestClient restClient,
            OperationMapper operationMapper
    ) {
        this.restClient = restClient;
        this.operationMapper = operationMapper;
    }

    public ResponseEntity<SaferResponseDTO> sendPostRequestToSaferPayments(String uri, String body, String messageType, String correlationId, String requestType) {
        boolean isInputFieldsError = StringUtils.isBlank(uri) || StringUtils.isBlank(body) || StringUtils.isBlank(messageType) || StringUtils.isBlank(correlationId) || StringUtils.isBlank(requestType);
        if (isInputFieldsError) {
            throw new IllegalArgumentException("Input parameters must not be null or empty");
        }

        try {
            this.log.info("Enviando petición a Safer Payments. URI: {}, Message Type: {}, Correlation ID: {}, Request Type: {}, Body: {}",
                    uri, messageType, correlationId, requestType, body);

            ResponseEntity<SaferResponseDTO> response = this.restClient.post()
                    .uri(uri)
                    .contentType(APPLICATION_JSON)
                    .contentLength(body.getBytes(StandardCharsets.UTF_8).length)
                    .body(body)
                    .header("X-SP-Message-Type-Id", messageType)
                    .header("X-SP-Message-Id", correlationId)
                    .header("X-SP-Request-Type", requestType)
                    .retrieve().toEntity(SaferResponseDTO.class);

            this.log.info("Respuesta de Safer: {}", response);

            return response;

        } catch (Exception e) {
            this.log.error("Error enviando request a Safer Payments. URI: {}, Message Type: {}, Correlation ID: {}, Request Type: {}",
                    uri, messageType, correlationId, requestType, e);
            throw new RuntimeException("RunTimeExcepcion llamando a Safer", e);
        }
    }

    public ResponseEntity<EE_O_ComprobarFraude> sendPostRequestToTacticalAndSVO(String uri, String SVOUri, String body, String idOperacionBE) {
        boolean isInputFieldsError = StringUtils.isBlank(uri) || StringUtils.isBlank(body);
        if (isInputFieldsError) {
            throw new IllegalArgumentException("Input parameters must not be null or empty");
        }

        try {
            this.log.info("Enviando petición al motor táctico. URI: {}. Body:{}", uri, body);
            ResponseEntity<EE_O_ComprobarFraude> response = this.restClient.post()
                    .uri(uri)
                    .contentType(APPLICATION_JSON)
                    .body(body)
                    .retrieve().toEntity(EE_O_ComprobarFraude.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                ObjectMapper objectMapper = new ObjectMapper();
                Request request;
                EE_O_ComprobarFraude eeOComprobarFraude = objectMapper.convertValue(response.getBody(), EE_O_ComprobarFraude.class);
                boolean contieneErrores = eeOComprobarFraude.getCodigoRetorno().equals("0");

                if (contieneErrores) {
                    this.log.error("Error en respuesta del motor táctico: {}", response);
                    ArrayList<FactorDto> listaFactores = new ArrayList<>();
                    listaFactores.add(new FactorDto("ERROR_MOTOR", -1));
                    request = operationMapper.creationSVORequestMapping(idOperacionBE, listaFactores);
                } else {
                    this.log.info("Respuesta del motor táctico: {}", response);

                    idOperacionBE = idOperacionBE == null ? "-1" : idOperacionBE;

                    request = operationMapper.creationSVORequestMapping(eeOComprobarFraude, idOperacionBE);
                }

                String json = objectMapper.writeValueAsString(request);
                this.log.info("Enviando peticion a SVO: Body: {}", json);

                ResponseEntity<Response> responseSVO = this.restClient.post()
                        .uri(SVOUri)
                        .contentType(APPLICATION_JSON)
                        .body(json)
                        .retrieve().toEntity(Response.class);
                this.log.info("Respuesta de SVO: {}", responseSVO);
            }

            return response;
        } catch (ResourceAccessException e) {
            this.log.error("TimeOut", e);
            FactorDto factordto = new FactorDto("0",0);
            ArrayList<FactorDto> listaFactores = new ArrayList<>();
            listaFactores.add(factordto);
            //TODO: Rehacer esto bien
            EE_O_ComprobarFraude eeOComprobarFraude = new EE_O_ComprobarFraude(
                    new RespuestaDto(false, false, 0, listaFactores, -1),
                    new ErrorResponse("","","")
            );
            return new ResponseEntity<>(eeOComprobarFraude, HttpStatus.OK);
        } catch (Exception e) {
            this.log.error("Excepción enviando petición hacia el motor táctico. URI: {}",
                    uri, e);
            throw new RuntimeException("RunTimeExcepción enviando petición hacia el motor táctico", e);
        }
    }

    @Override
    public ResponseEntity<SaferWebHookRequestDto> sendPostRequestToCleafy(String uri, String body) {
        return new ResponseEntity<SaferWebHookRequestDto>(HttpStatus.OK);
    }
}
