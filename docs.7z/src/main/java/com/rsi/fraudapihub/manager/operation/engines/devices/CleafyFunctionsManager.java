package com.rsi.fraudapihub.manager.operation.engines.devices;

import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import org.springframework.http.ResponseEntity;

public interface CleafyFunctionsManager<T, U> {
    WebHookResponseDto getEngineResponse(
            T requestDtoNulls,
            String correlationId,
            AntifraudEngineConfiguration.InfoMotorConfig engine
    ) throws Exception;

    WebHookResponseDto getHubResponse(
            ResponseEntity<U> response,
            String correlationId,
            AntifraudEngineConfiguration.InfoMotorConfig engine
    ) throws Exception;
}
