package com.rsi.fraudapihub.manager.operation.operations.devices;

import com.rsi.fraudapihub.utils.dto.request.operation.WebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import org.springframework.http.ResponseEntity;

import java.util.concurrent.CompletableFuture;

/**
 * The interface Api hub WebHook manager.
 *
 * @author Miguel Alonso Felipe
 */
public interface ApiHubWebHookManager {

    /**
     * Create operation for rest validation completable future.
     *
     * @param requestDto
     *         the request dto
     * @return the completable future
     */
    CompletableFuture<ResponseEntity<WebHookResponseDto>> createOperationForRestValidation(WebHookRequestDto requestDto) throws Exception;
}
