package com.rsi.fraudapihub.manager.operation.operations.operations;

import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import org.springframework.http.ResponseEntity;

import java.util.concurrent.CompletableFuture;

/**
 * The interface Api hub operation manager.
 *
 * @author Miguel Alonso Felipe
 */
public interface ApiHubOperationManager {

    /**
     * Create operation for soap validation operation response dto.
     *
     * @param requestDto
     *         the operation request dto
     * @return the operation response dto
     */
    OperationResponseDto createOperationForSoapValidation(OperationRequestDto requestDto, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded) throws Exception;

    /**
     * Create operation for rest validation completable future.
     *
     * @param requestDto
     *         the operation request dto
     * @return the completable future
     */
    CompletableFuture<ResponseEntity<OperationResponseDto>> createOperationForRestValidation(OperationRequestDto requestDto, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded) throws Exception;
}

