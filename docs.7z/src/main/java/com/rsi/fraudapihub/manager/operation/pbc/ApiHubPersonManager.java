package com.rsi.fraudapihub.manager.operation.pbc;

import com.rsi.fraudapihub.utils.dto.request.operation.PersonRequestDto;
import org.springframework.http.ResponseEntity;

import java.util.concurrent.CompletableFuture;

/**
 * The interface Api hub person manager.
 *
 * @param <T>
 *         the type parameter
 * @author Miguel Alonso Felipe
 */
public interface ApiHubPersonManager<T> {

    /**
     * Create operation for rest validation completable future.
     *
     * @param requestDto
     *         the request dto
     * @return the completable future
     */
    CompletableFuture<ResponseEntity<String>> createOperationForRestValidation(PersonRequestDto requestDto) throws InterruptedException;


}
