package com.rsi.fraudapihub.manager.operation.operations.operations.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.handler.engineOperations.operations.EngineOperationsHandler;
import com.rsi.fraudapihub.manager.operation.operations.operations.ApiHubOperationManager;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.request.hub.EnginesRequestContext;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.fraudapihub.utils.enums.EnginesCodes;
import jakarta.jms.JMSException;
import jakarta.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * The Api hub manager.
 *
 * @author Sergio Alonso
 */
@Service
@EnableJms
@RefreshScope
@SuppressWarnings("unchecked")
public class ApiHubOperationManagerImpl implements ApiHubOperationManager {

    /**
     * The MQ topic error.
     */
    @Value("${params.mq.topic.error}")
    public String mqTopicError;

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The JMS topic template.
     */
    private final JmsTemplate jmsTopicTemplate;

    /**
     * The Futures map for REST responses.
     */
    private final ConcurrentHashMap<String, CompletableFuture<OperationResponseDto>> futuresMapRest = new ConcurrentHashMap<>();

    /**
     * The Futures map for SOAP responses.
     */
    private final ConcurrentHashMap<String, CompletableFuture<OperationResponseDto>> futuresMapSoap = new ConcurrentHashMap<>();

    /**
     *
     */
    private final AntifraudEngineService antifraudEngineService;

    private final EngineOperationsHandler engineOperationsHandler;

    /**
     * Instantiates a new Api hub operation manager.
     *
     * @param jmsTopicTemplate
     *         the jms topic template
     */
    @Autowired
    public ApiHubOperationManagerImpl(
            @Qualifier("topicTemplate") JmsTemplate jmsTopicTemplate,
            AntifraudEngineService antifraudEngineService,
            EngineOperationsHandler engineOperationsHandler
    ) {
        this.jmsTopicTemplate = jmsTopicTemplate;
        this.antifraudEngineService = antifraudEngineService;
        this.engineOperationsHandler = engineOperationsHandler;
    }

    /**
     * MQ Message Sender.
     * Used to send the input data from DTO to a TOPIC.
     *
     * @param requestDto the operation request DTO
     * @return the PersonRequestDto response
     */
    public OperationResponseDto createOperationForSoapValidation(OperationRequestDto requestDto, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded) throws Exception {
        this.log.info("Request desde controlador SOAP {}", requestDto);
        String correlationId = UUID.randomUUID().toString();

        CompletableFuture<OperationResponseDto> future = new CompletableFuture<>();
        futuresMapSoap.put(correlationId, future);

        try {
            getResponseFromEngine(requestDto, correlationId, future, motorInfoLoaded);

            //sendMessageToMq(correlationId, genericResponse);

            return future.get(30, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ValidationException("Thread was interrupted while processing SOAP validation", e);
        }  catch (Exception e) {
            future.completeExceptionally(e);
            throw new ValidationException("Error processing SOAP validation", e);
        } finally {
            futuresMapSoap.remove(correlationId);
        }
    }

    /**
     * MQ Message Sender.
     * Used to send the input data from DTO to a TOPIC.
     *
     * @param requestDto the operation request DTO
     * @return a CompletableFuture containing the ResponseEntity with the response or error message
     */
    public CompletableFuture<ResponseEntity<OperationResponseDto>> createOperationForRestValidation(OperationRequestDto requestDto, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded) throws Exception {
        this.log.info("Request desde controlador REST {}", requestDto);
        String correlationId = UUID.randomUUID().toString();

        CompletableFuture<OperationResponseDto> future = new CompletableFuture<>();
        futuresMapRest.put(correlationId, future);

        try {
            getResponseFromEngine(requestDto, correlationId, future, motorInfoLoaded);

            //sendMessageToMq(correlationId, genericResponse);

            return future.orTimeout(30, TimeUnit.SECONDS).thenApply(ResponseEntity::ok);
        } catch (Exception e) {
            if (Thread.interrupted())
                throw new InterruptedException();
            future.completeExceptionally(e);
            throw new ValidationException("Error processing REST validation", e);
        } finally {
            futuresMapRest.remove(correlationId);
        }
    }


    /**
     * Sends a message to the JMS topic and simulates a response.
     *
     * @param requestDto    the request data
     * @param correlationId the correlation ID for tracking the message
     * @param future        the future to complete with the response
     * @throws JsonProcessingException if the JSON processing fails
     * @throws InterruptedException    if the thread is interrupted
     * @throws JMSException            if there is an error in the JMS message processing
     */
    public void getResponseFromEngine(
            OperationRequestDto requestDto, 
            String correlationId, 
            CompletableFuture<OperationResponseDto> future,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded
    ) throws Exception {
        OperationResponseDto genericResponse = null;

        List<AntifraudEngineConfiguration.InfoMotorConfig> engines = motorInfoLoaded.getCodigoMotor();

        AntifraudEngineConfiguration.InfoCanal channel = antifraudEngineService.getChannelById(requestDto.getIdCanal());
        requestDto.setIdCanal(channel.getNombreCanal());

        String operationRequestID = requestDto.getIdOperacionBE();
        String faseOperacion = requestDto.getEstadoFaseOperacion();

        for (AntifraudEngineConfiguration.InfoMotorConfig engine : engines) {
            EnginesCodes code = EnginesCodes.fromCode(engine.getCodigoMotor());
            EnginesRequestContext enginesRequestContext = new EnginesRequestContext(
                    requestDto,
                    faseOperacion,
                    correlationId,
                    operationRequestID,
                    motorInfoLoaded,
                    engine
            );
            genericResponse = engineOperationsHandler.handleOperation(code.toString(), enginesRequestContext);
        }

        this.log.debug("Generated JSON: {} for ID: {}", genericResponse, correlationId);
        future.complete(genericResponse);
        this.log.info("Finalizada ejecución: Request {} - Response {} con ID: {}", requestDto, genericResponse, correlationId);

    }

    public <T> void sendMessageToMq(String correlationId, T genericResponse) {
        jmsTopicTemplate.convertAndSend(genericResponse.toString(), m -> {
            m.setJMSCorrelationID(correlationId);
            return m;
        });
    }

}
