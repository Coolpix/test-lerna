package com.rsi.fraudapihub.manager.operation.engines.operations.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.exceptions.EngineTimeOutException;
import com.rsi.fraudapihub.exceptions.MapperFailedException;
import com.rsi.fraudapihub.handler.responseStrategy.operations.OperationsResponseHandler;
import com.rsi.fraudapihub.manager.operation.engines.operations.ApiHubFunctionsManager;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.service.connection.ApiHubRestService;
import com.rsi.fraudapihub.utils.dto.DtoUtils;
import com.rsi.fraudapihub.utils.dto.request.engine.tactical.EE_I_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.EE_O_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.fraudapihub.utils.enums.OperationPhaseStatus;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

@Service("TacticalEngineResponse")
public class ApiHubTacticalFunctionsManagerImpl implements ApiHubFunctionsManager<EE_I_ComprobarFraude, EE_O_ComprobarFraude> {

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The Object mapper.
     */
    private final ObjectMapper objectMapper;

    /**
     * The operation mapper.
     */
    private final OperationMapper operationMapper;

    /**
     * The Operation response handler.
     */
    private final OperationsResponseHandler<EE_O_ComprobarFraude> operationsResponseHandler;

    /**
     * The Api hub rest service.
     */
    private final ApiHubRestService apiHubRestService;

    /**
     * The Anti Fraud Engine Service
     */
    private final AntifraudEngineService antifraudEngineService;

    public ApiHubTacticalFunctionsManagerImpl(
            ObjectMapper objectMapper,
            OperationMapper operationMapper,
            OperationsResponseHandler<EE_O_ComprobarFraude> operationsResponseHandler,
            ApiHubRestService apiHubRestService,
            AntifraudEngineService antifraudEngineService
    ) {
        this.objectMapper = objectMapper;
        this.operationMapper = operationMapper;
        this.operationsResponseHandler = operationsResponseHandler;
        this.apiHubRestService = apiHubRestService;
        this.antifraudEngineService = antifraudEngineService;
    }

    public OperationResponseDto getEngineResponse(EE_I_ComprobarFraude requestDtoNulls, String faseOperacion, String correlationId, String idOperacionBE, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded, AntifraudEngineConfiguration.InfoMotorConfig engine) throws Exception {
        ResponseEntity<EE_O_ComprobarFraude> response;
        String messageType = faseOperacion.equals("0") ? "2" : faseOperacion.equals("1") ? "1" : "10";
        OperationResponseDto hubResponse;

        JSONObject cleanedDtoTactico = DtoUtils.toJsonObjectWithoutNulls(requestDtoNulls, false);

        if (OperationPhaseStatus.fromCode(faseOperacion).equals(OperationPhaseStatus.CREATION)) {
            response = this.apiHubRestService.sendPostRequestToTacticalAndSVO(
                    engine.getUrl(),
                    antifraudEngineService.getEngineInfoByCodigoMotor("2").getUrl(),
                    cleanedDtoTactico.toString(),
                    idOperacionBE
            );
            hubResponse = getHubResponse(response, faseOperacion, correlationId, idOperacionBE, motorInfoLoaded, engine);
        } else {
            hubResponse = operationMapper.buildSuccessfulResponseDTO(idOperacionBE);
        }

        JSONObject cleanedDtoSafer = DtoUtils.toJsonObjectWithoutNulls(requestDtoNulls, true);
        this.apiHubRestService.sendPostRequestToSaferPayments(
                antifraudEngineService.getEngineInfoByCodigoMotor("0").getUrl(),
                cleanedDtoSafer.toString(),
                messageType,
                correlationId,
                "ModelRequest"
        );

        return hubResponse;
    }

    public OperationResponseDto getHubResponse(ResponseEntity<EE_O_ComprobarFraude> response, String faseOperacion, String correlationId, String operationRequestID, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded, AntifraudEngineConfiguration.InfoMotorConfig engine) throws Exception {
        this.log.debug("Validating input fields: response={}, correlationId={}, operationRequestID={}", response, correlationId, operationRequestID);

        try {
            OperationResponseDto operationResponseDto;
            EE_O_ComprobarFraude eeOComprobarFraude = objectMapper.convertValue(response.getBody(), EE_O_ComprobarFraude.class);

            operationResponseDto = operationsResponseHandler.handleOperation(
                    "TACTICO",
                    eeOComprobarFraude,
                    faseOperacion,
                    operationRequestID,
                    motorInfoLoaded
            );

            return operationResponseDto;

        } catch (ResourceAccessException e) {
            this.log.error("Time Out: ", e);
            throw new EngineTimeOutException("Error por Time Out en la llamada a: " + motorInfoLoaded.getCodigoMotor() + ".", operationRequestID, motorInfoLoaded);
        } catch (IllegalArgumentException e) {
            throw new MapperFailedException("Error processing response from Engine", e);
        } catch (Exception e) {
            throw new Exception("Error validating engine response.", e);
        }
    }
}
