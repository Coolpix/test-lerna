package com.rsi.fraudapihub.manager.operation.engines.operations;

import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import org.springframework.http.ResponseEntity;

public interface ApiHubFunctionsManager<T, U> {

    OperationResponseDto getEngineResponse(
            T requestDtoNulls,
            String faseOperacion,
            String correlationId,
            String idOperacionBE,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded,
            AntifraudEngineConfiguration.InfoMotorConfig engine
    ) throws Exception;

    OperationResponseDto getHubResponse(
            ResponseEntity<U> response,
            String faseOperacion,
            String correlationId,
            String operationRequestID,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded,
            AntifraudEngineConfiguration.InfoMotorConfig engine
    ) throws Exception;
}
