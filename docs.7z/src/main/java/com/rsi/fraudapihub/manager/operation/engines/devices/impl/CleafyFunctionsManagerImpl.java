package com.rsi.fraudapihub.manager.operation.engines.devices.impl;

import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.exceptions.EngineTimeOutException;
import com.rsi.fraudapihub.exceptions.MapperFailedException;
import com.rsi.fraudapihub.handler.responseStrategy.cleafy.DeviceResponseHandler;
import com.rsi.fraudapihub.manager.operation.engines.devices.CleafyFunctionsManager;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.service.connection.ApiHubRestService;
import com.rsi.fraudapihub.utils.dto.DtoUtils;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferWebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

import java.util.List;

@Service("CleafyEngineResponse")
public class CleafyFunctionsManagerImpl implements CleafyFunctionsManager<SaferWebHookRequestDto, SaferResponseDTO> {

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The Api hub rest service.
     */
    private final ApiHubRestService apiHubRestService;

    /**
     * The operation handler.
     */
    private final DeviceResponseHandler<SaferResponseDTO> deviceResponseHandler;

    public CleafyFunctionsManagerImpl(
            DeviceResponseHandler<SaferResponseDTO> deviceResponseHandler,
            ApiHubRestService apiHubRestService
    ) {
        this.apiHubRestService = apiHubRestService;
        this.deviceResponseHandler = deviceResponseHandler;
    }

    @Override
    public WebHookResponseDto getEngineResponse(SaferWebHookRequestDto requestDtoNulls, String correlationId, AntifraudEngineConfiguration.InfoMotorConfig engine) throws Exception {
        ResponseEntity<SaferResponseDTO> response;
        JSONObject cleanedDtoSafer = DtoUtils.toJsonObjectWithoutNulls(requestDtoNulls, true);

        response = this.apiHubRestService.sendPostRequestToSaferPayments(
                engine.getUrl(),
                cleanedDtoSafer.toString(),
                "31",
                correlationId,
    "ModelRequest"
        );
        return getHubResponse(response, correlationId, engine);

    }

    @Override
    public WebHookResponseDto getHubResponse(ResponseEntity<SaferResponseDTO> response, String correlationId, AntifraudEngineConfiguration.InfoMotorConfig engine) throws Exception {
        this.log.debug("Validating input fields: response={}, correlationId={}", response, correlationId);
        AntifraudEngineService.MotorInfoLoaded motorInfoLoaded = new AntifraudEngineService.MotorInfoLoaded(List.of(engine),"SAFER");
        try {
            WebHookResponseDto webHookResponseDto;

            webHookResponseDto = deviceResponseHandler.handleOperation(
                    engine.getCodigoMotor(),
                    response.getBody(),
                    motorInfoLoaded
            );

            return webHookResponseDto;

        } catch (ResourceAccessException e) {
            this.log.error("Time Out: ", e);
            throw new EngineTimeOutException("Error por Time Out en la llamada a: " + engine.getNombreMotor() + ".", correlationId, motorInfoLoaded);
        } catch (IllegalArgumentException e) {
            throw new MapperFailedException("Error processing response from Engine", e);
        } catch (Exception e) {
            throw new Exception("Error validating engine response.", e);
        }
    }
}
