package com.rsi.fraudapihub.manager.operation.engines.operations.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.exceptions.EngineTimeOutException;
import com.rsi.fraudapihub.exceptions.MapperFailedException;
import com.rsi.fraudapihub.handler.responseStrategy.operations.OperationsResponseHandler;
import com.rsi.fraudapihub.manager.operation.engines.operations.ApiHubFunctionsManager;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.service.connection.ApiHubRestService;
import com.rsi.fraudapihub.utils.dto.DtoUtils;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferRequestDto;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

@Service("SaferEngineResponse")
public class ApiHubSaferFunctionsManagerImpl implements ApiHubFunctionsManager<SaferRequestDto, SaferResponseDTO> {

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The Object mapper.
     */
    private final ObjectMapper objectMapper;

    /**
     * The Operation response handler.
     */
    private final OperationsResponseHandler<SaferResponseDTO> operationsResponseHandler;

    /**
     * The Api hub rest service.
     */
    private final ApiHubRestService apiHubRestService;

    /**
     * The Anti Fraud Engine Service
     */
    private final AntifraudEngineService antifraudEngineService;

    public ApiHubSaferFunctionsManagerImpl(
            ObjectMapper objectMapper,
            OperationsResponseHandler<SaferResponseDTO> operationsResponseHandler,
            ApiHubRestService apiHubRestService,
            AntifraudEngineService antifraudEngineService
    ) {
        this.objectMapper = objectMapper;
        this.operationsResponseHandler = operationsResponseHandler;
        this.apiHubRestService = apiHubRestService;
        this.antifraudEngineService = antifraudEngineService;
    }

    public OperationResponseDto getEngineResponse(SaferRequestDto requestDtoNulls, String faseOperacion, String correlationId, String idOperacionBE, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded, AntifraudEngineConfiguration.InfoMotorConfig engine) throws Exception {

        String messageType = faseOperacion.equals("0") ? "2" : faseOperacion.equals("1") ? "1" : "10";
        OperationResponseDto hubResponse;

        JSONObject cleanedDtoSafer = DtoUtils.toJsonObjectWithoutNulls(requestDtoNulls, true);

        ResponseEntity<SaferResponseDTO> response = this.apiHubRestService.sendPostRequestToSaferPayments(
                antifraudEngineService.getEngineInfoByCodigoMotor("0").getUrl(),
                cleanedDtoSafer.toString(),
                messageType,
                correlationId,
                "ModelRequest"
        );

        hubResponse = getHubResponse(response, faseOperacion, correlationId, idOperacionBE, motorInfoLoaded, engine);

        return hubResponse;
    }

    public OperationResponseDto getHubResponse(ResponseEntity<SaferResponseDTO> response, String faseOperacion, String correlationId, String operationRequestID, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded, AntifraudEngineConfiguration.InfoMotorConfig engine) throws Exception {
        this.log.debug("Validating input fields: response={}, correlationId={}, operationRequestID={}", response, correlationId, operationRequestID);

        try {
            OperationResponseDto operationResponseDto;

            SaferResponseDTO saferResponseDTO = objectMapper.convertValue(response.getBody(), SaferResponseDTO.class);

            operationResponseDto = operationsResponseHandler.handleOperation(
                    engine.getNombreMotor(),
                    saferResponseDTO,
                    faseOperacion,
                    operationRequestID,
                    motorInfoLoaded
            );

            return operationResponseDto;

        } catch (ResourceAccessException e) {
            this.log.error("Time Out: ", e);
            throw new EngineTimeOutException("Error por Time Out en la llamada a: " + motorInfoLoaded.getCodigoMotor() + ".", operationRequestID, motorInfoLoaded);
        } catch (IllegalArgumentException e) {
            throw new MapperFailedException("Error processing response from Engine", e);
        } catch (Exception e) {
            throw new Exception("Error validating engine response.", e);
        }
    }
}
