package com.rsi.fraudapihub.manager.operation.pbc.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsi.fraudapihub.manager.operation.pbc.ApiHubPersonManager;
import com.rsi.fraudapihub.utils.dto.request.operation.PersonRequestDto;
import com.rsi.fraudapihub.utils.dto.response.operation.PersonInsideResponseDto;
import com.rsi.fraudapihub.utils.dto.response.operation.PersonResponseDto;
import jakarta.jms.JMSException;
import jakarta.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * The type Api hub person manager.
 *
 * @param <T>
 *         the type parameter
 * @author Miguel Alonso Felipe
 */
@Service
public class ApiHubPersonManagerImpl<T> implements ApiHubPersonManager<T> {

    /**
     * The MQ topic error.
     */
    @Value("${params.mq.topic.error}")
    public String mqTopicError;

    /**
     * The Log.
     */
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * The JMS topic template.
     */
    private final JmsTemplate jmsTopicTemplate;

    /**
     * The Object mapper.
     */
    private final ObjectMapper objectMapper;

    /**
     * The Futures map for REST responses.
     */
    private final ConcurrentHashMap<String, CompletableFuture<String>> futuresMapRest = new ConcurrentHashMap<>();

    /**
     * Instantiates a new API HUB manager.
     *
     * @param jmsTopicTemplate
     *         the JMS topic template
     * @param objectMapper
     *         the object mapper
     */
    @Autowired
    public ApiHubPersonManagerImpl(@Qualifier("topicTemplate") JmsTemplate jmsTopicTemplate, ObjectMapper objectMapper) {
        this.jmsTopicTemplate = jmsTopicTemplate;
        this.objectMapper = objectMapper;
    }

    /**
     * MQ Message Sender.
     * Used to send the input data from DTO to a TOPIC.
     *
     * @param requestDto the operation request DTO
     * @return a CompletableFuture containing the ResponseEntity with the response or error message
     */
    public CompletableFuture<ResponseEntity<String>> createOperationForRestValidation(PersonRequestDto requestDto) throws InterruptedException {
        this.log.info("Starting createOperationForRestValidation for request {}", requestDto);
        String correlationId = UUID.randomUUID().toString();
        try {
            CompletableFuture<String> future = new CompletableFuture<>();
            futuresMapRest.put(correlationId, future);

            sendMessageAndSimulateResponse(requestDto, correlationId, future);

            return future.orTimeout(30, TimeUnit.SECONDS).thenApply(ResponseEntity::ok);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ValidationException("Thread was interrupted while processing REST validation", e);
        }  catch (JsonProcessingException | JMSException | IllegalAccessException e) {
            this.log.error("Error creating operation for rest validation", e);
            return CompletableFuture.completedFuture(ResponseEntity.internalServerError().body(e.getMessage()));
        } finally {
            futuresMapRest.remove(correlationId);
        }
    }

    /**
     * Sends a message to the JMS topic and simulates a response.
     *
     * @param requestDto the request data
     * @param correlationId       the correlation ID for tracking the message
     * @param future              the future to complete with the response
     * @param <T>                 the type of the future being processed (OperationResponseDto or String)
     * @throws JsonProcessingException if the JSON processing fails
     * @throws InterruptedException    if the thread is interrupted
     * @throws JMSException            if there is an error in the JMS message processing
     */
    private <T> void sendMessageAndSimulateResponse(PersonRequestDto requestDto, String correlationId, CompletableFuture<T> future) throws JsonProcessingException, InterruptedException, JMSException, IllegalAccessException {
        // Respuesta mockeada, meter flujo de llamada a AML cuando se tenga disponible
        PersonResponseDto personResponseDto = new PersonResponseDto();
        
        personResponseDto.setCodigoRetorno("1");

        PersonInsideResponseDto personInsideResponseDto = new PersonInsideResponseDto();

        personInsideResponseDto.setCodRespuestaMotor("00001");
        personInsideResponseDto.setDescripcionRespuestaMotor("descripcionRespuestaMotor");
        personInsideResponseDto.setCodMotor("00001");
        personInsideResponseDto.setIdExternoMotor("10");
        personInsideResponseDto.setTipoOperacion("tipoOperacion");
        personInsideResponseDto.setAccionPBC("accionPBC");
        personInsideResponseDto.setIdAlerta("idAlerta");
        personInsideResponseDto.setIdEvidencia("IdEvidencia");
        personInsideResponseDto.setRiesgoOperacion("RiesgoOperacion");
        personInsideResponseDto.setCodRegla("CodRegla");
        personInsideResponseDto.setDescrRegla("DescRegla");
        personInsideResponseDto.setRiesgoOperacionManual("RiesgoOperacionManual");

        personResponseDto.setPersonInsideResponseDto(personInsideResponseDto);
        
        /*jmsTopicTemplate.convertAndSend(personResponseDto.toString(), m -> {
            m.setJMSCorrelationID(correlationId);
            return m;
        });*/
        
        String sasResponseJson = objectMapper.writeValueAsString(personResponseDto);
        this.log.debug("Generated JSON: {} for ID: {}", sasResponseJson, correlationId);
        ((CompletableFuture<String>) future).complete(sasResponseJson);
        this.log.info("Ending sendOperationForValidation for request: {} and ID: {}", requestDto, correlationId);
    }
}
