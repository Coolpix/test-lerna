package com.rsi.fraudapihub;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.SessionTrackingMode;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.core.env.AbstractEnvironment;
import java.util.EnumSet;

/**
 * The type Fraudapihub application.
 */
@SpringBootApplication
public class FraudapihubApplication extends SpringBootServletInitializer {

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME, getEnvironment());
        SpringApplication.run(FraudapihubApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME, getEnvironment());
        return builder.sources(FraudapihubApplication.class);
    }

    private static String getEnvironment() {
        String strEnvVar = System.getenv("TENV");
        if ((strEnvVar == null) || "LOCAL".equals(strEnvVar)) {
            strEnvVar = "DESA";
        }
        return strEnvVar;
    }

    @Override
    public void onStartup(final ServletContext servletContext) throws ServletException {
        System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME, getEnvironment());
        super.onStartup(servletContext);
        servletContext.setSessionTrackingModes(EnumSet.of(SessionTrackingMode.URL));
    }
}

