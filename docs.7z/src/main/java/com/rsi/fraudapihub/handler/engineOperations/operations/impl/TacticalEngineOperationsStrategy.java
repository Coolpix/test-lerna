package com.rsi.fraudapihub.handler.engineOperations.operations.impl;

import com.rsi.fraudapihub.handler.engineOperations.operations.EngineOperationsStrategy;
import com.rsi.fraudapihub.handler.requestStrategy.operations.OperationsRequestHandler;
import com.rsi.fraudapihub.manager.operation.engines.operations.ApiHubFunctionsManager;
import com.rsi.fraudapihub.utils.dto.request.engine.tactical.EE_I_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.request.hub.EnginesRequestContext;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.EE_O_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;

public class TacticalEngineOperationsStrategy implements EngineOperationsStrategy {

    private final ApiHubFunctionsManager<EE_I_ComprobarFraude, EE_O_ComprobarFraude> tacticalApiHubFunctionsManager;
    private final OperationsRequestHandler<EE_I_ComprobarFraude> operationsRequestHandler;

    public TacticalEngineOperationsStrategy(
            ApiHubFunctionsManager<EE_I_ComprobarFraude, EE_O_ComprobarFraude> tacticalApiHubFunctionsManager,
            OperationsRequestHandler<EE_I_ComprobarFraude> operationsRequestHandler
    ) {
        this.tacticalApiHubFunctionsManager = tacticalApiHubFunctionsManager;
        this.operationsRequestHandler = operationsRequestHandler;
    }

    @Override
    public OperationResponseDto execute(EnginesRequestContext context) {
        EE_I_ComprobarFraude tacticalRequestDto = operationsRequestHandler.handleOperation(context.getMotorInfoLoaded().getMapeo(), context.getRequestDto());
        try {
            return tacticalApiHubFunctionsManager.getEngineResponse(
                    tacticalRequestDto,
                    context.getFaseOperacion(),
                    context.getCorrelationId(),
                    context.getOperationRequestID(),
                    context.getMotorInfoLoaded(),
                    context.getEngine());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
