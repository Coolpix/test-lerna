package com.rsi.fraudapihub.handler.responseStrategy.cleafy.impl;

import com.rsi.fraudapihub.handler.responseStrategy.cleafy.DeviceResponseStrategy;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.response.engine.cleafy.CleafyResponseDto;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CleafyEngineResponseStrategy implements DeviceResponseStrategy<SaferResponseDTO> {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final OperationMapper operationMapper;

    public CleafyEngineResponseStrategy(OperationMapper operationMapper) {
        this.operationMapper = operationMapper;
    }

    @Override
    public WebHookResponseDto execute(SaferResponseDTO engineResponse, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded) {
        return operationMapper.buildSuccessfulWebHookResponseDTO(engineResponse);
    }
}
