package com.rsi.fraudapihub.handler.responseStrategy.operations;

import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;

@FunctionalInterface
public interface OperationsResponseStrategy<T> {
    OperationResponseDto execute(
            T engineResponse,
            String faseOperacion,
            String operationRequestID,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded
    );
}
