package com.rsi.fraudapihub.handler.responseStrategy.cleafy;

import com.rsi.fraudapihub.handler.responseStrategy.cleafy.impl.CleafyEngineResponseStrategy;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class DeviceResponseHandler<T> {

    private final Map<String, DeviceResponseStrategy> cleafyResponseStrategyMap;

    public DeviceResponseHandler(
            CleafyEngineResponseStrategy cleafyEngineResponseStrategy
    ) {
        this.cleafyResponseStrategyMap = Map.of(
                "CLEAFY", cleafyEngineResponseStrategy,
                "DEFAULT", cleafyEngineResponseStrategy
        );
    }

    public WebHookResponseDto handleOperation(
            String code,
            T engineResponse,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded
    ) {
        return cleafyResponseStrategyMap.getOrDefault(code, cleafyResponseStrategyMap.get("DEFAULT")).execute(
                engineResponse,
                motorInfoLoaded
        );
    }
}
