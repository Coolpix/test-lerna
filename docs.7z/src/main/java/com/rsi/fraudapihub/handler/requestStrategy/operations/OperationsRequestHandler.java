package com.rsi.fraudapihub.handler.requestStrategy.operations;

import com.rsi.fraudapihub.handler.requestStrategy.operations.impl.*;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OperationsRequestHandler<T> {

    private final Map<String, OperationsRequestStrategy> operationsRequestStrategyMap;

    public OperationsRequestHandler(
            BizumRequestStrategy bizumRequestStrategy,
            TargetRequestStrategy targetRequestStrategy,
            PSD2RequestStrategy psd2RequestStrategy,
            TacticalRequestStrategy tacticalRequestStrategy,
            DefaultRequestStrategy defaultRequestStrategy
    ) {
        this.operationsRequestStrategyMap = Map.of(
            "TARGET", targetRequestStrategy,
            "BIZUM", bizumRequestStrategy,
            "PSD2", psd2RequestStrategy,
            "TACTICO", tacticalRequestStrategy,
            "DEFAULT", defaultRequestStrategy
        );
    }

    public T handleOperation(String code, OperationRequestDto dto) {
        return (T) operationsRequestStrategyMap.getOrDefault(code, operationsRequestStrategyMap.get("DEFAULT")).execute(dto);
    }
}
