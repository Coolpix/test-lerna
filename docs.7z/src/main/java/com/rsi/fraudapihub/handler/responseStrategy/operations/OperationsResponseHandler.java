package com.rsi.fraudapihub.handler.responseStrategy.operations;

import com.rsi.fraudapihub.handler.responseStrategy.operations.impl.DefaultResponseStrategy;
import com.rsi.fraudapihub.handler.responseStrategy.operations.impl.SaferEngineResponseStrategy;
import com.rsi.fraudapihub.handler.responseStrategy.operations.impl.TacticalEngineResponseStrategy;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OperationsResponseHandler<T> {

    private final Map<String, OperationsResponseStrategy> operationsResponseStrategyMap;

    public OperationsResponseHandler(
            SaferEngineResponseStrategy saferEngineResponseStrategy,
            TacticalEngineResponseStrategy tacticalEngineResponseStrategy,
            DefaultResponseStrategy defaultResponseStrategy
    ) {
        this.operationsResponseStrategyMap = Map.of(
                "SAFER", saferEngineResponseStrategy,
                "TACTICO", tacticalEngineResponseStrategy,
                "DEFAULT", defaultResponseStrategy
        );
    }

    public OperationResponseDto handleOperation(
            String code,
            T engineResponse,
            String faseOperacion,
            String operationRequestID,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded
    ) {
        return operationsResponseStrategyMap.getOrDefault(code, operationsResponseStrategyMap.get("DEFAULT")).execute(
                engineResponse,
                faseOperacion,
                operationRequestID,
                motorInfoLoaded
        );
    }
}
