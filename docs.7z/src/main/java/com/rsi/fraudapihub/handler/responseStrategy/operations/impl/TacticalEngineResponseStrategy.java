package com.rsi.fraudapihub.handler.responseStrategy.operations.impl;

import com.rsi.fraudapihub.handler.responseStrategy.operations.OperationsResponseStrategy;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.base.ErrorResponse;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.EE_O_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TacticalEngineResponseStrategy implements OperationsResponseStrategy<EE_O_ComprobarFraude> {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final OperationMapper operationMapper;

    public TacticalEngineResponseStrategy(OperationMapper operationMapper) {
        this.operationMapper = operationMapper;
    }

    @Override
    public OperationResponseDto execute(
            EE_O_ComprobarFraude engineResponse,
            String faseOperacion,
            String operationRequestID,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded
    ) {
        if (engineResponse.getRespuesta() != null) {
            return operationMapper.buildTacticalEngineHubResponse(engineResponse, operationRequestID, motorInfoLoaded);
        } else{
            return buildErrorResponse(engineResponse);
        }
    }

    /**
     * Build error response base response.
     *
     * @param eeOComprobarFraude
     *         the ee o comprobar fraude
     * @return the base response
     */
    private OperationResponseDto buildErrorResponse(EE_O_ComprobarFraude eeOComprobarFraude) {
        ErrorResponse errorResponse = new ErrorResponse(
                eeOComprobarFraude.getErrores().getCodigoMostrar(),
                eeOComprobarFraude.getErrores().getMensajeMostrar(),
                eeOComprobarFraude.getErrores().getSolucion());
        OperationResponseDto operationResponseDto = new OperationResponseDto();
        operationResponseDto.setCodigoRetorno(eeOComprobarFraude.getCodigoRetorno());
        operationResponseDto.setError(errorResponse);

        return operationResponseDto;
    }
}
