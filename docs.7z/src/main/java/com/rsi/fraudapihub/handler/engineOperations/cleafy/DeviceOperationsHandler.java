package com.rsi.fraudapihub.handler.engineOperations.cleafy;

import com.rsi.fraudapihub.handler.engineOperations.cleafy.impl.CleafyEngineOperationsStrategy;
import com.rsi.fraudapihub.utils.dto.request.hub.DeviceRequestContext;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class DeviceOperationsHandler {

    private final Map<String, DeviceOperationsStrategy> cleafyEngineOperationsStrategyMap;

    public DeviceOperationsHandler(
            CleafyEngineOperationsStrategy cleafyEngineOperationsStrategy
    ) {
        this.cleafyEngineOperationsStrategyMap = Map.of(
                "CLEAFY", cleafyEngineOperationsStrategy,
                "DEFAULT", cleafyEngineOperationsStrategy
        );
    }

    public WebHookResponseDto handleOperation(String code, DeviceRequestContext context) {
        return cleafyEngineOperationsStrategyMap.getOrDefault(code, cleafyEngineOperationsStrategyMap.get("DEFAULT")).execute(context);
    }
}
