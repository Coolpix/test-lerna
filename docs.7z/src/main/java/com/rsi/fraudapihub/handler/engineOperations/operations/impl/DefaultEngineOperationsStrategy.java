package com.rsi.fraudapihub.handler.engineOperations.operations.impl;

import com.rsi.fraudapihub.handler.engineOperations.operations.EngineOperationsStrategy;
import com.rsi.fraudapihub.utils.dto.request.hub.EnginesRequestContext;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;


public class DefaultEngineOperationsStrategy implements EngineOperationsStrategy {

    private final OperationMapper operationMapper;

    public DefaultEngineOperationsStrategy(OperationMapper operationMapper) {
        this.operationMapper = operationMapper;
    }

    @Override
    public OperationResponseDto execute(EnginesRequestContext context) {
        String operationRequestID = context.getOperationRequestID() == null ? "0" : context.getOperationRequestID();
        return operationMapper.buildSuccessfulResponseDTO(operationRequestID);
    }
}
