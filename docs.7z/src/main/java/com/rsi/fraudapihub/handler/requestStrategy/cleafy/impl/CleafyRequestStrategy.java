package com.rsi.fraudapihub.handler.requestStrategy.cleafy.impl;

import com.rsi.fraudapihub.handler.requestStrategy.cleafy.DeviceRequestStrategy;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferWebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.WebHookRequestDto;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;

public class CleafyRequestStrategy implements DeviceRequestStrategy<SaferWebHookRequestDto> {

    private final OperationMapper operationMapper;

    public CleafyRequestStrategy(OperationMapper operationMapper) {
        this.operationMapper = operationMapper;
    }

    @Override
    public SaferWebHookRequestDto execute(WebHookRequestDto dto) {
        return operationMapper.buildSuccessfulSaferWebHookRequestDTO(dto);
    }
}
