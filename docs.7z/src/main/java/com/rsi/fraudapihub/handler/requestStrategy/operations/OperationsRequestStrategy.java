package com.rsi.fraudapihub.handler.requestStrategy.operations;

import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;

@FunctionalInterface
public interface OperationsRequestStrategy<T> {
    T execute(OperationRequestDto dto);
}
