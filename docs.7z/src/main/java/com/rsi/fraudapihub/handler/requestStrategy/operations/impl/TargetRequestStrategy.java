package com.rsi.fraudapihub.handler.requestStrategy.operations.impl;

import com.rsi.fraudapihub.handler.requestStrategy.operations.OperationsRequestStrategy;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.enums.OperationPhaseStatus;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TargetRequestStrategy implements OperationsRequestStrategy<SaferRequestDto> {
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final OperationMapper operationMapper;

    SaferRequestDto saferRequestDto;

    public TargetRequestStrategy(OperationMapper operationMapper) {
        this.operationMapper = operationMapper;
    }

    @Override
    public SaferRequestDto execute(OperationRequestDto dto) {
        String estadoFaseOperacion = dto.getEstadoFaseOperacion();
        OperationPhaseStatus status = OperationPhaseStatus.fromCode(estadoFaseOperacion);
        return switch (status) {
            case EXECUTION -> {
                saferRequestDto = operationMapper.executionOperationToSaferTIOrTR(dto);
                this.log.info("Envio a SAFER de TARGET - EJECUCION: {}", saferRequestDto);
                yield saferRequestDto;
            }
            case CREATION -> {
                saferRequestDto = operationMapper.creationOperationToSaferTIOrTR(dto);
                this.log.info("Envio a SAFER de TARGET - ALTA: {}", saferRequestDto);
                yield saferRequestDto;
            }
            case SIMULATION -> {
                saferRequestDto = operationMapper.simulationOperationToSaferTIOrTR(dto);
                this.log.info("Envio a SAFER de TARGET - SIMULACION: {}", saferRequestDto);
                yield saferRequestDto;
            }
        };
    }

}
