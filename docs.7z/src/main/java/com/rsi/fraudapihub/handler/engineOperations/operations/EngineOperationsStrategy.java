package com.rsi.fraudapihub.handler.engineOperations.operations;

import com.rsi.fraudapihub.utils.dto.request.hub.EnginesRequestContext;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;

@FunctionalInterface
public interface EngineOperationsStrategy {
    OperationResponseDto execute(EnginesRequestContext context);
}
