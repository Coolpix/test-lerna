package com.rsi.fraudapihub.handler.requestStrategy.operations.impl;

import com.rsi.fraudapihub.handler.requestStrategy.operations.OperationsRequestStrategy;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.enums.OperationPhaseStatus;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PSD2RequestStrategy implements OperationsRequestStrategy<SaferRequestDto> {
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final OperationMapper operationMapper;

    SaferRequestDto saferRequestDto;

    public PSD2RequestStrategy(OperationMapper operationMapper) {
        this.operationMapper = operationMapper;
    }

    @Override
    public SaferRequestDto execute(OperationRequestDto dto) {
        String estadoFaseOperacion = dto.getEstadoFaseOperacion();
        OperationPhaseStatus status = OperationPhaseStatus.fromCode(estadoFaseOperacion);
        return switch (status) {
            case EXECUTION -> {
                saferRequestDto = operationMapper.executionOperationToSaferTIPsd2OrTRPsd2(dto);
                this.log.info("Envio a SAFER PSD2 - EJECUCION: {}", saferRequestDto);
                yield saferRequestDto;
            }
            case CREATION -> {
                saferRequestDto = operationMapper.creationOperationToSaferTIPsd2OrTRPsd2(dto);
                this.log.info("Envio a SAFER PSD2 - ALTA: {}", saferRequestDto);
                yield saferRequestDto;
            }
            case SIMULATION -> {
                saferRequestDto = operationMapper.simulationOperationToSaferTIPsd2OrTRPsd2(dto);
                this.log.info("Envio a SAFER PSD2 - SIMULACION: {}", saferRequestDto);
                yield saferRequestDto;
            }
        };
    }
}
