package com.rsi.fraudapihub.handler.requestStrategy.operations.impl;

import com.rsi.fraudapihub.handler.requestStrategy.operations.OperationsRequestStrategy;
import com.rsi.fraudapihub.utils.dto.request.engine.tactical.EE_I_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.enums.OperationPhaseStatus;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TacticalRequestStrategy implements OperationsRequestStrategy<EE_I_ComprobarFraude> {
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final OperationMapper operationMapper;

    EE_I_ComprobarFraude eeIComprobarFraude;

    public TacticalRequestStrategy(OperationMapper operationMapper) {
        this.operationMapper = operationMapper;
    }

    @Override
    public EE_I_ComprobarFraude execute(OperationRequestDto dto) {
        String estadoFaseOperacion = dto.getEstadoFaseOperacion();
        OperationPhaseStatus status = OperationPhaseStatus.fromCode(estadoFaseOperacion);
        return switch (status) {
            case EXECUTION -> {
                eeIComprobarFraude = operationMapper.creationTacticalRequestMapping(dto);
                this.log.info("Envio a TACTICO - EJECUCION: {}", eeIComprobarFraude);
                yield eeIComprobarFraude;
            }
            case CREATION -> {
                eeIComprobarFraude = operationMapper.creationTacticalRequestMapping(dto);
                this.log.info("Envio a TACTICO - ALTA: {}", eeIComprobarFraude);
                yield eeIComprobarFraude;
            }
            case SIMULATION -> {
                eeIComprobarFraude = operationMapper.creationTacticalRequestMapping(dto);
                this.log.info("Envio a TACTICO - SIMULACION: {}", eeIComprobarFraude);
                yield eeIComprobarFraude;
            }
        };
    }
}
