package com.rsi.fraudapihub.handler.responseStrategy.cleafy;

import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;

@FunctionalInterface
public interface DeviceResponseStrategy<T> {
    WebHookResponseDto execute(
            T engineResponse,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded
    );
}
