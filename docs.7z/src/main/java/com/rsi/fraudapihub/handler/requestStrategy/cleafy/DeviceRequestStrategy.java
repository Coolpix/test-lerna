package com.rsi.fraudapihub.handler.requestStrategy.cleafy;

import com.rsi.fraudapihub.utils.dto.request.operation.WebHookRequestDto;

@FunctionalInterface
public interface DeviceRequestStrategy<T> {
    T execute(WebHookRequestDto webHookRequestDto);
}
