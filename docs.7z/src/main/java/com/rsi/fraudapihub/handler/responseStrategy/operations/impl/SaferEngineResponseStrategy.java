package com.rsi.fraudapihub.handler.responseStrategy.operations.impl;

import com.rsi.fraudapihub.handler.responseStrategy.operations.OperationsResponseStrategy;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.fraudapihub.utils.enums.OperationPhaseStatus;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SaferEngineResponseStrategy implements OperationsResponseStrategy<SaferResponseDTO> {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final OperationMapper operationMapper;

    public SaferEngineResponseStrategy(OperationMapper operationMapper) {
        this.operationMapper = operationMapper;
    }

    @Override
    public OperationResponseDto execute(
            SaferResponseDTO engineResponse,
            String faseOperacion,
            String operationRequestID,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded
    ) {
        OperationPhaseStatus status = OperationPhaseStatus.fromCode(faseOperacion);
        return switch (status) {
            case EXECUTION, SIMULATION -> {
                this.log.info("Start execution path with: {} phase status code.", status);
                yield operationMapper.buildSuccessfulResponseDTOFromSaferSimulation(engineResponse, operationRequestID, motorInfoLoaded);
            }
            case CREATION -> {
                this.log.info("Start creation path with: {} phase status code.", status);
                yield operationMapper.buildSuccessfulResponseDTOFromSaferCreation(engineResponse, operationRequestID, motorInfoLoaded);
            }
        };
    }
}
