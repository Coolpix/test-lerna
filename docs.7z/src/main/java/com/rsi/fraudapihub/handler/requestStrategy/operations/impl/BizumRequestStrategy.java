package com.rsi.fraudapihub.handler.requestStrategy.operations.impl;

import com.rsi.fraudapihub.handler.requestStrategy.operations.OperationsRequestStrategy;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.enums.OperationPhaseStatus;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BizumRequestStrategy implements OperationsRequestStrategy<SaferRequestDto> {

   private final Logger log = LoggerFactory.getLogger(this.getClass());

   private final OperationMapper operationMapper;

   SaferRequestDto saferRequestDto;

    public BizumRequestStrategy(OperationMapper operationMapper) {
        this.operationMapper = operationMapper;
    }

   @Override
   public SaferRequestDto execute(OperationRequestDto dto) {
       String estadoFaseOperacion = dto.getEstadoFaseOperacion();
       OperationPhaseStatus status = OperationPhaseStatus.fromCode(estadoFaseOperacion);
       return switch (status) {
           case EXECUTION -> {
               this.log.info("Start execution path with: {} phase status code.", estadoFaseOperacion);
               saferRequestDto = operationMapper.executionOperationToSaferBizum(dto);
               this.log.info("Envio a SAFER de BIZUM - EJECUCION {}", saferRequestDto);
               yield saferRequestDto;
           }
           case CREATION -> {
               this.log.info("Start creation path with: {} phase status code.", estadoFaseOperacion);
               saferRequestDto = operationMapper.creationOperationToSaferBizum(dto);
               this.log.info("Envio a SAFER de BIZUM - ALTA: {}", saferRequestDto);
               yield saferRequestDto;
           }
           case SIMULATION -> {
               this.log.info("Start simulation path with: {} phase status code.", estadoFaseOperacion);
               saferRequestDto = operationMapper.simulationOperationToSaferBizum(dto);
               this.log.info("Envio a SAFER de BIZUM - SIMULACION: {}", saferRequestDto);
               yield saferRequestDto;
           }
       };
   }
}
