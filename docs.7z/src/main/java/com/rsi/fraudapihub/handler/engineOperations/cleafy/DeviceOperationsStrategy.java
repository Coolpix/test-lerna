package com.rsi.fraudapihub.handler.engineOperations.cleafy;

import com.rsi.fraudapihub.utils.dto.request.hub.DeviceRequestContext;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;

@FunctionalInterface
public interface DeviceOperationsStrategy {
    WebHookResponseDto execute(DeviceRequestContext context);
}
