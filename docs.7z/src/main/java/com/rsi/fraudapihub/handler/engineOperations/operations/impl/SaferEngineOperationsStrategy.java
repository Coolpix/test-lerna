package com.rsi.fraudapihub.handler.engineOperations.operations.impl;

import com.rsi.fraudapihub.handler.engineOperations.operations.EngineOperationsStrategy;
import com.rsi.fraudapihub.handler.requestStrategy.operations.OperationsRequestHandler;
import com.rsi.fraudapihub.manager.operation.engines.operations.ApiHubFunctionsManager;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferRequestDto;
import com.rsi.fraudapihub.utils.dto.request.hub.EnginesRequestContext;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;

public class SaferEngineOperationsStrategy implements EngineOperationsStrategy {

    private final ApiHubFunctionsManager<SaferRequestDto, SaferResponseDTO> saferApiHubFunctionsManager;
    private final OperationsRequestHandler<SaferRequestDto> operationsRequestHandler;

    public SaferEngineOperationsStrategy(
            ApiHubFunctionsManager<SaferRequestDto, SaferResponseDTO> saferApiHubFunctionsManager,
            OperationsRequestHandler<SaferRequestDto> operationsRequestHandler
    ) {
        this.saferApiHubFunctionsManager = saferApiHubFunctionsManager;
        this.operationsRequestHandler = operationsRequestHandler;
    }

    @Override
    public OperationResponseDto execute(EnginesRequestContext context) {
        SaferRequestDto saferRequestDto = operationsRequestHandler.handleOperation(context.getMotorInfoLoaded().getMapeo(), context.getRequestDto());
        try {
            return saferApiHubFunctionsManager.getEngineResponse(
                    saferRequestDto,
                    context.getFaseOperacion(),
                    context.getCorrelationId(),
                    context.getOperationRequestID(),
                    context.getMotorInfoLoaded(),
                    context.getEngine());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
