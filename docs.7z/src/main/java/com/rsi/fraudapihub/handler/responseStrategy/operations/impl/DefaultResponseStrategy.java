package com.rsi.fraudapihub.handler.responseStrategy.operations.impl;

import com.rsi.fraudapihub.handler.responseStrategy.operations.OperationsResponseStrategy;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.EE_O_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.fraudapihub.utils.mapper.OperationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DefaultResponseStrategy implements OperationsResponseStrategy<EE_O_ComprobarFraude> {
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final OperationMapper operationMapper;

    public DefaultResponseStrategy(OperationMapper operationMapper) {
        this.operationMapper = operationMapper;
    }

    @Override
    public OperationResponseDto execute(EE_O_ComprobarFraude engineResponse, String faseOperacion, String operationRequestID, AntifraudEngineService.MotorInfoLoaded motorInfoLoaded) {
        return operationMapper.buildTacticalEngineHubResponse(engineResponse, operationRequestID, motorInfoLoaded);
    }
}
