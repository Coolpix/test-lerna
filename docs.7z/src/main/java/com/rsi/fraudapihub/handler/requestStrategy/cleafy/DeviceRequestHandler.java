package com.rsi.fraudapihub.handler.requestStrategy.cleafy;

import com.rsi.fraudapihub.handler.requestStrategy.cleafy.impl.CleafyRequestStrategy;
import com.rsi.fraudapihub.utils.dto.request.operation.WebHookRequestDto;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class DeviceRequestHandler<T> {

    private final Map<String, DeviceRequestStrategy> cleafyRequestStrategyMap;

    public DeviceRequestHandler(
            CleafyRequestStrategy cleafyRequestStrategy
    ) {
        this.cleafyRequestStrategyMap = Map.of(
                "CLEAFY", cleafyRequestStrategy,
                "DEFAULT", cleafyRequestStrategy
        );
    }

    public T handleOperation(String code, WebHookRequestDto dto) {
        return (T) cleafyRequestStrategyMap.getOrDefault(code, cleafyRequestStrategyMap.get("DEFAULT")).execute(dto);
    }
}
