package com.rsi.fraudapihub.handler.engineOperations.operations;

import com.rsi.fraudapihub.handler.engineOperations.operations.impl.DefaultEngineOperationsStrategy;
import com.rsi.fraudapihub.handler.engineOperations.operations.impl.SaferEngineOperationsStrategy;
import com.rsi.fraudapihub.handler.engineOperations.operations.impl.TacticalEngineOperationsStrategy;
import com.rsi.fraudapihub.utils.dto.request.hub.EnginesRequestContext;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;

import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class EngineOperationsHandler {

    private final Map<String, EngineOperationsStrategy> operationStrategies;

    public EngineOperationsHandler(
            SaferEngineOperationsStrategy saferHubStrategy,
            TacticalEngineOperationsStrategy tacticalHubStrategy,
            DefaultEngineOperationsStrategy defaultHubStrategy
    ) {
        this.operationStrategies = Map.of(
        "SAFER", saferHubStrategy,
        "TACTICO", tacticalHubStrategy,
        "GENERICO", defaultHubStrategy,
        "DEFAULT", defaultHubStrategy
        );
    }

    public OperationResponseDto handleOperation(String code, EnginesRequestContext context) {
        return operationStrategies.getOrDefault(code, operationStrategies.get("DEFAULT")).execute(context);
    }
}
