package com.rsi.fraudapihub.handler.engineOperations.cleafy.impl;

import com.rsi.fraudapihub.handler.engineOperations.cleafy.DeviceOperationsStrategy;
import com.rsi.fraudapihub.handler.requestStrategy.cleafy.DeviceRequestHandler;
import com.rsi.fraudapihub.manager.operation.engines.devices.CleafyFunctionsManager;
import com.rsi.fraudapihub.utils.dto.request.engine.cleafy.CleafyRequestDto;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferWebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.request.hub.DeviceRequestContext;
import com.rsi.fraudapihub.utils.dto.response.engine.cleafy.CleafyResponseDto;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;

public class CleafyEngineOperationsStrategy implements DeviceOperationsStrategy {

    private final CleafyFunctionsManager<SaferWebHookRequestDto, SaferResponseDTO> cleafyApiHubFunctionsManager;
    private final DeviceRequestHandler<SaferWebHookRequestDto> cleafyRequestHandler;

    public CleafyEngineOperationsStrategy(
            CleafyFunctionsManager<SaferWebHookRequestDto, SaferResponseDTO> cleafyApiHubFunctionsManager,
            DeviceRequestHandler<SaferWebHookRequestDto> deviceRequestHandler
    ) {
        this.cleafyApiHubFunctionsManager = cleafyApiHubFunctionsManager;
        this.cleafyRequestHandler = deviceRequestHandler;
    }

    @Override
    public WebHookResponseDto execute(DeviceRequestContext context) {
        SaferWebHookRequestDto saferWebHookRequestDto = cleafyRequestHandler.handleOperation("CLEAFY", context.getRequestDto());
        try {
            return cleafyApiHubFunctionsManager.getEngineResponse(
                    saferWebHookRequestDto,
                    context.getCorrelationId(),
                    context.getEngine());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
