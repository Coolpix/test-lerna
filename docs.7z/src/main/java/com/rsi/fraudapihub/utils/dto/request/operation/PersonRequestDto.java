package com.rsi.fraudapihub.utils.dto.request.operation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

/**
 * The EE_I_AltaPersonaPBC dto.
 *
 * @author Sergio Alonso
 */
@JsonTypeName(value = "EE_I_AltaPersonaPBC")
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "EE_I_AltaPersonaPBC", namespace = "http://www.ruralvia.com/fraudapihub")
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PersonRequestDto implements Serializable {

    @JsonProperty(value = "codigoEntidad")
    @XmlElement(name = "codigoEntidad", required = true)
    private String codigoEntidad;

    @JsonProperty(value = "tipoOperacion")
    @XmlElement(name = "tipoOperacion", required = true)
    private String tipoOperacion;

    @JsonProperty(value = "idCanal")
    @XmlElement(name = "idCanal", required = true)
    private String idCanal;

    @JsonProperty(value = "idInternoPe")
    @XmlElement(name = "idInternoPe", required = true)
    private String idInternoPe;

    @JsonProperty(value = "codigoIdExterno")
    @XmlElement(name = "codigoIdExterno")
    private String codigoIdExterno;

    @JsonProperty(value = "idExternoPe")
    @XmlElement(name = "idExternoPe")
    private String idExternoPe;

    @JsonProperty(value = "apellidoUnoCliente")
    @XmlElement(name = "apellidoUnoCliente")
    private String apellidoUnoCliente;

    @JsonProperty(value = "apellidoDosCliente")
    @XmlElement(name = "apellidoDosCliente")
    private String apellidoDosCliente;

    @JsonProperty(value = "nombreCliente")
    @XmlElement(name = "nombreCliente")
    private String nombreCliente;

    @JsonProperty(value = "denomLegal")
    @XmlElement(name = "denomLegal")
    private String denomLegal;

    @JsonProperty(value = "tipoPersona")
    @XmlElement(name = "tipoPersona")
    private String tipoPersona;

    @JsonProperty(value = "sexo")
    @XmlElement(name = "sexo")
    private String sexo;

    @JsonProperty(value = "codigoPaisNacionalidad")
    @XmlElement(name = "codigoPaisNacionalidad")
    private String codigoPaisNacionalidad;

    @JsonProperty(value = "codigoPaisNacimiento")
    @XmlElement(name = "codigoPaisNacimiento")
    private String codigoPaisNacimiento;

    @JsonProperty(value = "codigoPaisResidencia")
    @XmlElement(name = "codigoPaisResidencia")
    private String codigoPaisResidencia;

    @JsonProperty(value = "codigoEstructuraLegal")
    @XmlElement(name = "codigoEstructuraLegal")
    private String codigoEstructuraLegal;

    @JsonProperty(value = "fechaNacimiento")
    @XmlElement(name = "fechaNacimiento")
    private String fechaNacimiento;

    @JsonProperty(value = "codigoCNAE")
    @XmlElement(name = "codigoCNAE")
    private String codigoCNAE;

    @JsonProperty(value = "codigoCNO")
    @XmlElement(name = "codigoCNO")
    private String codigoCNO;

    @JsonProperty(value = "codigoSituacionLaboral")
    @XmlElement(name = "codigoSituacionLaboral")
    private String codigoSituacionLaboral;

    @JsonProperty(value = "paisFiscal")
    @XmlElement(name = "paisFiscal")
    private String paisFiscal;

    @JsonProperty(value = "municipioFiscal")
    @XmlElement(name = "municipioFiscal")
    private String municipioFiscal;

    @JsonProperty(value = "municipioPostal")
    @XmlElement(name = "municipioPostal")
    private String municipioPostal;

    @JsonProperty(value = "municipioOtros")
    @XmlElement(name = "municipioOtros")
    private String municipioOtros;

    @JsonProperty(value = "listaRelacionesPersona")
    @XmlElement(name = "listaRelacionesPersona")
    private List<String> listaRelacionesPersona;

    @JsonProperty(value = "estadoPersona")
    @XmlElement(name = "estadoPersona")
    private String estadoPersona;

}
