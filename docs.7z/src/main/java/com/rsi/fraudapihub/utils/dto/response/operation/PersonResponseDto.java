package com.rsi.fraudapihub.utils.dto.response.operation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.rsi.fraudapihub.utils.dto.base.BaseResponse;
import com.rsi.fraudapihub.utils.dto.base.ErrorResponse;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The EE_O_AltaOperacionFraude dto.
 *
 * @author Miguel Alonso Felipe
 */

@JsonTypeName(value = "EE_O_AltaPersonaPBC")
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "EE_O_AltaPersonaPBC", namespace = "http://www.ruralvia.com/fraudapihub")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class PersonResponseDto extends BaseResponse {

    /** The error. */
    @JsonProperty("RespuestaOperacion")
    private PersonInsideResponseDto personInsideResponseDto;

    /** The error. */
    @JsonProperty("Errores")
    private ErrorResponse error;

}

