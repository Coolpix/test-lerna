package com.rsi.fraudapihub.utils.constants;

/**
 * The type Response constants.
 *
 * @author Miguel Alonso Felipe
 */
public final class ResponseConstants {

    private ResponseConstants() {
        throw new AssertionError("Cannot instantiate constant utility class");
    }

    /**
     * The constant DEFAULT_ERROR_CODE.
     */
    public static final String DEFAULT_ERROR_CODE = "17000";
    /**
     * The constant DEFAULT_ERROR_MESSAGE.
     */
    public static final String DEFAULT_ERROR_MESSAGE = "Algo ha ido mal en la aplicación.";
    /**
     * The constant DEFAULT_ERROR_SOLUTION.
     */
    public static final String DEFAULT_ERROR_SOLUTION = "Prueba de nuevo más tarde. Revise logs de aplicación.";

    /**
     * The constant MANDATORY_FIELDS_LACK_ERROR_CODE.
     */
    public static final String MANDATORY_FIELDS_LACK_ERROR_CODE = "17001";
    /**
     * The constant MANDATORY_FIELDS_LACK_ERROR_MESSAGE.
     */
    public static final String MANDATORY_FIELDS_LACK_ERROR_MESSAGE = "Petición no válida por falta de campos obligatorios.";
    /**
     * The constant MANDATORY_FIELDS_LACK_ERROR_SOLUTION.
     */
    public static final String MANDATORY_FIELDS_LACK_ERROR_SOLUTION = "Revise los campos de entrada del cuerpo de la petición.";

    /**
     * The constant INCOMPATIBLE_FIELDS_ERROR_CODE.
     */
    public static final String INCOMPATIBLE_FIELDS_ERROR_CODE = "17002";
    /**
     * The constant INCOMPATIBLE_FIELDS_ERROR_MESSAGE.
     */
    public static final String INCOMPATIBLE_FIELDS_ERROR_MESSAGE = "Petición no válida por incompatibilidad en sus campos.";
    /**
     * The constant INCOMPATIBLE_FIELDS_ERROR_SOLUTION.
     */
    public static final String INCOMPATIBLE_FIELDS_ERROR_SOLUTION = "";

    /**
     * The constant REQUEST_MAPPING_ERROR_CODE.
     */
    public static final String REQUEST_MAPPING_ERROR_CODE = "17003";
    /**
     * The constant REQUEST_MAPPING_ERROR_MESSAGE.
     */
    public static final String REQUEST_MAPPING_ERROR_MESSAGE = "Error al mapear la petición.";
    /**
     * The constant REQUEST_MAPPING_ERROR_SOLUTION.
     */
    public static final String REQUEST_MAPPING_ERROR_SOLUTION = "Prueba de nuevo más tarde. Revise logs de aplicación.";

    /**
     * The constant DATABASE_ACCESS_ERROR_CODE.
     */
    public static final String DATABASE_ACCESS_ERROR_CODE = "17004";
    /**
     * The constant DATABASE_ACCESS_ERROR_MESSAGE.
     */
    public static final String DATABASE_ACCESS_ERROR_MESSAGE = "Error de acceso a la base de datos.";
    /**
     * The constant DATABASE_ACCESS_ERROR_SOLUTION.
     */
    public static final String DATABASE_ACCESS_ERROR_SOLUTION = "";

    /**
     * The constant INCOMPATIBLE_RECORD_ERROR_CODE.
     */
    public static final String INCOMPATIBLE_RECORD_ERROR_CODE = "17005";
    /**
     * The constant INCOMPATIBLE_RECORD_ERROR_MESSAGE.
     */
    public static final String INCOMPATIBLE_RECORD_ERROR_MESSAGE = "Error debido a la incompatibilidad de algunos campos con un registro previo de la base de datos.";
    /**
     * The constant INCOMPATIBLE_RECORD_ERROR_SOLUTION.
     */
    public static final String INCOMPATIBLE_RECORD_ERROR_SOLUTION = "";

    /**
     * The constant CONNECTION_ENGINE_ERROR_CODE.
     */
    public static final String CONNECTION_ENGINE_ERROR_CODE = "17006";
    /**
     * The constant CONNECTION_ENGINE_ERROR_MESSAGE.
     */
    public static final String CONNECTION_ENGINE_ERROR_MESSAGE = "Error en la conexión con un motor.";
    /**
     * The constant CONNECTION_ENGINE_ERROR_SOLUTION.
     */
    public static final String CONNECTION_ENGINE_ERROR_SOLUTION = "";
}
