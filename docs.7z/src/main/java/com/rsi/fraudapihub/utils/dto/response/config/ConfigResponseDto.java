package com.rsi.fraudapihub.utils.dto.response.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ConfigResponseDto {

    @JsonProperty("isConfigured")
    private boolean isConfigured;
}
