package com.rsi.fraudapihub.utils.dto.response.operation;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The type Operation inside response dto.
 *
 * @author Miguel Alonso Felipe
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class OperationInsideResponseDto {

    @JsonProperty(value = "estadoOperacion", required = true)
    @XmlElement(name = "estadoOperacion", required = true)
    private String estadoOperacion;

    @JsonProperty(value = "riesgoOperacion", required = true)
    @XmlElement(name = "riesgoOperacion", required = true)
    private Float riesgoOperacion;

    @JsonProperty(value = "idOperacionBE", required = true)
    @XmlElement(name = "idOperacionBE", required = true)
    private String idOperacionBE;

    @JsonProperty(value = "idOperacionInterno", required = true)
    @XmlElement(name = "idOperacionInterno", required = true)
    private Integer idOperacionInterno;

    @JsonProperty(value = "bloquearUsuario", required = true)
    @XmlElement(name = "bloquearUsuario", required = true)
    private Boolean bloquearUsuario;

    @JsonProperty(value = "motivosFraude", required = true)
    @XmlElement(name = "motivosFraude", required = true)
    private String motivosFraude;

    @JsonProperty(value = "motorInfoLoaded", required = true)
    @XmlElement(name = "motorInfoLoaded", required = true)
    private AntifraudEngineService.MotorInfoLoaded motorInfoLoaded;

}
