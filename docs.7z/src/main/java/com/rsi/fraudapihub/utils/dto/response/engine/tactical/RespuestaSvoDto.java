package com.rsi.fraudapihub.utils.dto.response.engine.tactical;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RespuestaSvoDto {

    @JsonProperty("idFraude")
    private String idFraude;
}
