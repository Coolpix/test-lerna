package com.rsi.fraudapihub.utils.dto.response.engine.tactical;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.rsi.fraudapihub.utils.dto.base.BaseResponse;
import com.rsi.fraudapihub.utils.dto.base.ErrorResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
@JsonTypeName(value = "EE_O_ComprobarFraude")
@SuppressWarnings("TypeName")
public class EE_O_ComprobarFraude extends BaseResponse {

    @JsonProperty("Respuesta")
    private RespuestaDto respuesta;

    @JsonProperty("Errores")
    private ErrorResponse errores;

}
