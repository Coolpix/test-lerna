package com.rsi.fraudapihub.utils.dto.request.hub;

import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.request.operation.WebHookRequestDto;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DeviceRequestContext {
    private final WebHookRequestDto requestDto;
    private final String correlationId;
    private final AntifraudEngineConfiguration.InfoMotorConfig engine;
}
