package com.rsi.fraudapihub.utils.dto.response.engine.cleafy;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CleafyResponseDto {

    @JsonProperty("Version")
    private int version;
}
