package com.rsi.fraudapihub.utils.enums;

import lombok.Getter;

/**
 * The enum Operation phase status.
 */
@Getter
public enum OperationPhaseStatus {
    /**
     * Simulation operation phase status.
     */
    SIMULATION("0"),
    /**
     * Creation operation phase status.
     */
    CREATION("1"),
    /**
     * Execution operation phase status.
     */
    EXECUTION("2");

    private final String code;

    OperationPhaseStatus(String code) {
        this.code = code;
    }

    /**
     * From code operation phase status.
     *
     * @param code
     *         the code
     * @return the operation phase status
     */
    public static OperationPhaseStatus fromCode(String code) {
        for (OperationPhaseStatus status : OperationPhaseStatus.values()) {
            if (status.getCode().equals(code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid code: " + code);
    }
}

