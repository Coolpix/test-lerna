package com.rsi.fraudapihub.utils.dto.response.operation;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The type Person inside response dto.
 *
 * @author Sergio Alonso
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class PersonInsideResponseDto {

    @JsonProperty(value = "codRespuestaMotor", required = true)
    private String codRespuestaMotor;

    @JsonProperty(value = "descripcionRespuestaMotor", required = true)
    private String descripcionRespuestaMotor;

    @JsonProperty(value = "codMotor", required = true)
    private String codMotor;

    @JsonProperty(value = "idExternoMotor")
    private String idExternoMotor;

    @JsonProperty(value = "tipoOperacion")
    private String tipoOperacion;

    @JsonProperty(value = "accionPBC")
    private String accionPBC;

    @JsonProperty(value = "idAlerta")
    private String idAlerta;

    @JsonProperty(value = "idEvidencia")
    private String idEvidencia;

    @JsonProperty(value = "riesgoOperacion")
    private String riesgoOperacion;

    @JsonProperty(value = "codRegla")
    private String codRegla;

    @JsonProperty(value = "descrRegla")
    private String descrRegla;

    @JsonProperty(value = "riesgoOperacionManual")
    private String riesgoOperacionManual;
}
