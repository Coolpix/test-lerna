package com.rsi.fraudapihub.utils.dto.response.engine.safer;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import java.util.ArrayList;

/**
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class IrisDTO {

    @JsonProperty("Version")
    @XmlElement(name = "Version")
    private int version;

    @JsonProperty("Message")
    @XmlElement(name = "Message")
    private String message;

    @JsonProperty("IrisInstance")
    @XmlElement(name = "IrisInstance")
    private String irisInstance;

    @JsonProperty("MessageTypeId")
    @XmlElement(name = "MessageTypeId")
    private int messageTypeId;

    @JsonProperty("SystemTime")
    @XmlElement(name = "SystemTime")
    private String systemTime;

    @JsonProperty("UniqueRecordId")
    @XmlElement(name = "UniqueRecordId")
    private int uniqueRecordId;

    @JsonProperty("MessageId")
    @XmlElement(name = "MessageId")
    private String messageId;

    @JsonProperty("Mandator")
    @XmlElement(name = "Mandator")
    private ArrayList<MandatorDTO> mandator;

    @JsonProperty("Merging")
    @XmlElement(name = "Merging")
    private boolean merging;

    @JsonProperty("InstanceStatus")
    @XmlElement(name = "InstanceStatus")
    private String instanceStatus;

    @JsonProperty("Latency")
    @XmlElement(name = "Latency")
    private double latency;

    @JsonProperty("Error")
    @XmlElement(name = "Error")
    private String error;

    @JsonProperty("ErrorCode")
    @XmlElement(name = "ErrorCode")
    private int errorCode;
}
