package com.rsi.fraudapihub.utils.enums;

import lombok.Getter;

/**
 *
 */
@Getter
public enum EnginesCodes {
    SAFER("0"),
    TACTICO("1"),
    GENERICO("9999");

    private final String code;

    EnginesCodes(String code) {
        this.code = code;
    }

    public static EnginesCodes fromCode(String code) {
        for (EnginesCodes engineCode : EnginesCodes.values()) {
            if (engineCode.getCode().equals(code)) {
                return engineCode;
            }
        }
        throw new IllegalArgumentException("Invalid code: " + code);
    }
}

