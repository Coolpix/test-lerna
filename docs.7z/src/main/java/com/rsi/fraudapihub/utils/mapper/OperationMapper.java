package com.rsi.fraudapihub.utils.mapper;

import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.request.engine.cleafy.CleafyRequestDto;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferWebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.request.engine.tactical.EE_I_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.request.engine.tactical.Request;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import com.rsi.fraudapihub.utils.dto.request.engine.safer.SaferRequestDto;
import com.rsi.fraudapihub.utils.dto.request.operation.WebHookRequestDto;
import com.rsi.fraudapihub.utils.dto.response.engine.cleafy.CleafyResponseDto;
import com.rsi.fraudapihub.utils.dto.response.engine.safer.SaferResponseDTO;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.EE_O_ComprobarFraude;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.FactorDto;
import com.rsi.fraudapihub.utils.dto.response.operation.OperationResponseDto;
import com.rsi.fraudapihub.utils.dto.response.operation.WebHookResponseDto;
import org.mapstruct.*;

import java.util.*;

/**
 * The interface Operation mapper.
 *
 * @author Miguel Alonso Felipe
 */
@Mapper(componentModel = "spring")
public interface OperationMapper {

    /**
     * Operation to safer ti safer request dto.
     *
     * @param operationRequestDto
     *         the operation request dto
     * @return the safer request dto
     * @throws NoSuchElementException
     *         the no such element exception
     */
    @Mapping(target = "nombrePorCuentaDe", ignore = true)
    @Mapping(target = "nombreOrdenante", ignore = true)
    @Mapping(target = "ibanOrdenante", ignore = true)
    @Mapping(target = "nombreBeneficiario", ignore = true)
    @Mapping(target = "entidadBeneficiaria", ignore = true)
    @Mapping(target = "telefonoDestinatario", ignore = true)
    @Mapping(target = "ibanBeneficiario", ignore = true)
    @Mapping(target = "bicBeneficiario", ignore = true)
    @Mapping(target = "importeOperacion", ignore = true)
    @Mapping(target = "concepto", ignore = true)
    @Mapping(target = "codigoMonedaOperacion", qualifiedByName = "mapCodigoMonedaOperacion")
    SaferRequestDto executionOperationToSaferTIOrTR(OperationRequestDto operationRequestDto) throws NoSuchElementException;

    /**
     * Execution operation to safer ti psd 2 or tr psd 2 safer request dto.
     *
     * @param operationRequestDto
     *         the operation request dto
     * @return the safer request dto
     */
    @Mapping(target = "nombrePorCuentaDe", ignore = true)
    @Mapping(target = "nombreOrdenante", ignore = true)
    @Mapping(target = "acuerdoBE", ignore = true)
    @Mapping(target = "ibanOrdenante", ignore = true)
    @Mapping(target = "nombreBeneficiario", ignore = true)
    @Mapping(target = "entidadBeneficiaria", ignore = true)
    @Mapping(target = "telefonoDestinatario", ignore = true)
    @Mapping(target = "ibanBeneficiario", ignore = true)
    @Mapping(target = "bicBeneficiario", ignore = true)
    @Mapping(target = "importeOperacion", ignore = true)
    @Mapping(target = "concepto", ignore = true)
    @Mapping(target = "idSesion", ignore = true)
    @Mapping(target = "codigoMonedaOperacion", qualifiedByName = "mapCodigoMonedaOperacion")
    SaferRequestDto executionOperationToSaferTIPsd2OrTRPsd2(OperationRequestDto operationRequestDto);

    /**
     * Execution operation to safer bizum safer request dto.
     *
     * @param operationRequestDto
     *         the operation request dto
     * @return the safer request dto
     */
    @Mapping(target = "nombrePorCuentaDe", ignore = true)
    @Mapping(target = "nombreOrdenante", ignore = true)
    @Mapping(target = "ibanOrdenante", ignore = true)
    @Mapping(target = "nombreBeneficiario", ignore = true)
    @Mapping(target = "entidadBeneficiaria", ignore = true)
    @Mapping(target = "telefonoDestinatario", ignore = true)
    @Mapping(target = "ibanBeneficiario", ignore = true)
    @Mapping(target = "bicBeneficiario", ignore = true)
    @Mapping(target = "importeOperacion", ignore = true)
    @Mapping(target = "concepto", ignore = true)
    @Mapping(target = "idOperacionCORE", ignore = true)
    @Mapping(target = "importeComisionesOperacion", ignore = true)
    @Mapping(target = "gastos", ignore = true)
    @Mapping(target = "codigoMonedaOperacion", qualifiedByName = "mapCodigoMonedaOperacion")
    SaferRequestDto executionOperationToSaferBizum(OperationRequestDto operationRequestDto);

    /**
     * Creation operation to safer ti or tr safer request dto.
     *
     * @param operationRequestDto
     *         the operation request dto
     * @return the safer request dto
     */
    @Mapping(target = "telefonoDestinatario", ignore = true)
    @Mapping(target = "bicBeneficiario", ignore = true)
    @Mapping(target = "idOperacionCORE", ignore = true)
    @Mapping(target = "importeComisionesOperacion", ignore = true)
    @Mapping(target = "gastos", ignore = true)
    @Mapping(target = "codigoMonedaOperacion", qualifiedByName = "mapCodigoMonedaOperacion")
    SaferRequestDto creationOperationToSaferTIOrTR(OperationRequestDto operationRequestDto);

    /**
     * Creation operation to safer ti psd 2 or tr psd 2 safer request dto.
     *
     * @param operationRequestDto
     *         the operation request dto
     * @return the safer request dto
     */
    @Mapping(target = "telefonoDestinatario", ignore = true)
    @Mapping(target = "bicBeneficiario", ignore = true)
    @Mapping(target = "idOperacionCORE", ignore = true)
    @Mapping(target = "importeComisionesOperacion", ignore = true)
    @Mapping(target = "gastos", ignore = true)
    @Mapping(target = "idSesion", ignore = true)
    @Mapping(target = "codigoMonedaOperacion", qualifiedByName = "mapCodigoMonedaOperacion")
    SaferRequestDto creationOperationToSaferTIPsd2OrTRPsd2(OperationRequestDto operationRequestDto);

    /**
     * Creation operation to safer bizum safer request dto.
     *
     * @param operationRequestDto
     *         the operation request dto
     * @return the safer request dto
     */
    @Mapping(target = "bicBeneficiario", ignore = true)
    @Mapping(target = "idOperacionCORE", ignore = true)
    @Mapping(target = "importeComisionesOperacion", ignore = true)
    @Mapping(target = "gastos", ignore = true)
    @Mapping(target = "retornoOperacion", ignore = true)
    @Mapping(target = "mensajeMostrarOperacion", ignore = true)
    @Mapping(target = "codigoMonedaOperacion", qualifiedByName = "mapCodigoMonedaOperacion")
    SaferRequestDto creationOperationToSaferBizum(OperationRequestDto operationRequestDto);

    /**
     * Simulation operation to safer ti or tr safer request dto.
     *
     * @param operationRequestDto
     *         the operation request dto
     * @return the safer request dto
     */
    @Mapping(target = "telefonoDestinatario", ignore = true)
    @Mapping(target = "bicBeneficiario", ignore = true)
    @Mapping(target = "idOperacionBE", ignore = true)
    @Mapping(target = "idOperacionCORE", ignore = true)
    @Mapping(target = "importeComisionesOperacion", ignore = true)
    @Mapping(target = "gastos", ignore = true)
    @Mapping(target = "codigoMonedaOperacion", qualifiedByName = "mapCodigoMonedaOperacion")
    SaferRequestDto simulationOperationToSaferTIOrTR(OperationRequestDto operationRequestDto);

    /**
     * Simulation operation to safer ti psd 2 or tr psd 2 safer request dto.
     *
     * @param operationRequestDto
     *         the operation request dto
     * @return the safer request dto
     */
    @Mapping(target = "telefonoDestinatario", ignore = true)
    @Mapping(target = "bicBeneficiario", ignore = true)
    @Mapping(target = "idOperacionBE", ignore = true)
    @Mapping(target = "idOperacionCORE", ignore = true)
    @Mapping(target = "importeComisionesOperacion", ignore = true)
    @Mapping(target = "gastos", ignore = true)
    @Mapping(target = "idSesion", ignore = true)
    @Mapping(target = "codigoMonedaOperacion", qualifiedByName = "mapCodigoMonedaOperacion")
    SaferRequestDto simulationOperationToSaferTIPsd2OrTRPsd2(OperationRequestDto operationRequestDto);

    /**
     * Simulation operation to safer bizum safer request dto.
     *
     * @param operationRequestDto
     *         the operation request dto
     * @return the safer request dto
     */
    @Mapping(target = "bicBeneficiario", ignore = true)
    @Mapping(target = "idOperacionBE", ignore = true)
    @Mapping(target = "idOperacionCORE", ignore = true)
    @Mapping(target = "importeComisionesOperacion", ignore = true)
    @Mapping(target = "gastos", ignore = true)
    @Mapping(target = "codigoMonedaOperacion", qualifiedByName = "mapCodigoMonedaOperacion")
    SaferRequestDto simulationOperationToSaferBizum(OperationRequestDto operationRequestDto);

    /**
     * Creation operation to tactical engine request dto.
     *
     * @param operationRequestDto
     *         the operation request dto
     * @return the tactica engine request dto
     */
    @Mapping(target = "usuarioBe", source = "usuarioBE")
    @Mapping(target = "idOperacion", source = "idOperacionBE")
    @Mapping(target = "canal", source = "idCanal")
    @Mapping(target = "acuerdoBE", source = "acuerdoBE")
    @Mapping(target = "idInternoPe", source = "idInternoPE")
    @Mapping(target = "ibanOrigen", source = "ibanOrdenante")
    @Mapping(target = "ordenante", source = "nombreOrdenante")
    @Mapping(target = "cuentaDestino", source = "ibanBeneficiario")
    @Mapping(target = "bicDestino", source = "bicBeneficiario")
    @Mapping(target = "beneficiario", source = "nombreBeneficiario")
    @Mapping(target = "importe", source = "importeOperacion")
    @Mapping(target = "cccVirtual", source = "cccVirtual")
    EE_I_ComprobarFraude creationTacticalRequestMapping(OperationRequestDto operationRequestDto);

    /**
     * Creation svo request mapping request.
     *
     * @param eeOComprobarFraude
     *         the ee o comprobar fraude
     * @param idOperacionBE
     *         the id operacion be
     * @return request request
     */
    @Mapping(target = "marcaPosibleFraude", source = "eeOComprobarFraude.respuesta.marcaPosibleFraude")
    @Mapping(target = "pesoFraude", source = "eeOComprobarFraude.respuesta.pesoFraude")
    @Mapping(target = "listaFactores", source = "eeOComprobarFraude.respuesta.listaFactores")
    @Mapping(target = "indicadorDenegacion", source = "eeOComprobarFraude.respuesta.accionAntiFraude")
    @Mapping(target = "idOperacion", expression = "java(idOperacionBE)")
    Request creationSVORequestMapping(EE_O_ComprobarFraude eeOComprobarFraude, String idOperacionBE);

    /**
     * @param idOperacionBE
     * @param listaFactores
     * @return
     */
    @Mapping(target = "marcaPosibleFraude", constant = "false")
    @Mapping(target = "pesoFraude", constant = "-1")
    @Mapping(target = "listaFactores", expression = "java(listaFactores)")
    @Mapping(target = "indicadorDenegacion", constant = "false")
    @Mapping(target = "idOperacion", expression = "java(idOperacionBE)")
    Request creationSVORequestMapping(String idOperacionBE, ArrayList<FactorDto> listaFactores);

    /**
     * @param operationRequestID
     * @return
     */
    @Mapping(target = "codigoRetorno", constant = "0")
    @Mapping(target = "operationInsideResponseDto.idOperacionBE", qualifiedByName = "operationRequestID", source = "operationRequestID")
    OperationResponseDto buildTacticalEngineHubResponse(String operationRequestID);

    /**
     * Build tactical engine hub response operation response dto.
     *
     * @param engineResponse
     *         the engine response
     * @param operationRequestID
     *         the operation request id
     * @param motorInfoLoaded
     *         the motor info
     * @return operation response dto
     */
    @Mapping(target = "codigoRetorno", constant = "1")
    @Mapping(target = "operationInsideResponseDto.estadoOperacion", qualifiedByName = "accionAntiFraude", source = "engineResponse.respuesta.accionAntiFraude")
    @Mapping(target = "operationInsideResponseDto.bloquearUsuario", constant = "false")
    @Mapping(target = "operationInsideResponseDto.idOperacionBE", qualifiedByName = "operationRequestID", source = "operationRequestID")
    @Mapping(target = "operationInsideResponseDto.idOperacionInterno", constant = "0")
    @Mapping(target = "operationInsideResponseDto.motivosFraude", constant = "")
    @Mapping(target = "operationInsideResponseDto.motorInfoLoaded", qualifiedByName = "motorInfo", source = "motorInfoLoaded")
    @Mapping(target = "operationInsideResponseDto.riesgoOperacion", source = "engineResponse.respuesta.pesoFraude")
    OperationResponseDto buildTacticalEngineHubResponse(
            EE_O_ComprobarFraude engineResponse,
            String operationRequestID,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded
    );

    /**
     * Build successful response dto operation response dto for creation in Safer.
     *
     * @param engineResponse
     *         the engine response
     * @param operationRequestID
     *         the operation request id
     * @param motorInfoLoaded
     *         the motor info
     * @return the operation response dto
     */
    @Mapping(target = "codigoRetorno", constant = "1")
    @Mapping(target = "operationInsideResponseDto.idOperacionBE", source = "operationRequestID")
    @Mapping(target = "operationInsideResponseDto.idOperacionInterno", source = "engineResponse", qualifiedByName = "mapUniqueRecordId")
    @Mapping(target = "operationInsideResponseDto.motivosFraude", constant = "")
    @Mapping(target = "operationInsideResponseDto.estadoOperacion", source = "engineResponse", qualifiedByName = "mapEstadoOperacion")
    @Mapping(target = "operationInsideResponseDto.bloquearUsuario", source = "engineResponse.spBloqueoUsuario", qualifiedByName = "mapIntegerToBoolean")
    @Mapping(target = "operationInsideResponseDto.riesgoOperacion", source = "engineResponse.spRiskScore")
    @Mapping(target = "operationInsideResponseDto.motorInfoLoaded", source = "motorInfoLoaded")
    OperationResponseDto buildSuccessfulResponseDTOFromSaferCreation(
            SaferResponseDTO engineResponse,
            String operationRequestID,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded
    );

    /**
     * Build successful response dto operation response dto for simulation and execution for Safer.
     *
     * @param engineResponse
     *         the engine response
     * @param operationRequestID
     *         the operation request id
     * @param motorInfoLoaded
     *         the motor info
     * @return the operation response dto
     */
    @Mapping(target = "codigoRetorno", constant = "1")
    @Mapping(target = "operationInsideResponseDto.idOperacionBE", source = "operationRequestID")
    @Mapping(target = "operationInsideResponseDto.idOperacionInterno", source = "engineResponse", qualifiedByName = "mapUniqueRecordId")
    @Mapping(target = "operationInsideResponseDto.motivosFraude", constant = "")
    @Mapping(target = "operationInsideResponseDto.estadoOperacion", constant = "1")
    @Mapping(target = "operationInsideResponseDto.motorInfoLoaded", source = "motorInfoLoaded")
    OperationResponseDto buildSuccessfulResponseDTOFromSaferSimulation(
            SaferResponseDTO engineResponse,
            String operationRequestID,
            AntifraudEngineService.MotorInfoLoaded motorInfoLoaded
    );

    /**
     * Build successful response dto operation response dto.
     *
     * @param webHookRequestDTO
     *         the webHook request Dto
     *
     * @return the cleafy response dto
     */
    @Mapping(target = "codigoRetorno", constant = "1")
    WebHookResponseDto buildSuccessfulWebHookResponseDTO(SaferResponseDTO webHookRequestDTO);

    SaferWebHookRequestDto buildSuccessfulSaferWebHookRequestDTO(WebHookRequestDto webHookRequestDTO);
    /**
     * Build successful response dto operation response dto.
     *
     * @param operationRequestID
     *         the operation request id
     *
     * @return the operation response dto
     */
    @Mapping(target = "codigoRetorno", constant = "1")
    @Mapping(target = "operationInsideResponseDto.estadoOperacion", constant = "1")
    @Mapping(target = "operationInsideResponseDto.bloquearUsuario", constant = "false")
    @Mapping(target = "operationInsideResponseDto.idOperacionInterno", constant = "0")
    @Mapping(target = "operationInsideResponseDto.riesgoOperacion", constant = "0.0f")
    @Mapping(target = "operationInsideResponseDto.motivosFraude", constant = "")
    @Mapping(target = "operationInsideResponseDto.motorInfoLoaded", constant="motorInfoLoaded", qualifiedByName = "defaultMotorInfo")
    OperationResponseDto buildSuccessfulResponseDTO(String operationRequestID);

    /**
     * Default motor info antifraud engine service . motor info.
     *
     * @return the antifraud engine service . motor info
     */
    @Named("defaultMotorInfo")
    static AntifraudEngineService.MotorInfoLoaded defaultMotorInfo(String motorInfoLoaded) {
        return new AntifraudEngineService.MotorInfoLoaded(List.of(new AntifraudEngineConfiguration.InfoMotorConfig("9999", "Motor Genérico", "")),"GENERICO");
    }

    /**
     * Map estado operacion string.
     *
     * @param engineResponse
     *         the engine response
     * @return the string
     */
    @Named("mapEstadoOperacion")
    static String mapEstadoOperacion(SaferResponseDTO engineResponse) {
        return engineResponse.getSpIntercept() == 1 ? "0" : "1";
    }

    /**
     * Map unique record id integer.
     *
     * @param engineResponse
     *         the engine response
     * @return the integer
     */
    @Named("mapUniqueRecordId")
    static Integer mapUniqueRecordId(SaferResponseDTO engineResponse) {
        return engineResponse.getIris().getUniqueRecordId();
    }

    /**
     * Gets accion anti fraude.
     *
     * @param isPosibleFraude
     *         the is posible fraude
     * @return the accion anti fraude
     */
    @Named("accionAntiFraude")
    default String getAccionAntiFraude(Boolean isPosibleFraude) {
        return isPosibleFraude ? "0" : "1";
    }

    /**
     * Gets operation request id.
     *
     * @param operationRequestID
     *         the operation request id
     * @return the operation request id
     */
    @Named("operationRequestID")
    default String getOperationRequestID(String operationRequestID) {
        return operationRequestID;
    }

    /**
     * Gets motor info.
     *
     * @param motorInfoLoaded
     *         the motor info
     * @return the motor info
     */
    @Named("motorInfo")
    default AntifraudEngineService.MotorInfoLoaded getMotorInfo(AntifraudEngineService.MotorInfoLoaded motorInfoLoaded) {
        return motorInfoLoaded;
    }

    /**
     * Map codigo moneda operacion string.
     *
     * @param codigoMonedaOperacion
     *         the codigo moneda operacion
     * @return the string
     * @throws NoSuchElementException
     *         the no such element exception
     */
    @Named("mapCodigoMonedaOperacion")
    default String mapCodigoMonedaOperacion(String codigoMonedaOperacion)  throws NoSuchElementException {
        if (codigoMonedaOperacion != null && !codigoMonedaOperacion.isEmpty()) {
            return Currency.getAvailableCurrencies().stream()
                    .filter(c -> Objects.equals(c.getCurrencyCode(), codigoMonedaOperacion))
                    .findFirst()
                    .orElseThrow(() -> new NoSuchElementException("Codigo de pais no encontrado."))
                    .getNumericCodeAsString();
        }
        return codigoMonedaOperacion;
    }

    /**
     * Map integer to boolean boolean.
     *
     * @param value
     *         the value
     * @return the boolean
     */
    @Named("mapIntegerToBoolean")
    default Boolean mapIntegerToBoolean(Integer value) {
        return value != null && value == 1;
    }
}

