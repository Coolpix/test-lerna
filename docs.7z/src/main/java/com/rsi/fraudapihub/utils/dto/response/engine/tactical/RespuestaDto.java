package com.rsi.fraudapihub.utils.dto.response.engine.tactical;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import java.util.ArrayList;

/**
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RespuestaDto {

    @JsonProperty("marcaPosibleFraude")
    private boolean marcaPosibleFraude;

    @JsonProperty("accionAntiFraude")
    private boolean accionAntiFraude;

    @JsonProperty("numeroRegistros")
    private int numeroRegistros;

    @JsonProperty("ListaFactores")
    private ArrayList<FactorDto> listaFactores;

    @JsonProperty("pesoFraude")
    private int pesoFraude;
}
