package com.rsi.fraudapihub.utils.dto.request.engine.tactical;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import java.io.Serializable;

/**
 * The SVORequestDto dto.
 *
 * @author Sergio Alonso
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@SuppressWarnings("TypeName")
public class EE_I_ComprobarFraude implements Serializable {

    @JsonProperty(value = "codigoEntidad")
    private String codigoEntidad;

    @JsonProperty(value = "usuarioBe")
    private String usuarioBe;

    @JsonProperty(value = "idOperacion")
    private long idOperacion;

    @JsonProperty(value = "tipoOperacion")
    private String tipoOperacion;

    @JsonProperty(value = "canal")
    private String canal;

    @JsonProperty(value = "acuerdoBE")
    private String acuerdoBE;

    @JsonProperty(value = "idInternoPe")
    private String idInternoPe;

    @JsonProperty(value = "ibanOrigen")
    private String ibanOrigen;

    @JsonProperty(value = "importe")
    private float importe;

    @JsonProperty(value = "concepto")
    private String concepto;

    @JsonProperty(value = "ordenante")
    private String ordenante;

    @JsonProperty(value = "cuentaDestino")
    private String cuentaDestino;

    @JsonProperty(value = "bicDestino")
    private String bicDestino;

    @JsonProperty(value = "beneficiario")
    private String beneficiario;

    @JsonProperty(value = "idSesion")
    private String idSesion;

    @JsonProperty(value = "cccVirtual")
    private String cccVirtual;
}
