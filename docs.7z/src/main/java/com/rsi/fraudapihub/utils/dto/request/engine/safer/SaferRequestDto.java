package com.rsi.fraudapihub.utils.dto.request.engine.safer;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * The SaferRequestDto dto.
 *
 * @author Miguel Alonso Felipe
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SaferRequestDto implements Serializable {

    @JsonProperty(value = "codigoEntidad")
    private String codigoEntidad;

    @JsonProperty(value = "tipoOperacion")
    private String tipoOperacion;

    @JsonProperty(value = "usuarioBE")
    private String usuarioBE;

    @JsonProperty(value = "acuerdoBE")
    private String acuerdoBE;

    @JsonProperty(value = "idSesion")
    private String idSesion;

    @JsonProperty(value = "idCanal")
    private String idCanal;

    @JsonProperty(value = "estadoFaseOperacion")
    private String estadoFaseOperacion;

    @JsonProperty(value = "nombreOrdenante")
    private String nombreOrdenante;

    @JsonProperty(value = "ibanOrdenante")
    private String ibanOrdenante;

    @JsonProperty(value = "nombreBeneficiario")
    private String nombreBeneficiario;

    @JsonProperty(value = "ibanBeneficiario")
    private String ibanBeneficiario;

    @JsonProperty(value = "entidadBeneficiaria")
    private String entidadBeneficiaria;

    @JsonProperty(value = "bicBeneficiario")
    private String bicBeneficiario;

    @JsonProperty(value = "telefonoDestinatario")
    private String telefonoDestinatario;

    @JsonProperty(value = "importeOperacion")
    private Float importeOperacion;

    @JsonProperty(value = "codigoMonedaOperacion", defaultValue = "EUR")
    private String codigoMonedaOperacion;

    @JsonProperty(value = "concepto")
    private String concepto;

    @JsonProperty(value = "nombrePorCuentaDe")
    private String nombrePorCuentaDe;

    @JsonProperty(value = "fechaHora", required = true)
    private String fechaHora;

    @JsonProperty(value = "idOperacionBE")
    private String idOperacionBE;

    @JsonProperty(value = "idOperacionCORE")
    private String idOperacionCORE;

    @JsonProperty(value = "importeComisionesOperacion")
    private Float importeComisionesOperacion;

    @JsonProperty(value = "gastos")
    private Float gastos;

    @JsonProperty(value = "retornoOperacion")
    private String retornoOperacion;

    @JsonProperty(value = "mensajeMostrarOperacion")
    private String mensajeMostrarOperacion;
}

