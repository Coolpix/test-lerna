package com.rsi.fraudapihub.utils.dto.request.operation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * The EE_I_AltaOperacionFraude dto.
 *
 * @author Miguel Alonso Felipe
 */
@JsonTypeName(value = "EE_I_AltaOperacionFraude")
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "EE_I_AltaOperacionFraude", namespace = "http://www.ruralvia.com/fraudapihub")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class OperationRequestDto implements Serializable, Cloneable {

    @JsonProperty(value = "codigoEntidad")
    @XmlElement(name = "codigoEntidad", required = true, nillable = false)
    private String codigoEntidad;

    @JsonProperty(value = "tipoOperacion")
    @XmlElement(name = "tipoOperacion", defaultValue = "0")
    private String tipoOperacion;

    @JsonProperty(value = "usuarioBE")
    @XmlElement(name = "usuarioBE", required = true, nillable = false)
    private String usuarioBE;

    @JsonProperty(value = "acuerdoBE")
    @XmlElement(name = "acuerdoBE", required = true, nillable = false)
    private String acuerdoBE;

    @JsonProperty(value = "idSesion")
    @XmlElement(name = "idSesion", defaultValue = "0")
    private String idSesion;

    @JsonProperty(value = "idCanal")
    @XmlElement(name = "idCanal", required = true, nillable = false)
    private String idCanal;

    @JsonProperty(value = "estadoFaseOperacion")
    @XmlElement(name = "estadoFaseOperacion")
    private String estadoFaseOperacion;

    @JsonProperty(value = "nombreOrdenante")
    @XmlElement(name = "nombreOrdenante")
    private String nombreOrdenante;

    @JsonProperty(value = "ibanOrdenante")
    @XmlElement(name = "ibanOrdenante")
    private String ibanOrdenante;

    @JsonProperty(value = "nombreBeneficiario")
    @XmlElement(name = "nombreBeneficiario")
    private String nombreBeneficiario;

    @JsonProperty(value = "ibanBeneficiario")
    @XmlElement(name = "ibanBeneficiario")
    private String ibanBeneficiario;

    @JsonProperty(value = "entidadBeneficiaria")
    @XmlElement(name = "entidadBeneficiaria")
    private String entidadBeneficiaria;

    @JsonProperty(value = "bicBeneficiario")
    @XmlElement(name = "bicBeneficiario")
    private String bicBeneficiario;

    @JsonProperty(value = "telefonoDestinatario")
    @XmlElement(name = "telefonoDestinatario")
    private String telefonoDestinatario;

    @JsonProperty(value = "importeOperacion")
    @XmlElement(name = "importeOperacion")
    private Float importeOperacion;

    @JsonProperty(value = "codigoMonedaOperacion", defaultValue = "EUR")
    @XmlElement(name = "codigoMonedaOperacion", defaultValue = "EUR")
    private String codigoMonedaOperacion;

    @JsonProperty(value = "concepto")
    @XmlElement(name = "concepto")
    private String concepto;

    @JsonProperty(value = "nombrePorCuentaDe")
    @XmlElement(name = "nombrePorCuentaDe")
    private String nombrePorCuentaDe;

    @JsonProperty(value = "fechaHora", required = true)
    @XmlElement(name = "fechaHora", required = true)
    private String fechaHora;

    @JsonProperty(value = "idOperacionBE")
    @XmlElement(name = "idOperacionBE")
    private String idOperacionBE;

    @JsonProperty(value = "idOperacionCORE")
    @XmlElement(name = "idOperacionCORE")
    private String idOperacionCORE;

    @JsonProperty(value = "importeComisionesOperacion")
    @XmlElement(name = "importeComisionesOperacion")
    private Float importeComisionesOperacion;

    @JsonProperty(value = "gastos")
    @XmlElement(name = "gastos")
    private Float gastos;

    @JsonProperty(value = "retornoOperacion")
    @XmlElement(name = "retornoOperacion")
    private String retornoOperacion;

    @JsonProperty(value = "mensajeMostrarOperacion")
    @XmlElement(name = "mensajeMostrarOperacion")
    private String mensajeMostrarOperacion;

    @JsonProperty(value = "cccVirtual")
    @XmlElement(name = "cccVirtual")
    private String cccVirtual;

    @JsonProperty(value = "idInternoPE")
    @XmlElement(name = "idInternoPE")
    private String idInternoPE;


    @Override
    public String toString() {
        return "EE_I_AltaOperacionFraude{" + "acuerdoBE='" + acuerdoBE + '\'' + ", codigoEntidad='" + codigoEntidad + '\'' + ", tipoOperacion='" + tipoOperacion + '\'' + ", usuarioBE='" + usuarioBE + '\'' + ", idSesion='" + idSesion + '\'' + ", idCanal='"
                + idCanal + '\'' + ", estadoFaseOperacion='" + estadoFaseOperacion + '\'' + ", nombreOrdenante='" + nombreOrdenante + '\'' + ", ibanOrdenante='" + ibanOrdenante + '\'' + ", nombreBeneficiario='" + nombreBeneficiario + '\''
                + ", ibanBeneficiario='" + ibanBeneficiario + '\'' + ", entidadBeneficiaria='" + entidadBeneficiaria + '\'' + ", bicBeneficiario='" + bicBeneficiario + '\'' + ", telefonoDestinatario='" + telefonoDestinatario + '\''
                + ", importeOperacion=" + importeOperacion + ", codigoMonedaOperacion='" + codigoMonedaOperacion + '\'' + ", concepto='" + concepto + '\'' + ", nombrePorCuentaDe='" + nombrePorCuentaDe + '\'' + ", fechaHora='" + fechaHora + '\''
                + ", idOperacionBE='" + idOperacionBE + '\'' + ", idOperacionCORE='" + idOperacionCORE + '\'' + ", importeComisionesOperacion=" + importeComisionesOperacion + ", gastos=" + gastos + ", retornoOperacion='" + retornoOperacion + '\''
                + ", mensajeMostrarOperacion='" + mensajeMostrarOperacion + '\'' + ", idInternoPE='" + idInternoPE + ", cccVirtual='" + cccVirtual + '\'' + '}';
    }

    @Override
    public OperationRequestDto clone() {
        try {
            OperationRequestDto clone = (OperationRequestDto) super.clone();
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}
