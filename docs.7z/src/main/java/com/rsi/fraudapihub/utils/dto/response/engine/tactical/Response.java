package com.rsi.fraudapihub.utils.dto.response.engine.tactical;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.rsi.fraudapihub.utils.dto.base.BaseResponse;
import com.rsi.fraudapihub.utils.dto.base.ErrorResponse;

@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
@JsonTypeName(value = "response")
public class Response extends BaseResponse {

    @JsonProperty("Respuesta")
    private RespuestaSvoDto respuesta;

    @JsonProperty("Errores")
    private ErrorResponse errores;
}
