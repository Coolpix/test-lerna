package com.rsi.fraudapihub.utils.dto.response.engine.safer;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SaferResponseDTO {

    @JsonProperty("IRIS")
    @XmlElement(name = "IRIS")
    private IrisDTO Iris;
    private Integer spBloqueoUsuario;
    private Integer spIntercept;
    private Float spRiskScore;
    private String spRulesFired;
}
