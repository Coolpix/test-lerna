package com.rsi.fraudapihub.utils.dto.request.engine.tactical;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.rsi.fraudapihub.utils.dto.response.engine.tactical.FactorDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import java.util.ArrayList;

/**
 * The request dto.
 *
 * @author Sergio Alonso
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@SuppressWarnings("TypeName")
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
@JsonTypeName(value = "request")
public class Request {

    @JsonProperty(value = "idOperacion")
    private String idOperacion;

    @JsonProperty("marcaPosibleFraude")
    private String marcaPosibleFraude;

    @JsonProperty("pesoFraude")
    private String pesoFraude;

    @JsonProperty("ListaFactores")
    private ArrayList<FactorDto> listaFactores;

    @JsonProperty("indicadorDenegacion")
    private String indicadorDenegacion;
}
