package com.rsi.fraudapihub.utils.dto.request.hub;

import com.rsi.fraudapihub.configuration.hub.AntifraudEngineConfiguration;
import com.rsi.fraudapihub.service.config.AntifraudEngineService;
import com.rsi.fraudapihub.utils.dto.request.operation.OperationRequestDto;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EnginesRequestContext {
    private final OperationRequestDto requestDto;
    private final String faseOperacion;
    private final String correlationId;
    private final String operationRequestID;
    private final AntifraudEngineService.MotorInfoLoaded motorInfoLoaded;
    private final AntifraudEngineConfiguration.InfoMotorConfig engine;
}
