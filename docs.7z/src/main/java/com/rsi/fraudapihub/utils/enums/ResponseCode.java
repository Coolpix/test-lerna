package com.rsi.fraudapihub.utils.enums;

import lombok.Getter;

/**
 * The enum Response code.
 */
@Getter
public enum ResponseCode {
    /**
     * Success response code.
     */
    SUCCESS("1"),

    /**
     * Error response code.
     */
    ERROR("0");

    private String responseCodeValue;

    ResponseCode(final String responseCode) {
        this.responseCodeValue = responseCode;
    }

    /**
     * Gets response code.
     *
     * @return the response code
     */
    public String getResponseCode() {
        return this.responseCodeValue;
    }
}
