package com.rsi.fraudapihub.utils.dto.response.engine.tactical;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FactorDto {

    @JsonProperty("codigoFactor")
    private String codigoFactor;

    @JsonProperty("pesoFactor")
    private int pesoFactor;
}
