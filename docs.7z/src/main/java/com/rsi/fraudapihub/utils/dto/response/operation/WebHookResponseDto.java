package com.rsi.fraudapihub.utils.dto.response.operation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.rsi.fraudapihub.utils.dto.base.BaseResponse;
import com.rsi.fraudapihub.utils.dto.base.ErrorResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The EE_O_AltaOperacionFraude dto.
 *
 * @author Miguel Alonso Felipe
 */

@JsonTypeName(value = "EE_O_AltaAlerta")
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class WebHookResponseDto extends BaseResponse {

    /** The error. */
    @JsonProperty("Errores")
    private ErrorResponse error;
}
