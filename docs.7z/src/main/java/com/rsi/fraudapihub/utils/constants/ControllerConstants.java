package com.rsi.fraudapihub.utils.constants;

import org.springframework.http.MediaType;
import java.nio.charset.StandardCharsets;

/**
 * The type Controller constants.
 *
 * @author Miguel Alonso Felipe
 */
public class ControllerConstants {

    /**
     * The JSON Media Type.
     */
    public static final String JSON_MEDIA_TYPE    = MediaType.APPLICATION_JSON_VALUE;

    /**
     * The charset.
     */
    public static final String CHARSET_UTF_8      = StandardCharsets.UTF_8.name();

}
