package com.rsi.fraudapihub.utils.dto.base;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The type Error response.
 *
 * @author Miguel Alonso Felipe
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ErrorResponse {

    @XmlElement(name = "codigoMostrar")
    @JsonProperty("codigoMostrar")
    private String codigoMostrar;

    @XmlElement(name = "mensajeMostrar")
    @JsonProperty("mensajeMostrar")
    private String mensajeMostrar;

    @XmlElement(name = "solucion")
    @JsonProperty("solucion")
    private String solucion;
}

