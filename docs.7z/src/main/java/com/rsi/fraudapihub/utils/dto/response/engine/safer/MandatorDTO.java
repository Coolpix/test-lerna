package com.rsi.fraudapihub.utils.dto.response.engine.safer;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MandatorDTO {

    @JsonProperty("Mandatorname")
    @XmlElement(name = "Mandatorname")
    private String mandatorname;

    @JsonProperty("Revision")
    @XmlElement(name = "Revision")
    private int revision;
}
