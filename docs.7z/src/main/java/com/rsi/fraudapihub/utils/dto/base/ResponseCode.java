package com.rsi.fraudapihub.utils.dto.base;

/**
 * The enum Response code.
 *
 * @author Miguel Alonso Felipe
 */
public enum ResponseCode {

    /**
     * Success response code.
     */
    SUCCESS("1"),

    /**
     * Error response code.
     */
    ERROR("0");

    /** The response code value. */
    private final String responseCodeValue;

    ResponseCode(final String responseCode) {
        this.responseCodeValue = responseCode;
    }

    /**
     * Gets response code.
     *
     * @return the response code
     */
    public String getResponseCode() {
        return this.responseCodeValue;
    }
}
