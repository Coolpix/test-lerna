package com.rsi.fraudapihub.utils.dto.request.engine.safer;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SaferWebHookRequestDto implements Serializable {
    @JsonProperty(value = "idDispositivo")
    private String idDispositivo;

    @JsonProperty(value = "idDispositivoBanca")
    private String idDispositivoBanca;

    @JsonProperty(value = "usuarioBE")
    private String usuarioBE;

    @JsonProperty(value = "idSesion")
    private String idSesion;

    @JsonProperty(value = "tipoDispositivo")
    private String tipoDispositivo;

    @JsonProperty(value = "nombreDispositivo")
    private String nombreDispositivo;

    @JsonProperty(value = "soDispositivo")
    private String soDispositivo;

    @JsonProperty(value = "soVersDispositivo")
    private String soVersDispositivo;

    @JsonProperty(value = "endpointDispositivo")
    private String endpointDispositivo;

    @JsonProperty(value = "endpointVersDispositivo")
    private String endpointVersDispositivo;

    @JsonProperty(value = "ipDispositivo")
    private String ipDispositivo;

    @JsonProperty(value = "latitudDispositivo")
    private String latitudDispositivo;

    @JsonProperty(value = "longitudDispositivo")
    private String longitudDispositivo;

    @JsonProperty(value = "localizacionDispositivo")
    private String localizacionDispositivo;

    @JsonProperty(value = "codIsoPais")
    private String codIsoPais;

    @JsonProperty(value = "tagNuevoDispositivoWeb")
    private Integer tagNuevoDispositivoWeb;

    @JsonProperty(value = "tagNuevoDispositivoApp")
    private Integer tagNuevoDispositivoApp;

    @JsonProperty(value = "tagDispositivoOnCall")
    private Integer tagDispositivoOnCall;

    @JsonProperty(value = "tagNuevaLocalizDispositivo")
    private Integer tagNuevaLocalizDispositivo;

    @JsonProperty(value = "tagJailBroken")
    private Integer tagJailBroken;

    @JsonProperty(value = "tagEmulacion")
    private Integer tagEmulacion;

    @JsonProperty(value = "tagMalwareWeb")
    private Integer tagMalwareWeb;

    @JsonProperty(value = "tagMalwareApp")
    private Integer tagMalwareApp;

    @JsonProperty(value = "tagBehavDispositivo")
    private Integer tagBehavDispositivo;

    @JsonProperty(value = "tagIpBlack")
    private Integer tagIpBlack;

    @JsonProperty(value = "tagBrowserBlack")
    private Integer tagBrowserBlack;

    @JsonProperty(value = "tagDispositivoBlack")
    private Integer tagDispositivoBlack;

    @JsonProperty(value = "tagRiskOnCall")
    private Integer tagRiskOnCall;

    @JsonProperty(value = "tagScam")
    private Integer tagScam;

    @JsonProperty(value = "tagRiskDesvincDispositivo")
    private Integer tagRiskDesvincDispositivo;

    @JsonProperty(value = "tagImpossibleTravel")
    private Integer tagImpossibleTravel;

    @JsonProperty(value = "tagRiskNuevaVinculac")
    private Integer tagRiskNuevaVinculac;
}
