package com.rsi.fraudapihub.utils.dto;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * The type Dto utils.
 *
 * @author Miguel Alonso Felipe
 */
public class DtoUtils {

    /**
     * Remove null fields t.
     *
     * @param <T>
     *         the type parameter
     * @param dto
     *         the dto
     * @return the t
     * @throws IllegalAccessException
     *         the illegal access exception
     */
    public static <T> T removeNullFields(T dto) throws IllegalAccessException {
        Field[] fields = dto.getClass().getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            if (field.get(dto) == null) {
                field.set(dto, null);
            }
        }
        return dto;
    }

    /**
     * To map without nulls map.
     *
     * @param <T>
     *         the type parameter
     * @param dto
     *         the dto
     * @return the map
     * @throws IllegalAccessException
     *         the illegal access exception
     */
    public static <T> Map<String, Object> toMapWithoutNulls(T dto) throws IllegalAccessException {
        Map<String, Object> result = new HashMap<>();
        Field[] fields = dto.getClass().getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            Object value = field.get(dto);
            if (value != null) {
                result.put(field.getName(), value);
            }
        }
        return result;
    }

    /**
     * To json object without nulls json object.
     *
     * @param <T>
     *         the type parameter
     * @param dto
     *         the dto
     * @return the json object
     * @throws IllegalAccessException
     *         the illegal access exception
     */
    public static <T> JSONObject toJsonObjectWithoutNulls(T dto, Boolean plain) throws IllegalAccessException {
        if (dto == null) {
            return null;
        }

        JSONObject jsonObject = createJsonObject(dto);

        JSONObject rootObject = new JSONObject();

        if (!plain) {
            rootObject.put(dto.getClass().getSimpleName(), jsonObject);
            return rootObject;
        } else {
            return jsonObject;
        }

    }

    /**
     * @param obj
     * @return
     * @throws IllegalAccessException
     */
    private static JSONObject createJsonObject(Object obj) throws IllegalAccessException {
        JSONObject jsonObject = new JSONObject();

        Field[] fields = obj.getClass().getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);

            Object value = field.get(obj);
            if (value != null) {
                if (isPrimitiveOrWrapper(value.getClass()) || value instanceof String) {
                    jsonObject.put(field.getName(), value);
                } else {
                    JSONObject nestedJson = createJsonObject(value);
                    jsonObject.put(field.getName(), nestedJson);
                }
            }
        }
        return jsonObject;
    }

    /**
     * @param clazz
     * @return
     */
    private static boolean isPrimitiveOrWrapper(Class<?> clazz) {
        return clazz.isPrimitive()
                || clazz == Boolean.class || clazz == Byte.class || clazz == Character.class
                || clazz == Short.class || clazz == Integer.class || clazz == Long.class
                || clazz == Float.class || clazz == Double.class;
    }
}

