package com.rsi.fraudapihub.utils.dto.request.engine.cleafy;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;

/**
 * The CleafyRequestDto dto.
 *
 * @author Sergio Alonso
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CleafyRequestDto implements Serializable {

    @JsonProperty(value = "codigoEntidad")
    private String codigoEntidad;
}
